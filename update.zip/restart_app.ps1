# MSG Yazilim - Temiz Kapatma ve Yeniden Baslatma Motoru
$ErrorActionPreference = "SilentlyContinue"

$appDir = "C:\MSGYazilim"
$appExe = Join-Path $appDir "MSGYazilim.exe"
$nodeExe = Join-Path $appDir "node.exe"

# 1. Acik olan pencereyi X tusuna basilmis gibi nazikce kapat
Get-Process chrome, msedge -ErrorAction SilentlyContinue | Where-Object { $_.MainWindowTitle -like '*MSG YAZILIM*' } | ForEach-Object {
    $_.CloseMainWindow() | Out-Null
}
Start-Sleep -Milliseconds 600

# Kapanmayan surecleri tamamen sonlandir
Get-Process MSGYazilim -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
Get-Process chrome, msedge -ErrorAction SilentlyContinue | Where-Object { $_.MainWindowTitle -like '*MSG YAZILIM*' } | Stop-Process -Force -ErrorAction SilentlyContinue
Get-Process node -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue

# 2. Portun ve belleklerin bosalmasi icin bekle
Start-Sleep -Milliseconds 1500

# 3. Node sunucusunu arka planda baslat
Start-Process -FilePath $nodeExe -ArgumentList "server.js" -WorkingDirectory $appDir -WindowStyle Hidden

# 4. Sunucunun 3000 portunu dinlemeye basladigini bekle
for ($i = 0; $i -lt 30; $i++) {
    Start-Sleep -Milliseconds 250
    $conn = Test-NetConnection -ComputerName 127.0.0.1 -Port 3000 -WarningAction SilentlyContinue
    if ($conn.TcpTestSucceeded) { break }
}

# 5. Sunucu hazir olduktan sonra MSGYazilim.exe'yi baslat
Start-Sleep -Milliseconds 500
if (Test-Path $appExe) {
    Start-Process -FilePath $appExe -WorkingDirectory $appDir
}
