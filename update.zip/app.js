/* Hırdavat - Profesyonel Yönetim ve Satış Sistemi */
'use strict';

const $=s=>document.querySelector(s);
const $$=s=>document.querySelectorAll(s);
const h=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const money=n=>(Number(n)||0).toLocaleString('tr-TR',{style:'currency',currency:'TRY'});
const num=n=>(Number(n)||0).toLocaleString('tr-TR',{maximumFractionDigits:3});
const pad=n=>String(n).padStart(2,'0');
const dkey=d=>{const x=new Date(d);return x.getFullYear()+'-'+pad(x.getMonth()+1)+'-'+pad(x.getDate())};
const fdate=d=>new Date(d).toLocaleDateString('tr-TR');
const fdt=d=>new Date(d).toLocaleString('tr-TR',{dateStyle:'short',timeStyle:'short'});
const addDays=(d,n)=>{const x=new Date(d);x.setDate(x.getDate()+n);return x.toISOString()};
const parse=v=>{const n=parseFloat(String(v).replace(',','.'));return isNaN(n)?0:n};
const round2=n=>Math.round((n+Number.EPSILON)*100)/100;
const round3=n=>Math.round((n+Number.EPSILON)*1000)/1000;

/* ==========================================================================
   GİB RESMİ KDV TANIMLARI VE HESAPLAMA MOTORU (3065 SAYILI KDV KANUNU)
   ========================================================================== */
const KDV_RATES = [
  { rate: 20, label: '%20 - Genel Oran (Hırdavat, Elektrik, Temizlik, Tekel, Elektronik, Genel)', short: '%20 Genel Oran' },
  { rate: 10, label: '%10 - Gıda & Tekstil (Et, Şarküteri, Süt, Yağ, Manav, Giyim, İlaç)', short: '%10 Gıda/Tekstil' },
  { rate: 1,  label: '%1 - Temel İhtiyaç (Ekmek, Sade Pide, Simit, Un, Toptan Hububat)', short: '%1 Temel İhtiyaç' },
  { rate: 0,  label: '%0 - KDV Muaf / İstisna', short: '%0 Muaf' }
];

function calculateKdvBreakdown(items, discount = 0, total = null){
  if(!Array.isArray(items) || !items.length) return { groups: [], totalKdv: 0, totalMatrah: 0, totalWithKdv: 0 };
  const rawSub = round2(items.reduce((a, i) => a + round2(num(i.qty) * num(i.price)), 0));
  const effectiveTotal = total != null ? num(total) : round2(rawSub - (num(discount) || 0));
  const ratio = rawSub > 0 ? (effectiveTotal / rawSub) : 1;

  const groups = {};
  items.forEach(it => {
    const rate = num(it.kdv != null ? it.kdv : 20);
    const lineTotal = round2(num(it.qty) * num(it.price) * ratio);
    if(!groups[rate]){
      groups[rate] = { rate, totalWithKdv: 0, matrah: 0, kdvAmount: 0 };
    }
    groups[rate].totalWithKdv = round2(groups[rate].totalWithKdv + lineTotal);
  });

  let totalKdv = 0;
  let totalMatrah = 0;
  const list = Object.values(groups).sort((a,b) => b.rate - a.rate).map(g => {
    g.matrah = round2(g.totalWithKdv / (1 + g.rate / 100));
    g.kdvAmount = round2(g.totalWithKdv - g.matrah);
    totalKdv = round2(totalKdv + g.kdvAmount);
    totalMatrah = round2(totalMatrah + g.matrah);
    return g;
  });

  return {
    groups: list,
    totalKdv,
    totalMatrah,
    totalWithKdv: effectiveTotal
  };
}

/* ==========================================================================
   ÇOKLU SEKTÖR MOTORU (SECTOR ENGINE)
   ========================================================================== */
const SECTORS = {
  hirdavat: {
    id: 'hirdavat',
    name: 'Hırdavat & Nalburiye',
    icon: '🔧',
    sub: 'HIRDAVAT & NALBURİYE',
    color: '#0284c7',
    defaultKdv: 20,
    units: ['adet', 'metre', 'paket', 'koli', 'takım', 'rulo', 'kg'],
    defaultUnit: 'adet',
    fields: ['rack', 'brand', 'roll'],
    sampleCats: ['El Aletleri', 'Elektrikli Aletler', 'Civata & Somun & Vida', 'Boya & Kimyasallar', 'Kilit & Hırdavat', 'Bahçe & Tesisat', 'Yapı Malzemeleri'],
    quickHint: 'Vida, dübel, çivi, silikon vb. çok satılan ürünleri buraya ekleyin: <b>＋ Ekle</b>.',
    quickChips: [5, 10, 25],
    namePlaceholder: 'Örn: 4x40 Sunta Vidası',
    barcodePlaceholder: 'Barkod okutun veya ürün kodu yazın'
  },
  market: {
    id: 'market',
    name: 'Market, Bakkal & Tekel',
    icon: '🛒',
    sub: 'MARKET & ŞARKÜTERİ',
    color: '#16a34a',
    defaultKdv: 20,
    units: ['adet', 'paket', 'koli', 'kg', 'gram', 'litre'],
    defaultUnit: 'adet',
    fields: ['scale', 'plu', 'expiry'],
    sampleCats: ['Temel Gıda', 'İçecekler & Meşrubat', 'Atıştırmalık & Şekerleme', 'Süt & Şarküteri', 'Temizlik & Deterjan', 'Manav', 'Tekel & Tütün'],
    quickHint: 'Ekmek, süt, su, yumurta, sakız, sigara vb. çok satılan ürünleri buraya ekleyin: <b>＋ Ekle</b>.',
    quickChips: [1, 2, 5],
    namePlaceholder: 'Örn: Çaykur Rize Turist Çay 1000g',
    barcodePlaceholder: 'Barkod okutun veya yazın (869...)'
  },
  sarkuteri: {
    id: 'sarkuteri',
    name: 'Şarküteri, Kasap & Manav',
    icon: '🥩',
    sub: 'ŞARKÜTERİ & KASAP',
    color: '#dc2626',
    defaultKdv: 10,
    units: ['kg', 'gram', 'adet', 'paket'],
    defaultUnit: 'kg',
    fields: ['scale', 'plu', 'expiry'],
    sampleCats: ['Kırmızı Et & Kıyma', 'Beyaz Et & Tavuk', 'Peynir & Kaşar Çeşitleri', 'Zeytin & Kahvaltılık', 'Sucuk & Pastırma & Sosis', 'Yöresel Lezzetler', 'Taze Manav'],
    quickHint: 'Kıyma, kuşbaşı, kaşar peyniri, beyaz peynir, tereyağı vb. çok satılan ürünleri buraya ekleyin: <b>＋ Ekle</b>.',
    quickChips: [1, 2, 5],
    namePlaceholder: 'Örn: Dana Kıyma (Az Yağlı)',
    barcodePlaceholder: 'Barkod okutun veya terazi kodunu yazın'
  },
  butik: {
    id: 'butik',
    name: 'Butik, Giyim & Ayakkabı',
    icon: '👗',
    sub: 'BUTİK & MODA TASARIM',
    color: '#d946ef',
    defaultKdv: 10,
    units: ['adet', 'çift', 'takım'],
    defaultUnit: 'adet',
    fields: ['variants', 'sizes', 'colors', 'hanger'],
    sizes: ['XS', 'S', 'M', 'L', 'XL', '2XL', '3XL', '36', '38', '40', '42', '44', '46', 'Standart'],
    colors: ['Siyah', 'Beyaz', 'Lacivert', 'Kırmızı', 'Mavi', 'Yeşil', 'Bej', 'Gri', 'Haki', 'Pudra', 'Bordo', 'Kahverengi', 'Ekru'],
    sampleCats: ['Elbise & Abiye', 'T-Shirt & Bluz', 'Pantolon & Jean', 'Gömlek & Triko', 'Ceket & Mont & Kaban', 'Ayakkabı & Çanta', 'Takı & Aksesuar'],
    quickHint: 'Çorap, basic tişört, kemer, şal, toka vb. çok satılan ürünleri buraya ekleyin: <b>＋ Ekle</b>.',
    quickChips: [1, 2, 3],
    namePlaceholder: 'Örn: Siyah Mini Elbise',
    barcodePlaceholder: 'Barkod / Model Kodu / Beden Etiketi'
  },
  kirtasiye: {
    id: 'kirtasiye',
    name: 'Kırtasiye & Kitap',
    icon: '📚',
    sub: 'KIRTASİYE & KİTAPEVİ',
    color: '#0891b2',
    defaultKdv: 20,
    units: ['adet', 'düzine', 'deste', 'kutu', 'paket'],
    defaultUnit: 'adet',
    fields: ['isbn', 'author', 'publisher'],
    sampleCats: ['Okul Kırtasiye', 'Ofis & Masaüstü Gereçleri', 'Defter & Ajanda', 'Kalem & Yazı Gereçleri', 'Roman & Edebiyat', 'Sınav & Ders Kitapları', 'Hobi & Sanatsal'],
    quickHint: 'A4 fotokopi kağıdı, kurşun kalem, silgi, çizgili defter vb. çok satılan ürünleri buraya ekleyin: <b>＋ Ekle</b>.',
    quickChips: [1, 5, 10],
    namePlaceholder: 'Örn: A4 Fotokopi Kağıdı 80g (500lü)',
    barcodePlaceholder: 'Barkod veya ISBN Kodu'
  },
  petshop: {
    id: 'petshop',
    name: 'Petshop & Akvaryum',
    icon: '🐕',
    sub: 'PETSHOP & EVCİL HAYVAN',
    color: '#ea580c',
    defaultKdv: 20,
    units: ['adet', 'paket', 'kg', 'gram'],
    defaultUnit: 'adet',
    fields: ['expiry', 'petType', 'scale'],
    sampleCats: ['Kedi Kuru Mama & Konserve', 'Köpek Maması & Ödüller', 'Kedi Kumu & Hijyen', 'Kuş Yemi & Kafesler', 'Akvaryum & Balık Yemleri', 'Tasma & Kıyafet', 'Bakım & Sağlık'],
    quickHint: 'Kedi ödül maması, yaş mama, kedi kumu, kuş yemi vb. çok satılan ürünleri buraya ekleyin: <b>＋ Ekle</b>.',
    quickChips: [1, 2, 5],
    namePlaceholder: 'Örn: Somonlu Kısır Kedi Maması 1.5kg',
    barcodePlaceholder: 'Barkod okutun veya ürün kodu yazın'
  },
  telefon: {
    id: 'telefon',
    name: 'Telefon & Teknik Servis',
    icon: '📱',
    sub: 'TEKNİK SERVİS & AKSESUAR',
    color: '#4f46e5',
    defaultKdv: 20,
    units: ['adet', 'hizmet', 'paket'],
    defaultUnit: 'adet',
    fields: ['imei', 'serial', 'deviceModel', 'warranty'],
    sampleCats: ['Akıllı Telefonlar', 'Kılıf & Kapaklar', 'Ekran Koruyucu Camlar', 'Şarj Başlığı & Kablolar', 'Kulaklık & Hoparlör', 'Teknik Servis & Tamir', 'Yedek Parça & Ekran'],
    quickHint: 'Ekran koruyucu cam, şarj kablosu, adaptör, kılıf vb. çok satılan ürünleri buraya ekleyin: <b>＋ Ekle</b>.',
    quickChips: [1, 2, 3],
    namePlaceholder: 'Örn: iPhone 15 Pro Hayalet Ekran Koruyucu',
    barcodePlaceholder: 'Barkod / IMEI / Seri No'
  },
  parfumeri: {
    id: 'parfumeri',
    name: 'Kozmetik & Parfümeri',
    icon: '💄',
    sub: 'KOZMETİK & PARFÜMERİ',
    color: '#ec4899',
    defaultKdv: 20,
    units: ['adet', 'şişe', 'kutu', 'ml'],
    defaultUnit: 'adet',
    fields: ['volumeMl', 'shadeColor', 'brand'],
    sampleCats: ['Erkek & Kadın Parfümleri', 'Makyaj & Fondöten & Maskara', 'Cilt Bakımı & Serumlar', 'Saç Bakımı & Şampuanlar', 'Güneş & Vücut Losyonları', 'Oje & Manikür', 'Kişisel Bakım'],
    quickHint: 'Ruj, oje, aseton, kolonya, el kremi, mini parfüm vb. çok satılan ürünleri buraya ekleyin: <b>＋ Ekle</b>.',
    quickChips: [1, 2, 3],
    namePlaceholder: 'Örn: Chanel No 5 EDP 100ml',
    barcodePlaceholder: 'Barkod okutun veya ürün kodu yazın'
  },
  kafe: {
    id: 'kafe',
    name: 'Kafe, Fırın & Pastane',
    icon: '☕',
    sub: 'KAFE & FIRIN & PASTANE',
    color: '#b45309',
    defaultKdv: 10,
    units: ['porsiyon', 'adet', 'dilim', 'bardak', 'fincan', 'kg'],
    defaultUnit: 'porsiyon',
    fields: ['tableNote', 'portion'],
    sampleCats: ['Sıcak Kahveler & Espresso', 'Soğuk Kahveler & Frappe', 'Meşrubat & Taze İçecekler', 'Pasta & Tatlı Çeşitleri', 'Börek & Poğaça & Simit', 'Kahvaltı Tabakları & Tost', 'Çay & Bitki Çayları'],
    quickHint: 'Çay, Türk kahvesi, su, soda, simit, tost, kurabiye vb. çok satılan ürünleri buraya ekleyin: <b>＋ Ekle</b>.',
    quickChips: [1, 2, 5],
    namePlaceholder: 'Örn: Sıcak Latte / Kruvasan',
    barcodePlaceholder: 'Menü / Ürün Kodu'
  },
  genel: {
    id: 'genel',
    name: 'Genel Ticari İşletme',
    icon: '🏢',
    sub: 'TİCARİ İŞLETME YÖNETİMİ',
    color: '#2563eb',
    defaultKdv: 20,
    units: ['adet', 'paket', 'koli', 'kg', 'metre', 'takım'],
    defaultUnit: 'adet',
    fields: ['rack', 'brand'],
    sampleCats: ['Genel Ticari Ürünler', 'Hızlı Satış Malları', 'Hizmetler', 'Sarf Malzemeleri'],
    quickHint: 'Sık satılan hızlı ürünleri buraya ekleyin: <b>＋ Ekle</b>.',
    quickChips: [1, 2, 5],
    namePlaceholder: 'Örn: Satış Ürünü Adı',
    barcodePlaceholder: 'Barkod okutun veya ürün kodu yazın'
  },
  all: {
    id: 'all',
    name: '⭐ Tüm Sektörler (Ultra Pro)',
    icon: '💎',
    sub: 'EVRENSEL TİCARİ PLATFORM',
    color: '#7c3aed',
    defaultKdv: 20,
    units: ['adet', 'metre', 'kg', 'gram', 'litre', 'paket', 'koli', 'çift', 'takım', 'porsiyon', 'dilim', 'düzine'],
    defaultUnit: 'adet',
    fields: ['scale', 'plu', 'variants', 'sizes', 'colors', 'imei', 'isbn', 'rack', 'brand', 'expiry', 'roll'],
    sampleCats: ['Genel Ürünler', 'Gıda & Şarküteri', 'Tekstil & Giyim', 'Elektronik & Aksesuar', 'Hırdavat & Yapı'],
    quickHint: 'Sık satılan hızlı ürünleri buraya ekleyin: <b>＋ Ekle</b>.',
    quickChips: [1, 2, 5],
    namePlaceholder: 'Örn: Satış Ürünü Adı',
    barcodePlaceholder: 'Barkod okutun veya ürün kodu yazın'
  }
};

function getActiveSectorKey(){
  const lic = S.license;
  if(lic && lic.sector && lic.sector !== 'all') {
    return lic.sector;
  }
  if(lic && lic.sector === 'all' && S.settings && S.settings.activeSector) {
    return S.settings.activeSector;
  }
  if(lic && lic.sector) return lic.sector;
  const cached = localStorage.getItem('msg_active_sector') || sessionStorage.getItem('msg_active_sector');
  if(cached && SECTORS[cached]) return cached;
  return 'sarkuteri';
}

function getActiveSector(){
  const k = getActiveSectorKey();
  return SECTORS[k] || SECTORS.sarkuteri || SECTORS.market || SECTORS.hirdavat;
}

/* ---------- Durum ve Sunucu Bağlantısı ---------- */
let S={products:[],customers:[],sales:[],expenses:[],payments:[],quick:[],users:[],seq:{sale:0},settings:{shop:'MSG YAZILIM',creditDays:15,defMin:5},v:0,me:{role:'cashier',name:''}};
let TOKEN=sessionStorage.getItem('msg_token')||sessionStorage.getItem('hrd_token'), es=null;
localStorage.removeItem('cc_token'); // Eski kalıcı oturumu temizle
const isAdmin=()=>S.me.role==='admin';

function cleanPhoneForWa(p){
  let s = String(p||'').replace(/\D/g, '');
  if(s.startsWith('0')) s = '9' + s;
  else if(!s.startsWith('90') && s.length === 10) s = '90' + s;
  return s;
}

async function api(path,opt={}){
  const r=await fetch(path,{...opt,headers:{'Content-Type':'application/json','X-Token':TOKEN||'',...(opt.headers||{})}});
  if(r.status===401&&TOKEN){sessionStorage.removeItem('msg_token');sessionStorage.removeItem('hrd_token');localStorage.removeItem('cc_token');location.reload();throw new Error('auth')}
  return r.json();
}

function updateShopBranding(){
  const sec = getActiveSector();
  const name = S.settings.shop || 'İşletme';
  const parts = name.trim().split(/\s+/);
  const b1 = parts[0] || 'İŞLETME';
  const b2 = parts.slice(1).join(' ') || sec.sub;
  
  if($('#brandName')) $('#brandName').textContent = b1;
  if($('#brandSub')) $('#brandSub').textContent = b2;
  if($('#sideFootShop')) $('#sideFootShop').textContent = name + ' (' + sec.name + ')';
  
  // Sol üst logo ikonunu sektör ikonuna çevir
  const logoEl = document.querySelector('.brand .logo');
  if(logoEl) logoEl.textContent = sec.icon;

  document.title = (document.title.startsWith('(') ? document.title.split(') ')[0] + ') ' : '') + name + ' - ' + sec.name;

  updBadge();
  updateLicenseBadge();
}

function updateLicenseBadge(){
  const b=$('#licBadge');if(!b)return;
  const lic=S.license;
  const sec=getActiveSector();
  if(!lic||!lic.valid){
    b.style.display='inline-flex';
    b.className='tag t-bad';
    b.innerHTML='🔒 Lisanssız';
    showLicenseModal(lic?lic.error:'Lisans aktivasyonu gereklidir.');
    return;
  }
  hideLicenseModal();
  b.style.display='inline-flex';
  let badgeTxt = '';
  if(!lic.exp||lic.exp===0){
    b.className='tag t-ok';
    badgeTxt = `${sec.icon} ${sec.name} • ⭐ Sınırsız`;
    b.title=`Lisans: Sınırsız (Ömür Boyu) - Sektör: ${sec.name}`;
  }else{
    const left=lic.daysLeft||0;
    if(left>14){b.className='tag t-ok';badgeTxt=`${sec.icon} ${sec.name} • 🔑 ${left} Gün`;}
    else if(left>3){b.className='tag t-warn';badgeTxt=`${sec.icon} ${sec.name} • ⚠️ ${left} Gün`;}
    else{b.className='tag t-bad';badgeTxt=`${sec.icon} ${sec.name} • 🚨 ${left} Gün`;}
    b.title=`Lisans Bitiş: ${new Date(lic.exp).toLocaleDateString('tr-TR')} - Sektör: ${sec.name}`;
  }
  b.innerHTML=badgeTxt;
}

function showLicenseModal(msg){
  const modalBg=$('#licModalBg'), modal=$('#licModal');
  if(!modalBg||!modal)return;
  const lic = S.license;
  const mid = (lic && lic.mid) || 'LÜTFEN BEKLEYİN...';
  const isExp = lic && lic.expired;
  const title = isExp ? '⏳ Lisans Süreniz Sona Erdi' : '🔒 MSG YAZILIM - Lisans Aktivasyonu';
  const sub = isExp ? 'Kullanım süreniz dolmuştur. Verileriniz %100 güvendedir.' : 'Bu sistem donanıma bağlı kriptografik lisans ile korunmaktadır.';
  const waText = encodeURIComponent(`Merhaba, MSG YAZILIM Sistemi için lisans almak istiyorum.\n\nDonanım Kimliğim (Machine ID):\n${mid}`);
  const bk = S.backupInfo || (lic && lic.backupInfo);

  modal.innerHTML=`
    <div class="lic-box" style="max-width:520px;padding:18px 22px">
      <div class="lic-icon">${isExp ? '⏳' : '🛡️'}</div>
      <h2 style="margin:0 0 6px;color:var(--navy);font-size:22px">${title}</h2>
      <p style="color:#64748b;font-size:13px;margin:0 0 10px">${sub}</p>

      <div style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:10px;padding:8px 12px;font-size:12px;color:#334155;margin-bottom:12px;line-height:1.4">
        🛡️ <b>Veri Güvenliği Garantisi:</b> Stoklarınız, müşteri hesaplarınız (veresiye) ve satış geçmişiniz asla silinmez ve güvenle korunur.
      </div>

      <!-- WhatsApp Lisans Alma Kutusu -->
      <div class="lic-wa-box">
        <div style="font-size:12px;font-weight:700;color:#065f46;margin-bottom:6px">
          💬 LİSANS ALMAK VEYA SÜRE UZATMAK İÇİN:
        </div>
        <a href="https://wa.me/905061104563?text=${waText}" target="_blank" class="lic-wa-btn">
          <span style="font-size:24px">📱</span>
          <span style="text-align:left">
            <span style="display:block;font-size:15px;font-weight:800">WhatsApp: 0506 110 45 63</span>
            <small style="font-size:11px;opacity:0.95">Donanım kimliğinizle doğrudan mesaj atmak için tıklayınız</small>
          </span>
        </a>
      </div>
      
      <div style="text-align:left;margin-bottom:6px">
        <label style="font-weight:700;color:#334155;font-size:12px">CİHAZ DONANIM KİMLİĞİNİZ (MACHINE ID):</label>
        <div class="lic-mid-box">
          <span class="lic-mid-code" id="txtMidVal">${mid}</span>
          <button class="btn sm or" type="button" onclick="navigator.clipboard.writeText('${mid}');toast('Donanım Kimliği kopyalandı!','ok')">📋 Kopyala</button>
        </div>
      </div>

      <div style="text-align:left;margin-bottom:12px">
        <label style="font-weight:700;color:#334155;font-size:12px">LİSANS ANAHTARI:</label>
        <textarea id="licKeyInput" class="lic-textarea" placeholder="Yöneticinizden (0506 110 45 63) aldığınız lisans anahtarını buraya yapıştırın..."></textarea>
      </div>

      ${msg?`<div style="background:#fee2e2;color:#991b1b;padding:8px 12px;border-radius:8px;font-size:12px;font-weight:600;margin-bottom:12px">${msg}</div>`:''}

      <button class="btn or lg" type="button" style="width:100%;border-radius:12px;font-weight:800;font-size:16px" onclick="activateLicenseSubmit()">
        🚀 SİSTEMİ ETKİNLEŞTİR
      </button>

      ${bk && bk.exists ? `
        <div class="lic-bk-restore-box">
          <div style="font-size:12px;font-weight:700;color:#1e40af;margin-bottom:4px">
            💡 Bu bilgisayarda önceki kurulumdan kalan otomatik yedek bulundu!
          </div>
          <div style="font-size:11.5px;color:#475569;margin-bottom:8px">
            İşletme: <b>${h(bk.shopName || 'Hırdavat')}</b> | ${bk.productsCount} Ürün, ${bk.customersCount} Müşteri, ${bk.salesCount} Satış (${bk.dateStr})
          </div>
          <button class="btn sm ok" type="button" style="width:100%;font-weight:700" onclick="restoreExternalBackup()">
            📥 Eski Stok ve Verileri Geri Yükle
          </button>
        </div>
      ` : ''}
    </div>
  `;
  modalBg.style.display='grid';
}

function hideLicenseModal(){
  const modalBg=$('#licModalBg');
  if(modalBg)modalBg.style.display='none';
}

async function activateLicenseSubmit(){
  const input=$('#licKeyInput');if(!input)return;
  const key=input.value.trim();
  if(!key){toast('Lütfen lisans anahtarını yapıştırınız!','err');return;}
  try{
    const res=await fetch('/api/license/activate',{
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body:JSON.stringify({key})
    });
    const data=await res.json();
    if(data.ok){
      toast('Lisans başarıyla etkinleştirildi! Sistem açılıyor...','ok');
      S.license=data.license;
      hideLicenseModal();
      updateLicenseBadge();
      setTimeout(()=>location.reload(),800);
    }else{
      toast('Hata: '+(data.error||'Geçersiz lisans anahtarı'),'err');
    }
  }catch(e){
    toast('Bağlantı hatası: '+e.message,'err');
  }
}

async function restoreExternalBackup(){
  if(!confirm("Otomatik korumalı yedek sisteme yüklensin mi?\nStoklarınız, carileriniz ve satışlarınız geri gelecektir.")) return;
  try{
    const res = await fetch('/api/backup/restore-external', { method: 'POST' });
    const data = await res.json();
    if(data.ok){
      toast(`✅ Yedek başarıyla geri yüklendi! (${data.productsCount} ürün, ${data.customersCount} cari, ${data.salesCount} satış)`, 'ok');
      setTimeout(()=>location.reload(), 1200);
    }else{
      toast('Geri yükleme hatası: ' + (data.error || 'Hata oluştu'), 'err');
    }
  }catch(e){
    toast('Sunucu hatası: ' + e.message, 'err');
  }
}

function applyState(st){
  if(!st)return;
  if(st.v>=S.v||!S.v){
    S=Object.assign(S,st);
    updateShopBranding();
    onlineUI();
  }
}

async function cmd(t,p={}){
  try{
    const r=await api('/api/cmd',{method:'POST',body:JSON.stringify({t,p})});
    if(r.state)applyState(r.state);
    if(r.error){toast(r.error,'err');return null}
    return r;
  }catch(e){
    if(e.message!=='auth')toast('Sunucuya ulaşılamıyor! Bağlantıyı kontrol edin.','err');
    return null;
  }
}

async function syncState(){
  try{applyState(await api('/api/state'));refreshView()}catch(e){}
}

function onlineUI(on=true){
  const o=$('#online');if(!o)return;
  o.className='tag '+(on?'t-ok':'t-bad');
  o.textContent=on?`🟢 Bağlı • ${S.online||1} cihaz`:'🔴 Bağlantı yok';
}

function connectSSE(){
  if(es)es.close();
  es=new EventSource('/api/events?token='+(TOKEN||''));
  es.addEventListener('v',e=>{
    try{
      const d=JSON.parse(e.data);
      S.online=d.online;
      onlineUI(true);
      if(d.v!==S.v)syncState();
    }catch(err){}
  });
  es.onopen=()=>{onlineUI(true);syncState()};
  es.onerror=()=>onlineUI(false);
}

function refreshView(){
  updateShopBranding();
  if(!$('#modalBg').hidden)return;
  const r=curRoute();
  if(r==='pos'){drawGrid();drawQuick();drawCart();return}
  const a=document.activeElement;if(a&&['INPUT','SELECT','TEXTAREA'].includes(a.tagName))return;
  route();
}

/* ---------- Kullanıcı Girişi ---------- */
async function showLogin(){
  let us=[];
  let shopName = S.settings?.shop || 'MSG YAZILIM';
  if(shopName === 'Hırdavat') shopName = 'MSG YAZILIM';
  try{
    const res=await (await fetch('/api/users')).json();
    if(res){
      if(Array.isArray(res)){
        us=res;
      } else if(res.users){
        us=res.users;
        if(res.shop && res.shop !== 'Hırdavat'){
          shopName=res.shop;
          S.settings = S.settings || {};
          S.settings.shop=res.shop;
        }
        if(res.license){
          S.license = res.license;
        }
        if(res.sector){
          localStorage.setItem('msg_active_sector', res.sector);
          sessionStorage.setItem('msg_active_sector', res.sector);
          if(!S.license) S.license = { sector: res.sector, secName: res.secName, valid: true };
        }
      }
    }
  }catch(e){}

  const sec = getActiveSector();

  const L=$('#login');L.hidden=false;
  L.innerHTML=`<div class="box" style="text-align:center">
  <div style="margin-bottom:12px">
    <img src="/logo.png" alt="MSG YAZILIM" style="max-width:220px;width:100%;height:auto;border-radius:14px;box-shadow:0 8px 24px rgba(0,0,0,0.25);display:block;margin:0 auto">
  </div>
  <h2 style="margin:6px 0 0;font-size:20px;color:var(--navy)" id="loginShopTitle">${h(shopName)}</h2>
  <p class="mut" style="margin:0 0 14px;font-size:13px">${sec.icon} ${h(sec.name)} • Kullanıcı Girişi</p>
  <select id="lu">${(us.length?us:[{id:'admin',name:'Yönetici'}]).map(u=>`<option value="${u.id}">${h(u.name)}</option>`).join('')}</select>
  <input id="lp" type="password" inputmode="numeric" maxlength="8" placeholder="PIN" autocomplete="off">
  <div class="err" id="lerr"></div><button class="btn or lg" style="width:100%" onclick="doLogin()">Giriş Yap</button></div>`;
  $('#lp').addEventListener('keydown',e=>{if(e.key==='Enter')doLogin()});
  $('#lp').focus();
}

async function doLogin(){
  try{
    const r=await fetch('/api/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id:$('#lu').value,pin:$('#lp').value})});
    const j=await r.json();
    if(j.token){
      TOKEN=j.token;
      sessionStorage.setItem('msg_token',TOKEN);
      sessionStorage.setItem('hrd_token',TOKEN);
      localStorage.removeItem('cc_token');
      $('#login').hidden=true;
      boot();
    }
    else{$('#lerr').textContent=j.error||'Hata';$('#lp').value='';$('#lp').focus()}
  }catch(e){$('#lerr').textContent='Sunucu bağlantı hatası'}
}

async function logout(){
  try{await api('/api/logout',{method:'POST'})}catch(e){}
  sessionStorage.removeItem('msg_token');
  sessionStorage.removeItem('hrd_token');
  localStorage.removeItem('cc_token');
  location.reload();
}

function userMenu(){
  modal(`<h2>👤 ${h(S.me.name||'Kullanıcı')} <small class="mut">(${isAdmin()?'Yönetici':'Kasiyer'})</small></h2>
  <h3>PIN Değiştir</h3><div class="row"><div class="f"><label>Eski PIN</label><input id="pn_o" type="password" inputmode="numeric"></div><div class="f"><label>Yeni PIN (4-8 rakam)</label><input id="pn_n" type="password" inputmode="numeric"></div></div>
  <div class="mfoot"><button class="btn rd" onclick="logout()">Çıkış Yap</button><button class="btn or" onclick="changePin()">PIN'i Değiştir</button></div>`);
}

async function changePin(){
  if(await cmd('pinChange',{old:$('#pn_o').value,pin:$('#pn_n').value})){closeModal();toast('PIN değiştirildi','ok')}
}

/* ---------- Code128 Barkod Oluşturucu ---------- */
const C128=["212222","222122","222221","121223","121322","131222","122213","122312","132212","221213","221312","231212","112232","122132","122231","113222","123122","123221","223211","221132","221231","213212","223112","312131","311222","321122","321221","312212","322112","322211","212123","212321","232121","111323","131123","131321","112313","132113","132311","211313","231113","231311","112133","112331","132131","113123","113321","133121","313121","211331","231131","213113","213311","213131","311123","311321","331121","312113","312311","332111","314111","221411","431111","111224","111422","121124","121421","141122","141221","112214","112412","122114","122411","142112","142211","241211","221114","413111","241112","134111","111242","121142","121241","114212","124112","124211","411212","421112","421211","212141","214121","412121","111143","111341","131141","114113","114311","411113","411311","113141","114131","311141","411131","211412","211214","211232","2331112"];
function code128(text){
  text=String(text).replace(/[^\x20-\x7e]/g,'');
  const codes=[104];let sum=104;
  [...text].forEach((c,i)=>{const v=c.charCodeAt(0)-32;codes.push(v);sum+=v*(i+1)});
  codes.push(sum%103);codes.push(106);
  return codes.map(c=>C128[c]).join('');
}
function barcodeSVG(text,o={}){
  const mod=o.mod||2,ht=o.h||60,q=10*mod;
  const pat=code128(text);let x=q,rects='',bar=true;
  for(const ch of pat){const w=+ch*mod;if(bar)rects+=`<rect x="${x}" y="0" width="${w}" height="${ht}"/>`;x+=w;bar=!bar}
  const W=x+q,H=ht+(o.text===false?0:18);
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${W} ${H}" width="${o.w||W}" fill="#000"><rect width="${W}" height="${H}" fill="#fff"/>${rects}${o.text===false?'':`<text x="${W/2}" y="${ht+14}" font-size="14" font-family="monospace" text-anchor="middle">${h(text)}</text>`}</svg>`;
}
function genBarcode(){
  let b;
  do{b='28'+String(Math.floor(Math.random()*1e10)).padStart(10,'0')}
  while(S.products.some(p=>p.barcode===b));
  return b;
}

/* ---------- Genel Yardımcılar ---------- */
function toast(m,t=''){
  const d=document.createElement('div');
  d.className=t;d.textContent=m;
  $('#toast').appendChild(d);
  setTimeout(()=>d.remove(),3200);
}

/* Pencere sadece ✕ / İptal ile kapanır; boşluğa tıklanınca kaybolmaz */
function modal(html,wide){
  $('#modal').className=wide?'wide':'';
  $('#modal').innerHTML=`<button class="mclose" onclick="closeModal()" title="Kapat">✕</button>`+html;
  $('#modalBg').hidden=false;
}
function closeModal(){
  closeCamModal();
  $('#modalBg').hidden=true;
  $('#modal').innerHTML='';
}

const unitOf=p=>{
  if(!p||!p.unit) return 'adet';
  const u=String(p.unit).toLowerCase().trim();
  if(u==='metre') return 'm';
  if(u==='kg'||u==='kilogram') return 'kg';
  if(u==='gram'||u==='gr') return 'gr';
  if(u==='litre'||u==='lt') return 'lt';
  if(u==='porsiyon') return 'prs';
  if(u==='dilim') return 'dlm';
  if(u==='koli') return 'koli';
  if(u==='paket') return 'pkt';
  if(u==='cift'||u==='çift') return 'çift';
  if(u==='takim'||u==='takım') return 'tk';
  if(u==='duzine'||u==='düzine') return 'dz';
  if(u==='hizmet') return 'hizmet';
  if(u==='ml') return 'ml';
  return u;
};
const stockOf=p=>`${num(p.stock)} ${unitOf(p)}`;
const isLow=p=>p.stock<=(p.min??S.settings.defMin);
const findP=id=>S.products.find(p=>p.id===id);

function printHTML(body,title='Yazdır'){
  const w=window.open('','_blank','width=900,height=700');
  if(!w){toast('Açılır pencere engellendi, tarayıcıdan izin verin','err');return}
  w.document.write(`<html><head><meta charset="utf-8"><title>${h(title)}</title>
  <style>
    @page { margin: 0; }
    body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Arial, sans-serif; margin: 10px; color: #000; }
    table { width: 100%; border-collapse: collapse; }
    td, th { padding: 4px; text-align: left; }
    .r { text-align: right; }
    .lab { display: inline-block; border: 1px dashed #999; padding: 6px; margin: 4px; text-align: center; width: 230px; page-break-inside: avoid; }
    .lab b { display: block; font-size: 12px; }
    .lab svg { width: 100%; height: auto; }
    @media print {
      body { margin: 4mm 2mm; }
      .no-print { display: none !important; }
    }
  </style></head><body>${body}<script>onload=()=>setTimeout(()=>{window.print();},350)<\/script></body></html>`);
  w.document.close();
}

function resizeImage(file,max=420){
  return new Promise(res=>{
    const r=new FileReader();
    r.onload=()=>{
      const im=new Image();
      im.onload=()=>{
        const k=Math.min(1,max/Math.max(im.width,im.height));
        const c=document.createElement('canvas');
        c.width=im.width*k;c.height=im.height*k;
        c.getContext('2d').drawImage(im,0,0,c.width,c.height);
        res(c.toDataURL('image/jpeg',0.82));
      };
      im.src=r.result;
    };
    r.readAsDataURL(file);
  });
}

function beep(ok){
  try{
    const a=new AudioContext(),o=a.createOscillator();
    o.frequency.value=ok?1050:240;
    o.connect(a.destination);o.start();
    setTimeout(()=>{o.stop();a.close()},ok?90:300);
  }catch(e){}
}

/* ---------- Veresiye ve Alacak Hesapları (Güncel Fiyat Endeksli) ---------- */
function creditRows(cid){
  let paid=S.payments.filter(p=>p.customerId===cid).reduce((a,p)=>a+p.amount,0);
  return S.sales.filter(s=>!s.void&&s.method==='veresiye'&&s.customerId===cid).sort((a,b)=>a.date.localeCompare(b.date)).map(s=>{
    let priceDiff=0;
    const itemsDetail=s.items.map(i=>{
      const p=findP(i.pid);
      const curUnitPrice=p?(i.mode==='roll'?(p.rollPrice||p.price):p.price):i.price;
      const effectiveUnitPrice=Math.max(i.price,curUnitPrice);
      const increased=curUnitPrice>i.price+0.001;
      const lineDiff=round2(i.qty*(effectiveUnitPrice-i.price));
      priceDiff+=lineDiff;
      return{
        ...i,
        origPrice:i.price,
        curPrice:curUnitPrice,
        effectivePrice:effectiveUnitPrice,
        increased,
        diffPerUnit:round2(effectiveUnitPrice-i.price),
        origTotal:round2(i.qty*i.price),
        curTotal:round2(i.qty*effectiveUnitPrice),
        lineDiff
      };
    });

    priceDiff=round2(priceDiff);
    const effectiveTotal=round2(s.total+priceDiff);
    const a=Math.min(paid,effectiveTotal);
    paid-=a;
    const rem=round2(effectiveTotal-a);

    return{
      s,
      origTotal:s.total,
      curTotal:effectiveTotal,
      priceDiff,
      hasIncrease:priceDiff>0.01,
      rem,
      late:rem>0.005&&new Date(s.dueDate)<new Date(),
      itemsDetail
    };
  });
}
const balanceOf=cid=>round2(creditRows(cid).reduce((a,r)=>a+r.rem,0));
const origBalanceOf=cid=>round2(creditRows(cid).reduce((a,r)=>a+Math.max(0,r.origTotal-(r.curTotal-r.rem)),0));

function overdueList(){
  const out=[];
  S.customers.forEach(c=>creditRows(c.id).filter(r=>r.late).forEach(r=>out.push({c,...r,days:Math.floor((Date.now()-new Date(r.s.dueDate))/864e5)})));
  return out;
}

function notifications(){
  const n=[];
  overdueList().forEach(o=>n.push({ic:'⏰',t:`Geciken ödeme: ${o.c.name}`,d:`${money(o.rem)} • Fiş #${o.s.no} • ${o.days} gün gecikti`,go:'customers'}));
  S.products.filter(isLow).forEach(p=>n.push({ic:p.stock<=0?'🚫':'⚠️',t:p.stock<=0?`Stok tükendi: ${p.name}`:`Stok azaldı: ${p.name}`,d:`Kalan: ${stockOf(p)} (alarm sınırı ${num(p.min??S.settings.defMin)})`,go:'products'}));
  return n;
}

function updBadge(){
  const n=notifications().length;
  const b=$('#badge');if(b){b.hidden=!n;b.textContent=n}
  const sec=getActiveSector();
  document.title=(n?`(${n}) `:'')+(S.settings?.shop||'MSG YAZILIM') + ' - ' + (sec?.name || 'Ticari Sistem');
  if($('#userBtn')) $('#userBtn').textContent='👤 '+(S.me.name||'Kullanıcı');
}

function toggleNotif(){
  const p=$('#notifPanel');if(!p.hidden){p.hidden=true;return}
  const n=notifications();
  p.innerHTML=`<div style="padding:8px 10px;font-weight:700">Bildirimler (${n.length})</div>`+(n.length?n.map(x=>`<div class="nitem" onclick="go('${x.go}')"><div class="ic">${x.ic}</div><div><b>${h(x.t)}</b><small>${h(x.d)}</small></div></div>`).join(''):'<div class="mut" style="padding:20px;text-align:center">Her şey yolunda ✅</div>');
  p.hidden=false;
}
function go(r){$('#notifPanel').hidden=true;location.hash='#'+r}

/* ---------- Sayfa Yönlendirmesi ---------- */
const PAGES=[['dashboard','📊','Ana Sayfa',1],['pos','🛒','Satış (Kasa)'],['products','📦','Ürünler / Stok'],['barcodes','🏷️','Barkod Oluştur'],['customers','👥','Veresiye / Müşteriler'],['sales','🧾','Satış Geçmişi'],['expenses','💸','Giderler',1],['reports','📈','Gelir-Gider / Muhasebe',1],['settings','⚙️','Ayarlar / Kullanıcılar',1]];
const curRoute=()=>{const r=(location.hash||'').slice(1);const pg=PAGES.find(p=>p[0]===r&&(!p[3]||isAdmin()));return pg?pg[0]:(isAdmin()?'dashboard':'pos')};

function route(){
  const r=curRoute(),pg=PAGES.find(p=>p[0]===r);
  document.body.classList.remove('menu');
  $('#nav').innerHTML=PAGES.filter(p=>!p[3]||isAdmin()).map(p=>`<a class="${p[0]===r?'on':''}" href="#${p[0]}">${p[1]} ${p[2]}</a>`).join('');
  $('#title').textContent=pg[2];
  document.removeEventListener('keydown',window._posKey||(()=>{}));
  if(r!=='pos'){document.body.classList.remove('posfull');if(document.fullscreenElement)document.exitFullscreen().catch(()=>{})}
  
  /* Mobil alt bar aktif öğe güncellemesi */
  const bnavMap={pos:'bnav-pos',products:'bnav-products',customers:'bnav-customers',sales:'bnav-sales'};
  document.querySelectorAll('.bnav-item').forEach(el=>el.classList.remove('on'));
  if(bnavMap[r]){
    const el=$('#'+bnavMap[r]);
    if(el) el.classList.add('on');
  }

  ({dashboard:pDash,pos:pPos,products:pProducts,barcodes:pBarcodes,customers:pCust,sales:pSales,expenses:pExp,reports:pRep,settings:pSet})[r]();
  updBadge();
}
window.addEventListener('hashchange',route);
setInterval(()=>{$('#clock').textContent=new Date().toLocaleString('tr-TR')},1000);

/* ==========================================================================
   SATIŞ (KASA) - ÇOKLU SEPET & KALICI SEPET HAFIZASI (PERSISTENCE)
   ========================================================================== */
let carts=[{id:1,name:'Sepet 1',items:[],discount:0,cust:'',due:'',method:'nakit',given:''}];
let activeCartIdx=0;
let posCat='',quickEdit=false,busy=false,lastPid=null;

function saveCarts(){
  try{
    localStorage.setItem('hrd_pos_carts', JSON.stringify(carts));
    localStorage.setItem('hrd_pos_active_cart', String(activeCartIdx));
  }catch(e){}
}

function loadCarts(){
  try{
    const saved=localStorage.getItem('hrd_pos_carts');
    if(saved){
      const parsed=JSON.parse(saved);
      if(Array.isArray(parsed)&&parsed.length){
        carts=parsed;
        const savedIdx=parseInt(localStorage.getItem('hrd_pos_active_cart'),10);
        activeCartIdx=(!isNaN(savedIdx)&&savedIdx>=0&&savedIdx<carts.length)?savedIdx:0;
        return;
      }
    }
  }catch(e){}
  carts=[{id:1,name:'Sepet 1',items:[],discount:0,cust:'',due:'',method:'nakit',given:''}];
  activeCartIdx=0;
}
loadCarts();

function curCart(){
  if(!carts[activeCartIdx]) activeCartIdx=0;
  return carts[activeCartIdx];
}

function addCartTab(){
  const maxId=carts.reduce((m,c)=>Math.max(m,c.id),0)||0;
  const newId=maxId+1;
  carts.push({id:newId,name:'Sepet '+newId,items:[],discount:0,cust:'',due:dkey(addDays(new Date(),S.settings.creditDays)),method:'nakit',given:''});
  activeCartIdx=carts.length-1;
  saveCarts();
  drawCart();
  toast('Yeni sepet açıldı: Sepet '+newId,'ok');
}

function switchCart(idx){
  if(idx>=0&&idx<carts.length){
    activeCartIdx=idx;
    lastPid=null;
    saveCarts();
    drawCart();
  }
}

function removeCart(idx,e){
  if(e)e.stopPropagation();
  if(carts.length<=1){
    const c=carts[0];
    c.items=[];c.discount=0;c.cust='';c.given='';lastPid=null;
    saveCarts();
    drawCart();
    toast('Sepet temizlendi','ok');
    return;
  }
  const c=carts[idx];
  if(c.items.length>0&&!confirm(`"${c.name}" içinde ${c.items.length} kalem ürün var. Bu sepet kapatılsın mı?`))return;
  carts.splice(idx,1);
  if(activeCartIdx>=carts.length) activeCartIdx=carts.length-1;
  lastPid=null;
  saveCarts();
  drawCart();
  toast('Sepet kapatıldı','ok');
}

function removeCartItem(idx){
  const c=curCart();
  if(c&&c.items&&c.items[idx]!==undefined){
    const remName=findP(c.items[idx].pid)?.name||'Ürün';
    c.items.splice(idx,1);
    lastPid=null;
    saveCarts();
    drawCart();
    toast(`${remName} sepetten çıkarıldı`,'ok');
  }
}

function clearCurrentCart(){
  const c=curCart();
  if(!c||!c.items.length){
    toast('Sepet zaten boş','err');
    return;
  }
  if(confirm(`"${c.name}" içindeki tüm ürünler silinsin mi?`)){
    c.items=[];
    c.discount=0;
    c.cust='';
    c.given='';
    lastPid=null;
    saveCarts();
    drawCart();
    toast('Sepet tamamen boşaltıldı','ok');
  }
}

function parkCurrentCart(){
  const c=curCart();
  if(!c||!c.items.length){
    toast('Beklemeye alınacak ürün yok (sepet boş)','err');
    return;
  }
  const custName = c.cust ? (S.customers.find(x=>x.id===c.cust)?.name || '') : '';
  const defNote = custName ? `${custName} (Bekleyen)` : `Bekleyen (${c.items.length} ürün)`;
  const n = prompt('Bu sepeti beklemeye almak için bir müşteri veya not girin:', defNote);
  if(n === null) return; // İptal edildi
  c.name = (n && n.trim()) ? n.trim() : defNote;
  c.isParked = true;
  saveCarts();
  // Yeni temiz sepet aç veya boş bir sepete geç
  const emptyIdx = carts.findIndex((cartItem, idx) => idx !== activeCartIdx && !cartItem.items.length);
  if(emptyIdx !== -1){
    switchCart(emptyIdx);
  } else {
    addCartTab();
  }
  toast(`⏸️ Sepet beklemeye alındı: "${c.name}"`,'ok');
}

function parkCartModal(){
  const parkedCarts = carts.map((c, i) => ({cart: c, idx: i})).filter(x => x.cart.items.length > 0 && x.idx !== activeCartIdx);
  if(!parkedCarts.length){
    toast('Bekleyen başka sepet bulunmuyor','warn');
    return;
  }
  modal(`
    <div style="padding:10px 4px">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px;border-bottom:1px solid var(--line);padding-bottom:8px">
        <h3 style="margin:0;display:flex;align-items:center;gap:8px">⏸️ Bekleyen Sepetler (${parkedCarts.length})</h3>
        <button class="btn ln sm" onclick="closeModal()">✕</button>
      </div>
      <div style="display:flex;flex-direction:column;gap:8px;max-height:360px;overflow-y:auto">
        ${parkedCarts.map(x => {
          const sub = cartSub(x.cart);
          const cst = x.cart.cust ? (S.customers.find(u=>u.id===x.cart.cust)?.name||'') : '';
          return `<div style="display:flex;align-items:center;justify-content:space-between;background:#f8fafc;border:1px solid #e2e8f0;border-radius:10px;padding:10px 12px">
            <div>
              <b style="font-size:14px;color:var(--navy)">🛒 ${h(x.cart.name)}</b>
              ${cst ? `<small style="display:block;color:#64748b">Müşteri: ${h(cst)}</small>` : ''}
              <small style="display:block;color:#0284c7;font-weight:700">${x.cart.items.length} Kalem Ürün • ${money(sub)}</small>
            </div>
            <div style="display:flex;gap:6px">
              <button class="btn or sm" onclick="closeModal();switchCart(${x.idx})" style="padding:7px 12px;font-weight:700">▶ Sepete Dön</button>
              <button class="btn rd sm" onclick="closeModal();removeCart(${x.idx})" style="padding:7px 9px" title="Sil">✕</button>
            </div>
          </div>`;
        }).join('')}
      </div>
    </div>
  `);
}

function renameCart(idx,e){
  if(e)e.stopPropagation();
  const c=carts[idx];
  const n=prompt('Sepet için isim veya not girin (Örn: Müşteri adı, Plaka):',c.name);
  if(n&&n.trim()){
    c.name=n.trim();
    saveCarts();
    drawCart();
  }
}

let curMposTab='cart';
function switchMposTab(tab){
  curMposTab=tab;
  const pleft=document.querySelector('.pleft'), pright=document.querySelector('.pright');
  const btnCart=$('#mposTabCart'), btnProds=$('#mposTabProds');
  const floatBar=$('#mposFloatBar');
  if(!pleft||!pright) return;
  if(window.innerWidth<=1000){
    if(tab==='cart'){
      pleft.style.display='flex';
      pright.style.display='none';
      btnCart?.classList.add('on');
      btnProds?.classList.remove('on');
      if(floatBar) floatBar.style.display='none';
    }else{
      pleft.style.display='none';
      pright.style.display='flex';
      btnCart?.classList.remove('on');
      btnProds?.classList.add('on');
      if(floatBar) floatBar.style.display='flex';
    }
  }else{
    pleft.style.display='';
    pright.style.display='';
    if(floatBar) floatBar.style.display='none';
  }
}
window.addEventListener('resize',()=>{
  if(curRoute()==='pos') switchMposTab(curMposTab);
});

function pPos(){
  $('#view').innerHTML=`<div class="posx">
  <!-- Mobil Segment Butonları (Sepet & Kasa vs Hızlı Ürünler) -->
  <div class="mpos-switcher mobile-only">
    <button type="button" id="mposTabCart" class="mpos-tab-btn ${curMposTab==='cart'?'on':''}" onclick="switchMposTab('cart')">
      🛒 Sepet & Kasa <span class="mpos-badge" id="mposCountBadge">0</span>
    </button>
    <button type="button" id="mposTabProds" class="mpos-tab-btn ${curMposTab==='prods'?'on':''}" onclick="switchMposTab('prods')">
      📦 Hızlı Ürün Seçimi
    </button>
  </div>

  <div class="pleft">
    <!-- Üst Araçlar: Sepet Sekmeleri & Canlı Kasa Terazisi -->
    <div class="pos-top-tools">
      <div class="cart-tabs-bar" id="cartTabsBar"></div>
      <!-- Canlı Terazi Göstergesi (Barkod Kutusunu Ezmemesi İçin Üst Bara Taşındı) -->
      <div id="scaleWidget" class="scale-live-widget" onclick="toggleScaleSettingsModal()" title="Canlı Kasa Terazisi (Tıklayarak Ayarlayın / Test Edin)">
        <span class="scale-status-dot" id="scaleDot"></span>
        <span class="scale-icon-pulse">⚖️</span>
        <span class="scale-digits zero" id="scaleDigits">0.000 KG</span>
      </div>
    </div>

    <!-- Barkod Okuma ve Canlı Ürün Arama Bandı (Tam Genişlik & Ferah) -->
    <div class="scanbar-wrap">
      <div class="scanbar">
        <input id="scan" placeholder="Barkodu okutun veya ürün adı yazın..." autocomplete="off" autofocus>
        <button class="btn cam" type="button" onclick="openCamScan()" title="Kamerayla Oku">📷 <span class="hide-sm">Kamera</span></button>
        <button class="btn or" type="button" onclick="scanEnter()" title="Sepete Ekle">+ <span class="hide-sm">Ekle</span></button>
        <button class="btn ln hide-sm" type="button" onclick="openZReportModal()" title="Gün Sonu Kasa Raporu (Z Raporu)">📊 Z Raporu</button>
        <button class="btn ln hide-sm" type="button" onclick="togglePosFull()" title="Tam Ekran">⛶</button>
      </div>
      <!-- Canlı Arama Sonuçları / Öneriler Dropdown -->
      <div id="scanSuggest" class="scan-suggest" hidden></div>
    </div>

    <!-- Son Okutulan Ürün Kartı -->
    <div id="lastBox"></div>

    <!-- Sepet Ürün Tablosu -->
    <div class="cartwrap">
      <table class="ctable">
        <thead>
          <tr>
            <th class="hide-sm">#</th>
            <th>Ürün Adı / Barkod</th>
            <th class="c">Miktar</th>
            <th class="r hide-sm">Birim Fiyat</th>
            <th class="r">Tutar</th>
            <th class="c"><button class="btn sm rd" type="button" onclick="clearCurrentCart()" title="Sepetteki Tüm Ürünleri Boşalt" style="padding:2px 7px;font-size:11px">🗑️ Sil</button></th>
          </tr>
        </thead>
        <tbody id="cartBody"></tbody>
      </table>
    </div>

    <!-- Ödeme ve Kasa Paneli -->
    <div class="paypanel" id="payPanel"></div>
  </div>

  <div class="pright">
    <!-- Hızlı Ürünler Paneli -->
    <div class="card" style="padding:12px">
      <div class="qhead">
        <b>⚡ Hızlı Satış Tuşları</b>
        <span>
          <button class="btn ln sm" onclick="quickPick()">＋ Ekle</button>
          <button class="btn sm" id="qeBtn" onclick="quickEdit=!quickEdit;drawQuick()">✏️ Düzenle</button>
        </span>
      </div>
      <div id="qlist" class="qlist"></div>
    </div>

    <!-- Dokunmatik Ürün Kataloğu -->
    <div class="card" style="padding:12px">
      <div id="cats" class="cats"></div>
      <div id="pgrid" class="pgrid"></div>
    </div>
  </div>

  <!-- Mobil Hızlı Ürünler Açıkken Altta Kayan Mini Sepet & Kasaya Git Barı -->
  <div id="mposFloatBar" class="mpos-float-bar mobile-only" onclick="switchMposTab('cart')" style="display:none">
    <div class="mpos-float-info">
      <span style="font-size:22px">🛒</span>
      <div>
        <b id="mposFloatCount">0 Kalem Ürün</b>
        <small id="mposFloatTotal">0,00 ₺</small>
      </div>
    </div>
    <button type="button" class="btn or sm" style="font-weight:700;padding:8px 14px;border-radius:10px">Kasaya Git ➔</button>
  </div>
  </div>`;

  const sc=$('#scan');
  sc.addEventListener('keydown',e=>{
    const box=$('#scanSuggest');
    if(e.key==='ArrowDown'){
      if(box&&!box.hidden&&curSuggestMatches.length>0){
        e.preventDefault();
        curSuggestIdx=(curSuggestIdx+1)%curSuggestMatches.length;
        renderSuggestActive();
        return;
      }
    }
    if(e.key==='ArrowUp'){
      if(box&&!box.hidden&&curSuggestMatches.length>0){
        e.preventDefault();
        curSuggestIdx=(curSuggestIdx-1+curSuggestMatches.length)%curSuggestMatches.length;
        renderSuggestActive();
        return;
      }
    }
    if(e.key==='Escape'){
      if(box) box.hidden=true;
      return;
    }
    if(e.key==='Enter'){
      e.preventDefault();
      e.stopPropagation();
      if(box&&!box.hidden&&curSuggestIdx>=0&&curSuggestMatches[curSuggestIdx]){
        let mult=1;
        const starMatch=sc.value.trim().match(/^(\d+(?:[.,]\d+)?)\s*\*\s*/);
        if(starMatch) mult=parse(starMatch[1])||1;
        selectSuggestProduct(curSuggestMatches[curSuggestIdx].id,mult);
        return;
      }
      scanEnter();
    }
  });

  sc.addEventListener('input',()=>{
    updateScanSuggest();
    drawGrid();
  });

  sc.addEventListener('blur',()=>{
    setTimeout(()=>{
      const box=$('#scanSuggest');
      if(box) box.hidden=true;
    },220);
  });

  sc.addEventListener('focus',()=>{
    if(sc.value.trim()) updateScanSuggest();
  });

  window._posKey=e=>{
    if(e.key==='F2'){e.preventDefault();$('#scan')?.focus()}
    if(e.key==='F9'){e.preventDefault();checkout()}
  };
  document.addEventListener('keydown',window._posKey);

  drawGrid();
  drawQuick();
  drawCart();
  switchMposTab(curMposTab);
  sc.focus();
}

let curSuggestMatches=[];
let curSuggestIdx=-1;

function highlightMatch(text,query){
  if(!query) return h(text);
  const safe=query.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
  const parts=String(text).split(new RegExp(`(${safe})`,'gi'));
  return parts.map(p=>p.toLowerCase()===query.toLowerCase()?`<mark>${h(p)}</mark>`:h(p)).join('');
}

function updateScanSuggest(){
  const sc=$('#scan');
  const box=$('#scanSuggest');
  if(!sc||!box) return;
  const q=sc.value.trim();
  if(!q){
    box.hidden=true;
    box.innerHTML='';
    curSuggestMatches=[];
    curSuggestIdx=-1;
    return;
  }

  let searchWord=q;
  let mult=1;
  const starMatch=q.match(/^(\d+(?:[.,]\d+)?)\s*\*\s*(.*)$/);
  if(starMatch){
    mult=parse(starMatch[1])||1;
    searchWord=starMatch[2].trim();
    if(!searchWord){
      box.hidden=true;
      return;
    }
  }

  const sLower=searchWord.toLowerCase();
  const matches=S.products.filter(p=>{
    return p.name.toLowerCase().includes(sLower)||
           p.barcode.includes(searchWord)||
           (p.category&&p.category.toLowerCase().includes(sLower));
  }).slice(0,8);

  curSuggestMatches=matches;
  curSuggestIdx=-1;

  if(!matches.length){
    box.innerHTML=`
      <div class="suggest-empty">
        <span>🔍 "${h(searchWord)}" ile eşleşen ürün bulunamadı.</span>
        ${isAdmin()?`<button class="btn sm or" type="button" onmousedown="openProdWithSearch('${h(searchWord).replace(/'/g,"\\'")}')">+ Hemen Yeni Ürün Ekle</button>`:''}
      </div>
    `;
    box.hidden=false;
    return;
  }

  box.innerHTML=matches.map((p,idx)=>{
    const isOut=p.stock<=0;
    return `
      <div class="suggest-item ${idx===curSuggestIdx?'active':''}" data-idx="${idx}" onmousedown="selectSuggestProduct('${p.id}',${mult})">
        <div class="sug-thumb">${getProductIconHtml(p)}</div>
        <div class="sug-info">
          <b>${highlightMatch(p.name,searchWord)}</b>
          <div class="sug-meta">
            <span class="tag t-gray">${h(p.category||'Genel')}</span>
            <code>${highlightMatch(p.barcode,searchWord)}</code>
            <span class="tag ${isOut?'t-bad':isLow(p)?'t-warn':'t-ok'}">${stockOf(p)}</span>
          </div>
        </div>
        <div class="sug-price">
          <b>${money(p.price)}${p.unit==='metre'?' /m':''}</b>
          ${mult>1?`<small class="mut">${mult} adet = <b>${money(mult*p.price)}</b></small>`:''}
        </div>
      </div>
    `;
  }).join('');
  box.hidden=false;
}

function renderSuggestActive(){
  const box=$('#scanSuggest');
  if(!box) return;
  const items=box.querySelectorAll('.suggest-item');
  items.forEach((it,idx)=>{
    if(idx===curSuggestIdx){
      it.classList.add('active');
      it.scrollIntoView({block:'nearest'});
    }else{
      it.classList.remove('active');
    }
  });
}

function selectSuggestProduct(pid,qty=1){
  addCart(pid,qty);
  const sc=$('#scan');
  const box=$('#scanSuggest');
  if(sc) sc.value='';
  if(box){
    box.hidden=true;
    box.innerHTML='';
  }
  curSuggestMatches=[];
  curSuggestIdx=-1;
  drawGrid();
  setTimeout(()=>sc?.focus(),50);
}

function openProdWithSearch(name){
  const box=$('#scanSuggest');
  if(box) box.hidden=true;
  closeModal();
  prodForm(null,'');
  setTimeout(()=>{
    const fn=$('#f_n');
    if(fn) fn.value=name;
  },100);
}

function togglePosFull(){
  document.body.classList.toggle('posfull');
  if(document.body.classList.contains('posfull')) document.documentElement.requestFullscreen?.().catch(()=>{});
  else if(document.fullscreenElement) document.exitFullscreen().catch(()=>{});
}

/* Barkod Okuyucu Yakalayıcı: Ekranda nereye tıklanırsa tıklansın tabanca okutunca doğrudan işler */
document.addEventListener('keydown',e=>{
  if(curRoute()!=='pos'||!$('#modalBg').hidden)return;
  const a=document.activeElement;
  if(a&&a!==$('#scan')&&['INPUT','SELECT','TEXTAREA'].includes(a.tagName))return;
  const sc=$('#scan');
  if(!sc)return;

  if(e.key==='Enter'){
    if(a===sc)return; // scan kutusu kendi eventinde çalıştırıyor, mükerrer çalıştırma
    e.preventDefault();
    scanEnter();
    return;
  }
  if(e.key.length===1&&!e.ctrlKey&&!e.altKey&&!e.metaKey&&a!==sc){
    sc.focus();
  }
});

/* ==========================================================================
   TÜM ESNAF VE SEKTÖRLER İÇİN AKILLI İKON VE GÖRSEL KÜTÜPHANESİ
   ========================================================================== */
const PRODUCT_ICON_MAP = [
  // Kasap, Şarküteri, Et, Tavuk, Balık & Sakatat
  { keys: ['kıyma', 'dana kıyma', 'kuzu kıyma', 'çekilmiş et'], icon: '🥩' },
  { keys: ['kuşbaşı', 'dana kuşbaşı', 'kuzu kuşbaşı', 'sotelik'], icon: '🥩' },
  { keys: ['antrikot', 'bonfile', 'biftek', 'kontrfile', 'döş', 'gerdan', 'tranç', 'nuar'], icon: '🥩' },
  { keys: ['pirzola', 'kaburga', 'incik', 'kuzu', 'kuzu kol', 'kuzu but'], icon: '🍖' },
  { keys: ['köfte', 'kasap köfte', 'tekirdağ köfte', 'akçaabat köfte', 'ızgara köfte', 'hamburger'], icon: '🧆' },
  { keys: ['sucuk', 'kangal sucuk', 'fermente sucuk', 'parmak sucuk', 'kasap sucuk'], icon: '🌭' },
  { keys: ['pastırma', 'çemen', 'çemensiz pastırma', 'kayseri pastırması'], icon: '🥓' },
  { keys: ['kavurma', 'dana kavurma', 'blok kavurma', 'rize kavurma'], icon: '🥩' },
  { keys: ['salam', 'sosis', 'jambon', 'füme et', 'hindi füme'], icon: '🌭' },
  { keys: ['tavuk', 'piliç', 'bütün tavuk', 'baget', 'tavuk but', 'tavuk göğüs', 'tavuk kanat', 'kelebek', 'tavuk pirzola', 'fileto', 'tavuk ciğer'], icon: '🍗' },
  { keys: ['hindi', 'hindi göğüs', 'hindi but'], icon: '🦃' },
  { keys: ['ciğer', 'dana ciğer', 'kuzu ciğer', 'işkembe', 'paça', 'kelle', 'kokoreç', 'yürek', 'böbrek', 'mumbar', 'şırdan'], icon: '🥩' },
  { keys: ['balık', 'hamsi', 'istavrit', 'çipura', 'levrek', 'somon', 'mezgit', 'palamut', 'alabalık', 'karides', 'kalamar', 'midye', 'ton balığı'], icon: '🐟' },

  // Süt, Peynir, Zeytin & Şarküteri Kahvaltılık
  { keys: ['kaşar', 'taze kaşar', 'eski kaşar', 'kars kaşarı', 'kaşar peyniri'], icon: '🧀' },
  { keys: ['beyaz peynir', 'ezine', 'tulum', 'lor', 'çökelek', 'süzme peynir', 'dil peyniri', 'örgü peynir', 'çeçil', 'labne', 'krem peynir', 'peynir'], icon: '🧀' },
  { keys: ['tereyağı', 'tereyağ', 'yayık', 'köy tereyağı', 'tuzlu tereyağ', 'tuzsuz tereyağ'], icon: '🧈' },
  { keys: ['kaymak', 'manda kaymağı', 'afyon kaymağı'], icon: '🥛' },
  { keys: ['yoğurt', 'süzme yoğurt', 'tava yoğurdu', 'köy yoğurdu', 'kaymaklı yoğurt'], icon: '🥣' },
  { keys: ['süt', 'günlük süt', 'pastörize süt', 'tam yağlı süt', 'yarım yağlı', 'kutu süt'], icon: '🥛' },
  { keys: ['ayran', 'kefir', 'yayık ayran'], icon: '🥛' },
  { keys: ['yumurta', 'gezen tavuk', 'organik yumurta', 'koli yumurta', 'bıldırcın yumurtası'], icon: '🥚' },
  { keys: ['zeytin', 'yeşil zeytin', 'siyah zeytin', 'sele zeytin', 'çizik zeytin', 'kırma zeytin', 'dolma zeytin', 'ızgara zeytin'], icon: '🫒' },
  { keys: ['zeytinyağı', 'sızma zeytinyağı', 'riviera', 'ayçiçek yağı', 'mısırözü yağı', 'sıvı yağ', 'margarin'], icon: '🫒' },
  { keys: ['bal', 'çiçek balı', 'çam balı', 'petek bal', 'karakovan balı', 'kestane balı'], icon: '🍯' },
  { keys: ['reçel', 'çilek reçeli', 'vişne reçeli', 'kayısı reçeli', 'incir reçeli', 'marmelat'], icon: '🍯' },
  { keys: ['tahin', 'pekmez', 'üzüm pekmezi', 'dut pekmezi', 'keçiboynuzu'], icon: '🍯' },
  { keys: ['helva', 'tahin helvası', 'fıstıklı helva', 'kakaolu helva', 'yaz helvası'], icon: '🥮' },
  { keys: ['turşu', 'salatalık turşusu', 'biber turşusu', 'lahana turşusu', 'kornişon', 'jalapeno'], icon: '🥒' },

  // Sebze & Meyve (Manav)
  { keys: ['domates', 'salkım domates', 'cherry domates', 'pembe domates', 'köy domatesi'], icon: '🍅' },
  { keys: ['salatalık', 'hıyar', 'çengelköy salatalık', 'badem salatalık'], icon: '🥒' },
  { keys: ['biber', 'sivri biber', 'çarliston', 'kapya', 'dolmalık biber', 'acı biber', 'yeşil biber', 'kırmızı biber'], icon: '🌶️' },
  { keys: ['patlıcan', 'kemer patlıcan', 'bostan patlıcan', 'top patlıcan'], icon: '🍆' },
  { keys: ['patates', 'kızartmalık patates', 'taze patates', 'kumpirlik patates'], icon: '🥔' },
  { keys: ['soğan', 'kuru soğan', 'kırmızı soğan', 'mor soğan', 'yeşil soğan', 'taze soğan', 'arpacık'], icon: '🧅' },
  { keys: ['sarımsak', 'kastamonu sarımsak', 'taşköprü'], icon: '🧄' },
  { keys: ['elma', 'starking', 'golden', 'granny smith', 'amasya elması'], icon: '🍎' },
  { keys: ['muz', 'yerli muz', 'anamur muz', 'ithal muz'], icon: '🍌' },
  { keys: ['portakal', 'mandalina', 'greyfurt', 'narenciye', 'sıkmalık portakal'], icon: '🍊' },
  { keys: ['limon', 'yatak limon', 'misket limon', 'file limon'], icon: '🍋' },
  { keys: ['çilek'], icon: '🍓' },
  { keys: ['karpuz', 'adana karpuz', 'diyarbakır karpuz'], icon: '🍉' },
  { keys: ['kavun', 'kırkağaç kavun'], icon: '🍈' },
  { keys: ['üzüm', 'çekirdeksiz üzüm', 'sultaniye', 'kara üzüm'], icon: '🍇' },
  { keys: ['şeftali', 'kayısı', 'nektarin', 'malatya kayısı'], icon: '🍑' },
  { keys: ['kiraz', 'vişne', 'napolyon kiraz'], icon: '🍒' },
  { keys: ['marul', 'kıvırcık', 'göbek marul', 'aysberg', 'roka'], icon: '🥬' },
  { keys: ['maydanoz', 'dereotu', 'nane', 'tere', 'fesleğen', 'reyhan'], icon: '🌿' },
  { keys: ['havuç', 'turp', 'şalgam', 'kırmızı pancar'], icon: '🥕' },
  { keys: ['ıspanak', 'pırasa', 'lahana', 'karnabahar', 'brokoli', 'enginar', 'kereviz'], icon: '🥬' },
  { keys: ['mantar', 'kültür mantarı', 'istiridye mantarı', 'kestane mantarı'], icon: '🍄' },
  { keys: ['mısır', 'süt mısır', 'koçan mısır'], icon: '🌽' },
  { keys: ['kabak', 'bal kabağı', 'sakız kabak'], icon: '🎃' },
  { keys: ['avokado', 'ananas', 'kivi', 'mango', 'hindistan cevizi'], icon: '🥑' },

  // Ekmek, Unlu Mamul & Fırın
  { keys: ['ekmek', 'somun', 'francala', 'tam buğday', 'kepekli ekmek', 'çavdar', 'tost ekmeği', 'baget ekmek', 'lavaş', 'bazlama', 'pide'], icon: '🍞' },
  { keys: ['simit', 'kandil simidi', 'gevrek'], icon: '🥨' },
  { keys: ['poğaça', 'pogaca', 'açma', 'boyoz', 'kruvasan'], icon: '🥐' },
  { keys: ['börek', 'su böreği', 'kol böreği', 'sigara böreği', 'ıspanaklı börek', 'kıymalı börek', 'peynirli börek'], icon: '🥟' },
  { keys: ['yufka', 'baklavalık yufka', 'kadayıf'], icon: '🥞' },
  { keys: ['tost', 'sandviç', 'hamburger', 'dürüm'], icon: '🥪' },
  { keys: ['pasta', 'yaş pasta', 'cheesecake', 'tiramisu', 'ekler', 'profiterol', 'sufle', 'waffle'], icon: '🍰' },
  { keys: ['tatlı', 'baklava', 'tulumba', 'şöbiyet', 'revani', 'kemalpaşa', 'künefe', 'sütlaç', 'kazandibi', 'muhallebi'], icon: '🥮' },
  { keys: ['kurabiye', 'bisküvi', 'kraker', 'bebe bisküvisi'], icon: '🍪' },
  { keys: ['kek', 'muffin', 'cupcake', 'browni'], icon: '🧁' },
  { keys: ['dondurma', 'cornetto', 'magnum', 'maraş dondurması'], icon: '🍦' },

  // İçecekler & Meşrubat
  { keys: ['çay', 'siyah çay', 'demlik poşet', 'filiz çay', 'rize çay', 'bitki çayı', 'ıhlamur', 'adaçayı', 'yeşil çay'], icon: '🫖' },
  { keys: ['kahve', 'türk kahvesi', 'filtre kahve', 'nescafe', 'espresso', 'latte', 'cappuccino', 'americano', 'hazır kahve'], icon: '☕' },
  { keys: ['su', 'doğal kaynak suyu', 'pet su', 'damacana', '0.5l', '1.5l', '5l'], icon: '💧' },
  { keys: ['soda', 'maden suyu', 'kızılay', 'beypazarı', 'sarıkız', 'meyveli soda'], icon: '🥤' },
  { keys: ['kola', 'coca cola', 'pepsi', 'cola'], icon: '🥤' },
  { keys: ['fanta', 'gazoz', 'çamlıca', 'yedigün', 'sprite'], icon: '🥤' },
  { keys: ['meyve suyu', 'şeftali suyu', 'vişne suyu', 'karışık meyve suyu', 'cappy', 'dimes'], icon: '🧃' },
  { keys: ['limonata', 'şalgam', 'soğuk çay', 'ice tea', 'fuse tea', 'lipton'], icon: '🧃' },
  { keys: ['enerji içeceği', 'red bull', 'burn', 'monster'], icon: '⚡' },
  { keys: ['bira', 'şarap', 'rakı', 'votka', 'viski', 'alkol'], icon: '🍺' },

  // Atıştırmalık, Temel Gıda & Bakliyat
  { keys: ['çikolata', 'bitter', 'sütlü çikolata', 'gofret', 'çikolatalı gofret'], icon: '🍫' },
  { keys: ['cips', 'patates cipsi', 'doritos', 'lays', 'ruffles', 'pringles'], icon: '🥔' },
  { keys: ['şekerleme', 'bonbon', 'jelibon', 'lolilop', 'yumuşak şeker', 'karamel'], icon: '🍬' },
  { keys: ['sakız', 'falım', 'vivident', 'mentos'], icon: '🫧' },
  { keys: ['kuruyemiş', 'fındık', 'fıstık', 'antep fıstığı', 'badem', 'ceviz', 'kaju', 'leblebi'], icon: '🥜' },
  { keys: ['çekirdek', 'ay çekirdeği', 'kabak çekirdeği'], icon: '🌻' },
  { keys: ['un', 'buğday unu', 'mısır unu', 'irmik'], icon: '🌾' },
  { keys: ['şeker', 'toz şeker', 'küp şeker', 'kesme şeker', 'esmer şeker'], icon: '🧂' },
  { keys: ['tuz', 'sofra tuzu', 'kaya tuzu', 'deniz tuzu'], icon: '🧂' },
  { keys: ['baharat', 'karabiber', 'pul biber', 'kekik', 'nane', 'kimyon', 'tarçın', 'köri', 'sumak'], icon: '🌶️' },
  { keys: ['makarna', 'spagetti', 'fiyonk', 'burgu', 'şehriye', 'arpa şehriye', 'tel şehriye'], icon: '🍝' },
  { keys: ['pirinç', 'baldo', 'osmancık', 'yasmin', 'basmati'], icon: '🍚' },
  { keys: ['bulgur', 'pilavlık bulgur', 'köftelik bulgur'], icon: '🌾' },
  { keys: ['mercimek', 'kırmızı mercimek', 'yeşil mercimek'], icon: '🥣' },
  { keys: ['nohut', 'fasulye', 'kuru fasulye', 'barbunya'], icon: '🥣' },
  { keys: ['salça', 'domates salçası', 'biber salçası', 'ketçap', 'mayonez', 'hardal'], icon: '🥫' },
  { keys: ['konserve', 'bezelye', 'mısır konservesi', 'garnitür', 'ton balık'], icon: '🥫' },
  { keys: ['sigara', 'tütün', 'sarma tütün', 'filtre', 'çarşaf'], icon: '🚬' },
  { keys: ['çakmak', 'kibrit', 'muhtar çakmağı', 'clipper', 'bic'], icon: '🔥' },

  // Temizlik, Hijyen & Kişisel Bakım
  { keys: ['deterjan', 'çamaşır deterjanı', 'sıvı deterjan', 'toz deterjan', 'omo', 'ariel', 'persil', 'alo', 'tursil'], icon: '🧼' },
  { keys: ['yumuşatıcı', 'yumoş', 'vernel'], icon: '🧴' },
  { keys: ['çamaşır suyu', 'ace', 'domestos', 'hijyen'], icon: '🧪' },
  { keys: ['bulaşık deterjanı', 'fairy', 'pril', 'bulaşık tableti', 'finish'], icon: '🫧' },
  { keys: ['sabun', 'el sabunu', 'sıvı sabun', 'kalıp sabun', 'hacı şakir', 'duru', 'dove'], icon: '🧼' },
  { keys: ['şampuan', 'saç kremi', 'head & shoulders', 'pantene', 'elidor', 'clear'], icon: '🧴' },
  { keys: ['duş jeli', 'vücut şampuanı', 'banyo lifi'], icon: '🛁' },
  { keys: ['diş macunu', 'diş fırçası', 'colgate', 'sensodyne', 'ipana'], icon: '🪥' },
  { keys: ['tuvalet kağıdı', 'kağıt havlu', 'peçete', 'mendil', 'selpak', 'solo'], icon: '🧻' },
  { keys: ['ıslak mendil', 'bebek bezi', 'prima', 'molfix', 'sleepy'], icon: '🧻' },
  { keys: ['çöp poşeti', 'buzdolabı poşeti', 'streç film', 'alüminyum folyo', 'pişirme kağıdı'], icon: '🗑️' },
  { keys: ['sünger', 'bulaşık süngeri', 'temizlik bezi', 'mikrofiber bez', 'vileda', 'paspas'], icon: '🧽' },
  { keys: ['kolonya', 'limon kolonyası', 'eyüp sabri', 'tütün kolonyası', 'dezenfektan'], icon: '🧴' },
  { keys: ['parfüm', 'deodorant', 'roll-on', 'vücut spreyi', 'axe', 'nivea', 'rexona'], icon: '💐' },
  { keys: ['ruj', 'oje', 'maskara', 'rimel', 'fondöten', 'aseton', 'makyaj'], icon: '💄' },
  { keys: ['krem', 'el kremi', 'yüz kremi', 'nemlendirici', 'güneş kremi', 'vazelin'], icon: '🧴' },
  { keys: ['tıraş', 'tıraş bıçağı', 'permatik', 'gillette', 'tıraş köpüğü', 'tıraş kolonyası'], icon: '🪒' },

  // Giyim, Tekstil, Butik & Ayakkabı
  { keys: ['tişört', 'tisort', 't-shirt', 'atlet', 'fanila', 'polo yaka'], icon: '👕' },
  { keys: ['gömlek', 'keten gömlek', 'oduncu gömlek'], icon: '👔' },
  { keys: ['pantolon', 'kot pantolon', 'jean', 'kumaş pantolon', 'kanvas', 'kargo pantolon'], icon: '👖' },
  { keys: ['elbise', 'gece elbisesi', 'yazlık elbise', 'abiye', 'tunik', 'etek'], icon: '👗' },
  { keys: ['ceket', 'blazer', 'mont', 'kaban', 'palto', 'yelek', 'yağmurluk', 'rüzgarlık'], icon: '🧥' },
  { keys: ['kazak', 'hırka', 'süveter', 'triko', 'sweatshirt', 'hoodie'], icon: '🧶' },
  { keys: ['eşofman', 'tayt', 'şort', 'bermuda', 'pijama', 'pijama takımı'], icon: '🩳' },
  { keys: ['iç çamaşırı', 'boxer', 'külot', 'sütyen', 'korse', 'çorap', 'bambu çorap', 'patik çorap', 'külotlu çorap'], icon: '🧦' },
  { keys: ['ayakkabı', 'spor ayakkabı', 'sneaker', 'klasik ayakkabı', 'babet'], icon: '👟' },
  { keys: ['bot', 'çizme', 'kar botu'], icon: '🥾' },
  { keys: ['terlik', 'sandalet', 'plaj terliği', 'ev terliği', 'topuklu', 'stiletto'], icon: '👡' },
  { keys: ['çanta', 'omuz çantası', 'sırt çantası', 'el çantası', 'cüzdan', 'kartlık'], icon: '👜' },
  { keys: ['kemer', 'deri kemer'], icon: '🥋' },
  { keys: ['şapka', 'kasket', 'bere', 'eldiven', 'atkı', 'şal', 'eşarp', 'fular'], icon: '🧢' },
  { keys: ['takı', 'kolye', 'küpe', 'yüzük', 'bileklik', 'saat'], icon: '💍' },
  { keys: ['havlu', 'bornoz', 'nevresim', 'çarşaf', 'yastık', 'yorgan', 'battaniye'], icon: '🛏️' },

  // Hırdavat, Yapı Market & Nalburiye
  { keys: ['vida', 'akıllı vida', 'sunta vidası', 'ağaç vidası', 'alçıpan vidası', 'trapez'], icon: '🔩' },
  { keys: ['dübel', 'plastik dübel', 'çelik dübel', 'tuğla dübeli'], icon: '🔩' },
  { keys: ['çivi', 'inşaat çivisi', 'tel çivi', 'çelik çivi'], icon: '🔨' },
  { keys: ['civata', 'somun', 'pul', 'rondela', 'gijon', 'kelepçe'], icon: '🔩' },
  { keys: ['matkap', 'darbeli matkap', 'şarjlı', 'vidalama', 'hilti', 'kırıcı delici', 'matkap ucu', 'uç'], icon: '🪛' },
  { keys: ['çekiç', 'balyoz', 'keser', 'lastik tokmak'], icon: '🔨' },
  { keys: ['pense', 'kargaburun', 'yan keski', 'kerpeten', 'ayarlı pense'], icon: '🔧' },
  { keys: ['tornavida', 'yıldız tornavida', 'düz tornavida', 'kontrol kalemi', 'alyan', 'torx'], icon: '🪛' },
  { keys: ['anahtar', 'ingiliz anahtarı', 'kurbağacık', 'boru anahtarı', 'kombine anahtar', 'lokma'], icon: '🔧' },
  { keys: ['testere', 'demir testeresi', 'ahşap testeresi', 'dekupaj', 'tilki kuyruğu', 'keski', 'ıspatula'], icon: '🪚' },
  { keys: ['spiral', 'taşlama', 'spiral taşı', 'kesme taşı', 'zımpara', 'zımpara kağıdı'], icon: '⚙️' },
  { keys: ['boya', 'iç cephe boyası', 'dış cephe boyası', 'tavan boyası', 'yağlı boya', 'sprey boya', 'vernik'], icon: '🎨' },
  { keys: ['fırça', 'kestirme fırça', 'yağlı boya fırçası', 'rulo', 'boya rulosu', 'saplı rulo'], icon: '🖌️' },
  { keys: ['tiner', 'sentetik tiner', 'selülozik tiner', 'boya sökücü'], icon: '🧪' },
  { keys: ['silikon', 'mastik', 'şeffaf silikon', 'beyaz silikon', 'silikon tabancası', 'poliüretan köpük'], icon: '🧴' },
  { keys: ['yapıştırıcı', 'japon yapıştırıcı', 'bali', 'uhü', 'hızlı yapıştırıcı', 'epoksi'], icon: '🩹' },
  { keys: ['bant', 'koli bandı', 'elektrik bandı', 'izole bant', 'çift taraflı bant', 'maskeleme bandı', 'teflon bant'], icon: '🩹' },
  { keys: ['kilit', 'asma kilit', 'kale kilit', 'barel', 'kapı kolu', 'menteşe', 'sürgü'], icon: '🔒' },
  { keys: ['kablo', 'antigron', 'nya', 'ttr', 'uzatma kablosu', 'grup priz'], icon: '🔌' },
  { keys: ['priz', 'anahtar priz', 'fiş', 'erkek fiş', 'dişi fiş', 'sigorta'], icon: '🔌' },
  { keys: ['ampul', 'led ampul', 'tasarruflu ampul', 'floresan', 'projektör', 'led şerit', 'duy'], icon: '💡' },
  { keys: ['musluk', 'batarya', 'vana', 'küresel vana', 'sifon', 'duş başlığı', 'hortum', 'bahçe hortumu'], icon: '🚰' },
  { keys: ['boru', 'pvc boru', 'fittings', 'dirsek', 'manşon', 'nipel', 'rekor', 'conta'], icon: '🪠' },
  { keys: ['eldiven', 'iş eldiveni', 'nitril eldiven', 'deri eldiven', 'baret', 'koruyucu gözlük', 'toz maskesi'], icon: '🧤' },
  { keys: ['metre', 'şerit metre', 'su terazisi', 'ip'], icon: '📏' },
  { keys: ['merdiven', 'alüminyum merdiven', 'akrobat'], icon: '🪜' },
  { keys: ['zincir', 'halat', 'çelik halat', 'ip', 'sicim'], icon: '⛓️' },

  // Kırtasiye, Kitap & Ofis
  { keys: ['kurşun kalem', 'tükenmez kalem', 'pilot kalem', 'jel kalem', 'dolma kalem', 'fosforlu kalem', 'keçeli kalem', 'boya kalemi', 'kalem'], icon: '✏️' },
  { keys: ['uç', '0.5 uç', '0.7 uç', '0.9 uç', 'min'], icon: '✏️' },
  { keys: ['silgi', 'kalemtraş', 'kalemtıraş'], icon: '🧹' },
  { keys: ['defter', 'kareli defter', 'çizgili defter', 'resim defteri', 'bloknot', 'ajanda', 'spiralli'], icon: '📓' },
  { keys: ['kitap', 'roman', 'hikaye', 'test kitabı', 'soru bankası', 'sözlük', 'atlas'], icon: '📚' },
  { keys: ['a4', 'fotokopi kağıdı', 'karton', 'fon kartonu', 'elişi kağıdı', 'zarf', 'etiket'], icon: '📄' },
  { keys: ['dosya', 'klasör', 'şeffaf dosya', 'poşet dosya', 'telli dosya', 'magazinlik'], icon: '📁' },
  { keys: ['zımba', 'zımba teli', 'delgeç', 'ataç', 'kıskaç', 'raptiye'], icon: '📎' },
  { keys: ['makas', 'makat bıçağı', 'maket bıçağı', 'falçata'], icon: '✂️' },
  { keys: ['prit', 'yapıştırıcı', 'sıvı yapıştırıcı', 'uhutek'], icon: '🩹' },
  { keys: ['cetvel', 'gönye', 'iletki', 'pergel'], icon: '📐' },
  { keys: ['pastel boya', 'sulu boya', 'kuru boya', 'guaj boya', 'akrilik boya', 'oyun hamuru'], icon: '🎨' },
  { keys: ['okul çantası', 'kalemlik', 'beslenme çantası', 'matara', 'suluk'], icon: '🎒' },
  { keys: ['oyuncak', 'lego', 'araba', 'bebek', 'puzzle', 'kutu oyunu', 'peluş', 'top'], icon: '🧸' },

  // Petshop
  { keys: ['kedi maması', 'köpek maması', 'yavru kedi maması', 'kısırlaştırılmış', 'yaş mama', 'konserve mama', 'ödül maması', 'mama'], icon: '🥫' },
  { keys: ['kedi kumu', 'bentonit', 'çam peleti', 'silika', 'kum küreği', 'kedi tuvaleti'], icon: '🐱' },
  { keys: ['kuş yemi', 'muhabbet kuşu yemi', 'kanarya yemi', 'papağan yemi', 'darı', 'kalamar kemiği', 'kuş kafesi'], icon: '🦜' },
  { keys: ['balık yemi', 'pul yem', 'akvaryum', 'iç filtre', 'hava motoru'], icon: '🐠' },
  { keys: ['tasma', 'boyun tasması', 'göğüs tasması', 'otomatik gezdirme', 'kayış', 'künye'], icon: '🐕' },
  { keys: ['tırmalama', 'kedi yatağı', 'köpek yatağı', 'taşıma çantası', 'box'], icon: '🐾' },
  { keys: ['kedi tarağı', 'pire tasması', 'pire damlası', 'evcil hayvan şampuanı', 'tırnak makası'], icon: '🐾' },

  // Telefon & Elektronik
  { keys: ['telefon', 'akıllı telefon', 'iphone', 'samsung', 'xiaomi', 'redmi'], icon: '📱' },
  { keys: ['kılıf', 'silikon kılıf', 'tank kılıf', 'deri kılıf', 'kapak'], icon: '📱' },
  { keys: ['ekran koruyucu', 'kırılmaz cam', 'nano cam', 'hayalet cam', 'lens koruyucu'], icon: '📱' },
  { keys: ['şarj aleti', 'şarj başlığı', 'adaptör', 'hızlı şarj', 'şarj kablosu', 'type-c', 'lightning', 'micro usb'], icon: '🔌' },
  { keys: ['kulaklık', 'bluetooth kulaklık', 'kablosuz kulaklık', 'airpods', 'kulakiçi kulaklık'], icon: '🎧' },
  { keys: ['hoparlör', 'bluetooth hoparlör', 'soundbar'], icon: '🔊' },
  { keys: ['powerbank', 'taşınabilir şarj', 'harici batarya'], icon: '🔋' },
  { keys: ['pil', 'kalem pil', 'ince pil', 'düğme pil', 'duracell', 'panasonic'], icon: '🔋' },
  { keys: ['hafıza kartı', 'micro sd', 'flash bellek', 'usb bellek'], icon: '💾' },
  { keys: ['teknik servis', 'ekran değişimi', 'batarya değişimi', 'tamir', 'bakım', 'format'], icon: '🛠️' }
];

function getProductIconChar(p, fallbackIcon){
  if(!p) return fallbackIcon || '📦';
  if(p.icon && String(p.icon).trim()) return String(p.icon).trim();
  const sec = getActiveSector();
  const def = fallbackIcon || (sec && sec.icon) || '📦';
  const text = (String(p.name || '') + ' ' + String(p.category || '')).toLocaleLowerCase('tr-TR');
  if(!text.trim()) return def;
  for(const entry of PRODUCT_ICON_MAP){
    for(const key of entry.keys){
      if(text.includes(key)){
        return entry.icon;
      }
    }
  }
  return def;
}

function getProductIconHtml(p, fallbackIcon){
  if(!p) return `<span class="prod-ic">${fallbackIcon || '📦'}</span>`;
  if(p.img && String(p.img).trim()){
    return `<img src="${h(p.img)}" alt="${h(p.name||'')}">`;
  }
  const ic = getProductIconChar(p, fallbackIcon);
  return `<span class="prod-ic">${ic}</span>`;
}

function closeIconPickerModal(){
  const b=$('#iconPickerBg');
  if(b) b.remove();
}

function openIconPicker(onSelect){
  closeIconPickerModal();
  const categories = [
    { name: '🥩 Şarküteri & Kasap', icons: ['🥩','🍖','🍗','🌭','🥓','🧆','🐟','🧀','🧈','🥛','🥣','🥚','🫒','🍯','🥒','🦃'] },
    { name: '🥦 Manav & Meyve-Sebze', icons: ['🍅','🥒','🌶️','🍆','🥔','🧅','🧄','🥕','🥬','🌿','🍄','🌽','🎃','🍎','🍌','🍊','🍋','🍓','🍉','🍈','🍇','🍑','🍒','🥑','🍍'] },
    { name: '🍞 Fırın, Ekmek & Pastane', icons: ['🍞','🥨','🥐','🥟','🥞','🥪','🍰','🥮','🍪','🧁','🍦'] },
    { name: '🥤 İçecekler & Kahve', icons: ['🫖','☕','💧','🥤','🧃','⚡','🍺'] },
    { name: '🛒 Market, Bakkal & Atıştırmalık', icons: ['🍫','🥔','🍬','🫧','🥜','🌻','🌾','🧂','🍝','🍚','🥫','🚬','🔥'] },
    { name: '🧼 Temizlik & Hijyen', icons: ['🧼','🧴','🫧','🪥','🧻','🗑️','🧽','🧪','🪒'] },
    { name: '👗 Giyim, Butik & Ayakkabı', icons: ['👕','👔','👖','👗','🧥','🧶','🩳','🧦','👟','🥾','👡','👠','👜','🥋','🧢','🧣','💍','🛏️'] },
    { name: '🔧 Hırdavat, Yapı & Boya', icons: ['🔩','🔨','🔧','🪛','🪚','⚙️','🎨','🖌️','🧴','🩹','🔒','🔌','💡','🚰','🪠','🧤','📏','🪜','⛓️'] },
    { name: '📚 Kırtasiye & Kitap', icons: ['✏️','🧹','📓','📚','📄','📁','📎','✂️','📐','🎒','🧸'] },
    { name: '🐾 Petshop & Akvaryum', icons: ['🥫','🐱','🐕','🦜','🐠','🐾','🎾'] },
    { name: '📱 Telefon & Elektronik', icons: ['📱','🔌','🎧','🔊','🔋','💾','🛠️'] },
    { name: '💄 Kozmetik & Parfümeri', icons: ['💄','💐','💅','🧴','🪞'] },
    { name: '⭐ Popüler Genel', icons: ['⭐','🏷️','📦','🎁','💳','💰','🧾','🛒','🏬'] }
  ];

  let activeCat = categories[0].name;
  const div=document.createElement('div');
  div.id='iconPickerBg';
  div.style.cssText='position:fixed;inset:0;background:rgba(0,0,0,0.6);backdrop-filter:blur(3px);z-index:999;display:grid;place-items:center;padding:12px;animation:pwaFadeIn 0.15s ease';

  div.innerHTML = `
    <div class="box" style="width:480px;max-width:95vw;padding:18px;background:#fff;border-radius:18px;box-shadow:0 20px 50px rgba(0,0,0,0.3)">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px">
        <h3 style="margin:0;font-size:17px;color:var(--navy)">✨ Ürün İçin İkon Seç</h3>
        <button class="mclose" onclick="closeIconPickerModal()" style="float:none">✕</button>
      </div>
      <div id="iconPickerCats" style="display:flex;gap:4px;flex-wrap:wrap;max-height:85px;overflow-y:auto;margin-bottom:12px;padding-bottom:4px"></div>
      <div id="iconPickerGrid" style="display:grid;grid-template-columns:repeat(auto-fill,minmax(54px,1fr));gap:8px;max-height:260px;overflow-y:auto;padding:4px"></div>
      <div style="text-align:right;margin-top:12px">
        <button class="btn ln sm" onclick="closeIconPickerModal()">Vazgeç</button>
      </div>
    </div>
  `;
  document.body.appendChild(div);

  const drawPicker = () => {
    const cat = categories.find(c => c.name === activeCat) || categories[0];
    const catTabs = categories.map(c => `
      <button type="button" class="chip ${c.name===activeCat?'on':''}" style="font-size:11px;padding:4px 8px;margin:2px" onclick="window._pickCat('${c.name}')">${c.name}</button>
    `).join('');
    const iconGrid = cat.icons.map(ic => `
      <button type="button" class="icon-pick-btn" onclick="window._chooseIcon('${ic}')" style="font-size:30px;width:54px;height:54px;border-radius:12px;border:1px solid #cbd5e1;background:#fff;cursor:pointer;display:grid;place-items:center;transition:0.1s" onmouseover="this.style.borderColor='var(--orange)';this.style.transform='scale(1.1)'" onmouseout="this.style.borderColor='#cbd5e1';this.style.transform='none'">${ic}</button>
    `).join('');

    div.querySelector('#iconPickerCats').innerHTML = catTabs;
    div.querySelector('#iconPickerGrid').innerHTML = iconGrid;
  };

  window._pickCat = (catName) => { activeCat = catName; drawPicker(); };
  window._chooseIcon = (ic) => {
    closeIconPickerModal();
    if(typeof onSelect === 'function') onSelect(ic);
  };
  drawPicker();
}

function drawQuick(){
  const b=$('#qlist');if(!b)return;
  const sec=getActiveSector();
  const l=(S.quick||[]).map(findP).filter(Boolean);
  const chips=sec.quickChips || [1, 2, 5];
  b.innerHTML=l.length?l.map(p=>{
    const uSuffix = (p.unit && p.unit !== 'adet') ? ('/' + p.unit) : '';
    const icHtml = getProductIconHtml(p, sec.icon);
    return `<div class="qt" onclick="quickAddCart('${p.id}')" title="${h(p.name)} - Sepete Ekle">
      ${quickEdit?`<button class="x" onclick="event.stopPropagation();quickRemove('${p.id}')" title="Kaldır">✕</button>`:''}
      <div class="qi">${icHtml}</div>
      <div class="qt-info">
        <b class="qt-title">${h(p.name)}</b>
        <div class="qt-price-row">
          <span class="qt-price">${money(p.price)}<small>${uSuffix}</small></span>
          <span class="qt-stock ${p.stock<=0?'bad':isLow(p)?'warn':'ok'}">${stockOf(p)}</span>
        </div>
      </div>
      <div class="chips">
        ${chips.map(c => `<button type="button" onclick="event.stopPropagation();addCart('${p.id}',${c},'',true)" title="+${c} Ekle">+${c}</button>`).join('')}
      </div>
    </div>`;
  }).join(''):`<div class="qempty-hint"><span style="font-size:28px">⚡</span><p>${sec.quickHint || 'Sık satılan hızlı ürünleri buraya ekleyin: <b>＋ Ekle</b>.'}</p></div>`;
  const e=$('#qeBtn');if(e)e.className='btn sm '+(quickEdit?'or':'ln');
}

async function quickRemove(id){
  await cmd('quickSet',{ids:S.quick.filter(x=>x!==id)});
  drawQuick();
}

let qSel=[];
function quickPick(){
  qSel=[...(S.quick||[])];
  modal(`<h2>⚡ Hızlı Satış Ürünlerini Seç</h2><input id="qq" placeholder="🔍 Ürün ara" style="margin-bottom:8px"><div class="pick" id="qpick"></div><div class="mfoot"><button class="btn ln" onclick="closeModal()">İptal</button><button class="btn or" onclick="quickSave()">Kaydet</button></div>`);
  $('#qq').oninput=drawPick;drawPick();
  setTimeout(()=>$('#qq').focus(),50);
}
function drawPick(){
  const q=$('#qq').value.toLowerCase();
  $('#qpick').innerHTML=S.products.filter(p=>!q||p.name.toLowerCase().includes(q)||p.barcode.includes(q)).map(p=>`<label><input type="checkbox" ${qSel.includes(p.id)?'checked':''} onchange="this.checked?qSel.push('${p.id}'):qSel=qSel.filter(x=>x!=='${p.id}')"><span style="display:inline-flex;align-items:center;gap:8px"><span style="font-size:20px">${getProductIconChar(p)}</span> <b>${h(p.name)}</b></span><small class="mut" style="margin-left:auto">${money(p.price)}</small></label>`).join('')||'<p class="mut">Ürün yok</p>';
}
async function quickSave(){
  if(await cmd('quickSet',{ids:qSel})){closeModal();drawQuick()}
}

function drawGrid(){
  const g=$('#pgrid');if(!g)return;
  const sec=getActiveSector();
  const cats=[...new Set(S.products.map(p=>p.category).filter(Boolean))].sort();
  $('#cats').innerHTML=`<button class="chip ${!posCat?'on':''}" onclick="posCat='';drawGrid()">Tümü (${S.products.length})</button>`+cats.map(c=>`<button class="chip ${posCat===c?'on':''}" onclick="posCat='${h(c).replace(/'/g,'')}';drawGrid()">${h(c)}</button>`).join('');
  const q=($('#scan')?.value||'').trim().toLowerCase();
  let l=S.products.filter(p=>(!posCat||p.category===posCat)&&(!q||p.name.toLowerCase().includes(q)||p.barcode.includes(q)||(p.category||'').toLowerCase().includes(q)));
  g.innerHTML=l.slice(0,90).map(p=>{
    const icHtml = getProductIconHtml(p, sec.icon);
    return `<div class="pc ${p.stock<=0?'out':''}" onclick="handleCode('${h(p.barcode)}')">
      <div class="im">${icHtml}<span class="ptag">${money(p.price)} / ${unitOf(p)}</span></div>
      <b>${h(p.name)}</b>
      <small class="${isLow(p)?'bad':'mut'}">Stok: ${stockOf(p)}</small>
    </div>`;
  }).join('')||'<p class="mut" style="padding:20px;text-align:center">Ürün bulunamadı.</p>';
}

let lastScanTime=0;
let lastScanCode='';

function scanEnter(){
  const sc=$('#scan');if(!sc)return;
  const raw=sc.value.trim();
  sc.value=''; // Hemen temizle ki ikinci enter veya gecikmeli olaylar tekrar okumasın!
  const box=$('#scanSuggest');
  if(box){box.hidden=true;box.innerHTML='';}
  curSuggestMatches=[];
  curSuggestIdx=-1;
  drawGrid();
  sc.focus();
  if(!raw)return;

  const now=Date.now();
  // Aynı barkod 500ms içinde arka arkaya geldiyse (CR+LF tabanca çift tetiklemesi) yoksay
  if(raw===lastScanCode&&(now-lastScanTime)<500){
    return;
  }
  lastScanCode=raw;
  lastScanTime=now;

  let q=1, v=raw;
  const m=raw.match(/^(\d+(?:[.,]\d+)?)\*(.+)$/);
  if(m){q=parse(m[1]);v=m[2].trim()}
  handleCode(v,q);
}

/* ==========================================================================
   CANLI KASA TERAZİSİ MOTORU (WEB SERIAL API & RS232 / USB ENTEGRASYONU)
   ========================================================================== */
let liveScaleWeight = 0;
let liveScalePort = null;
let liveScaleReader = null;
let liveScaleConnected = false;
let liveScaleBaud = parseInt(localStorage.getItem('msg_scale_baud') || '9600', 10);
let liveScaleProtocol = localStorage.getItem('msg_scale_proto') || 'cas'; // cas, dibal, bizerba, tem, generic

function updateScaleWidgetUI(){
  const dig = $('#scaleDigits');
  const dot = $('#scaleDot');
  const widget = $('#scaleWidget');
  if(!dig) return;
  if(liveScaleWeight > 0){
    dig.textContent = num(liveScaleWeight) + ' KG';
    dig.classList.remove('zero');
  } else {
    dig.textContent = '0.000 KG';
    dig.classList.add('zero');
  }
  if(dot){
    if(liveScaleConnected){
      dot.className = 'scale-status-dot online';
      widget?.classList.add('connected');
    } else {
      dot.className = 'scale-status-dot';
      widget?.classList.remove('connected');
    }
  }
}

function parseWeightFromScaleString(str){
  if(!str) return null;
  // Tem / CAS / Dibal formatları: ST,GS,+  1.450kg veya W: 1.450 veya saf 1.450
  const m = str.match(/([+\-]?\s*\d+[.,]\d{2,3})/);
  if(m){
    const cleanNum = parse(m[1].replace(/\s+/g, ''));
    if(!isNaN(cleanNum) && cleanNum >= 0 && cleanNum < 150){
      return cleanNum;
    }
  }
  return null;
}

async function connectLiveScale(){
  if(!('serial' in navigator)){
    toast('Bu tarayıcı Web Serial (Seri Port) desteklemiyor. Lütfen Chrome, Edge veya masaüstü uygulamamızı kullanın.', 'err');
    return false;
  }
  try {
    liveScalePort = await navigator.serial.requestPort();
    await liveScalePort.open({ baudRate: liveScaleBaud });
    liveScaleConnected = true;
    updateScaleWidgetUI();
    toast('⚖️ Kasa terazisi başarıyla bağlandı!', 'ok');
    readLiveScaleStream();
    return true;
  } catch(err) {
    console.warn('Terazi bağlantı hatası:', err);
    toast('Terazi bağlantısı iptal edildi veya port açılamadı: ' + err.message, 'err');
    liveScaleConnected = false;
    updateScaleWidgetUI();
    return false;
  }
}

async function readLiveScaleStream(){
  let buffer = '';
  while (liveScalePort && liveScalePort.readable && liveScaleConnected) {
    try {
      const textDecoder = new TextDecoderStream();
      const readableStreamClosed = liveScalePort.readable.pipeTo(textDecoder.writable);
      liveScaleReader = textDecoder.readable.getReader();
      while (true) {
        const { value, done } = await liveScaleReader.read();
        if (done) break;
        if (value) {
          buffer += value;
          const lines = buffer.split(/[\r\n]+/);
          if (lines.length > 1) {
            for (let i = 0; i < lines.length - 1; i++) {
              const line = lines[i].trim();
              if (line) {
                const w = parseWeightFromScaleString(line);
                if (w !== null) {
                  liveScaleWeight = w;
                  updateScaleWidgetUI();
                }
              }
            }
            buffer = lines[lines.length - 1];
          }
        }
      }
    } catch (err) {
      console.warn('Terazi okuma akışında kopma:', err);
      break;
    }
  }
  liveScaleConnected = false;
  updateScaleWidgetUI();
}

function disconnectLiveScale(){
  try {
    if(liveScaleReader) liveScaleReader.cancel();
    if(liveScalePort) liveScalePort.close();
  } catch(e){}
  liveScaleConnected = false;
  liveScaleWeight = 0;
  updateScaleWidgetUI();
  toast('Terazi bağlantısı kesildi', 'ok');
}

function toggleScaleSettingsModal(){
  modal(`
    <div style="padding:4px 2px">
      <div style="display:flex;align-items:center;justify-content:space-between;border-bottom:2px solid var(--navy);padding-bottom:10px;margin-bottom:14px">
        <h2 style="margin:0;font-size:19px;color:var(--navy);display:flex;align-items:center;gap:8px">
          ⚖️ Canlı Kasa Terazisi Ayarları & Test
        </h2>
        <button class="btn ln sm" onclick="closeModal()">✕</button>
      </div>

      <!-- Canlı Tartım Göstergesi -->
      <div style="background:#091224;border:2px solid ${liveScaleConnected?'#22c55e':'#0284c7'};border-radius:14px;padding:16px;text-align:center;margin-bottom:16px">
        <small style="color:#94a3b8;letter-spacing:1px;font-weight:700">CANLI TARTILAN AĞIRLIK</small>
        <div style="font-family:'Courier New',Courier,monospace;font-size:42px;font-weight:900;color:#4ade80;margin:6px 0" id="modalScaleDigits">
          ${num(liveScaleWeight)} KG
        </div>
        <div style="font-size:12px;color:${liveScaleConnected?'#4ade80':'#94a3b8'}">
          ${liveScaleConnected ? '🟢 Terazi Bağlı ve Veri Alınıyor (Canlı Tartım Aktif)' : '⚪ Terazi Bağlı Değil (Bağlan butonuna basınız)'}
        </div>
      </div>

      <div class="row">
        <div class="f">
          <label>Terazi Modeli / Protokol</label>
          <select id="scale_proto" onchange="liveScaleProtocol=this.value;localStorage.setItem('msg_scale_proto',this.value)">
            <option value="cas" ${liveScaleProtocol==='cas'?'selected':''}>CAS (ER / AP / SW Serisi)</option>
            <option value="dibal" ${liveScaleProtocol==='dibal'?'selected':''}>Dibal / Bizerba</option>
            <option value="tem" ${liveScaleProtocol==='tem'?'selected':''}>TEM / Aclas / Dikomsan</option>
            <option value="generic" ${liveScaleProtocol==='generic'?'selected':''}>Genel Standart RS232 Terazi</option>
          </select>
        </div>
        <div class="f">
          <label>Baud Rate (Haberleşme Hızı)</label>
          <select id="scale_baud" onchange="liveScaleBaud=parseInt(this.value,10);localStorage.setItem('msg_scale_baud',this.value)">
            <option value="9600" ${liveScaleBaud===9600?'selected':''}>9600 bps (Standart)</option>
            <option value="4800" ${liveScaleBaud===4800?'selected':''}>4800 bps</option>
            <option value="19200" ${liveScaleBaud===19200?'selected':''}>19200 bps</option>
            <option value="2400" ${liveScaleBaud===2400?'selected':''}>2400 bps</option>
          </select>
        </div>
      </div>

      <!-- Test Simülasyonu (Fiziki terazi olmadığı anlar veya test için) -->
      <div style="background:#f8fafc;border:1px dashed #cbd5e1;border-radius:10px;padding:10px 12px;margin-bottom:14px">
        <b style="font-size:12px;color:var(--navy);display:block;margin-bottom:4px">🧪 Manuel / Test Tartım Değeri Gir (Simülasyon):</b>
        <div style="display:flex;gap:6px">
          <input type="number" id="simScaleKg" step="0.05" min="0" placeholder="Örn: 1.450" style="flex:1;font-weight:700">
          <button class="btn sm" onclick="simScaleWeight(parse($('#simScaleKg').value))" style="background:#0284c7;color:#fff">Uygula</button>
          <button class="btn sm ln" onclick="simScaleWeight(0)">Sıfırla (0 KG)</button>
        </div>
      </div>

      <div class="mfoot" style="justify-content:space-between">
        ${liveScaleConnected ? `
          <button class="btn rd" onclick="disconnectLiveScale();closeModal()">🔌 Bağlantıyı Kes</button>
        ` : `
          <button class="btn or" onclick="connectLiveScale();closeModal()" style="font-weight:700">🔌 USB / COM Teraziye Bağlan</button>
        `}
        <button class="btn ln" onclick="closeModal()">✕ Kapat</button>
      </div>
    </div>
  `);
}

function simScaleWeight(kg){
  liveScaleWeight = Math.max(0, round3(kg||0));
  updateScaleWidgetUI();
  const md = $('#modalScaleDigits');
  if(md) md.textContent = num(liveScaleWeight) + ' KG';
  drawCart();
  toast(`Canlı terazi tartımı: ${num(liveScaleWeight)} KG olarak ayarlandı`, 'ok');
}

/* ---------- Terazi Barkodu Ayrıştırıcı (27/28 Standart EAN-13 ve EAN-12) ---------- */
function decodeScaleBarcode(barcodeStr){
  const s = String(barcodeStr||'').trim();
  // 12 veya 13 haneli ve 27/28 ile başlayan manav/kasap/şarküteri terazi barkodları
  if((s.length===12 || s.length===13) && (s.startsWith('27') || s.startsWith('28'))){
    const pluStr = s.substring(2,7);
    const pluNum = parseInt(pluStr, 10);
    const weightGrams = parseInt(s.substring(7,12), 10);
    const weightKg = round3(weightGrams / 1000);
    return { isScale:true, pluStr, pluNum, weightGrams, weightKg };
  }
  return { isScale:false };
}

function handleCode(v,q=1){
  const clean = String(v||'').trim();
  
  // 1. Elektronik Terazi Barkodu Kontrolü (Kasap, Şarküteri, Manav, Market)
  const sc = decodeScaleBarcode(clean);
  if(sc.isScale && sc.weightKg > 0){
    let p = S.products.find(x => 
      x.barcode === sc.pluStr || 
      x.barcode === String(sc.pluNum) ||
      (x.plu && (String(x.plu) === sc.pluStr || String(x.plu) === String(sc.pluNum))) ||
      x.barcode === clean ||
      (x.barcode && (x.barcode.startsWith('27' + sc.pluStr) || x.barcode.startsWith('28' + sc.pluStr)))
    );
    if(p){
      addCart(p.id, sc.weightKg, '', true);
      beep(true);
      toast(`⚖️ Terazi Tartımı: ${sc.weightKg} kg "${p.name}" sepete eklendi!`, 'ok');
      return p;
    }
  }

  // 2. Normal Barkod veya İsim Araması
  let p=S.products.find(x=>x.barcode===v);
  if(!p){
    const vLower=v.toLowerCase();
    const l=S.products.filter(x=>x.name.toLowerCase().includes(vLower)||x.barcode.includes(v));
    if(l.length>=1) p=l[0];
  }
  if(!p){
    beep(false);
    toast('⚠️ Kayıtlı ürün bulunamadı: '+v,'err');
    if(/^\d{3,}$/.test(v)&&isAdmin()){
      askAddUnknownProduct(v);
    }
    return null;
  }

  // 3. Butik Beden / Varyant Kontrolü
  if((p.sizes||p.colors) && (!q || q===1)){
    askVariantModal(p.id, q);
    return p;
  }

  // 4. Canlı Kasa Terazisi Kontrolü (Kg / Gramajlı ürün ise ve terazide ağırlık varsa)
  const isScaleUnit = ['kg','kilogram','gram','gr'].includes(String(p.unit||'').toLowerCase());
  let finalQty = q;
  if(isScaleUnit && liveScaleWeight > 0 && (!q || q === 1)){
    finalQty = liveScaleWeight;
    toast(`⚖️ Canlı Terazi: ${num(finalQty)} kg "${p.name}" sepete eklendi!`, 'ok');
  }

  addCart(p.id, finalQty);
  beep(true);
  return p;
}

/* Butik Hızlı Beden / Renk Seçim Penceresi */
let curSelectedVariant = { size:'', color:'' };
function askVariantModal(pid, n=1){
  const p = findP(pid); if(!p) return;
  curSelectedVariant = { size:'', color:'' };
  const sizes = (p.sizes||'').split(/[,/]/).map(s=>s.trim()).filter(Boolean);
  const colors = (p.colors||'').split(/[,/]/).map(c=>c.trim()).filter(Boolean);

  if(!sizes.length && !colors.length){
    addCart(pid, n);
    return;
  }

  modal(`
    <div style="text-align:center;padding:12px 6px">
      <div style="font-size:38px;margin-bottom:6px">👗</div>
      <h3 style="margin:0 0 4px;color:var(--navy);font-size:20px">${h(p.name)}</h3>
      <p class="mut" style="font-size:13px;margin:0 0 16px">Satışı yapılan beden / renk varyantını seçiniz:</p>

      ${sizes.length ? `
        <div style="margin-bottom:14px;text-align:left">
          <label style="font-weight:700;font-size:12px;color:#334155;display:block;margin-bottom:6px">BEDEN SEÇİMİ:</label>
          <div style="display:flex;gap:6px;flex-wrap:wrap" id="varSizeBox">
            ${sizes.map(s => `<button type="button" class="btn ln sm var-btn" style="min-width:44px;font-weight:700" onclick="pickVarChip(this, 'size', '${h(s)}')">${h(s)}</button>`).join('')}
          </div>
        </div>
      ` : ''}

      ${colors.length ? `
        <div style="margin-bottom:14px;text-align:left">
          <label style="font-weight:700;font-size:12px;color:#334155;display:block;margin-bottom:6px">RENK SEÇİMİ:</label>
          <div style="display:flex;gap:6px;flex-wrap:wrap" id="varColorBox">
            ${colors.map(c => `<button type="button" class="btn ln sm var-btn" style="font-weight:600" onclick="pickVarChip(this, 'color', '${h(c)}')">${h(c)}</button>`).join('')}
          </div>
        </div>
      ` : ''}

      <div style="display:flex;gap:10px;justify-content:center;margin-top:20px">
        <button class="btn ln" onclick="closeModal();addCart('${pid}', ${n}, '')">Varyantsız Ekle</button>
        <button class="btn or" onclick="confirmVariantCart('${pid}', ${n})">✔ Seçilenle Sepete Ekle</button>
      </div>
    </div>
  `);
}

function pickVarChip(btn, type, val){
  const box = type==='size' ? $('#varSizeBox') : $('#varColorBox');
  if(box) box.querySelectorAll('.var-btn').forEach(b => b.classList.remove('or'));
  btn.classList.add('or');
  curSelectedVariant[type] = val;
}

function confirmVariantCart(pid, n){
  const parts = [];
  if(curSelectedVariant.size) parts.push('Beden: '+curSelectedVariant.size);
  if(curSelectedVariant.color) parts.push('Renk: '+curSelectedVariant.color);
  const varStr = parts.join(' • ');
  closeModal();
  addCart(pid, n, varStr);
  beep(true);
}

function quickAddCart(pid){
  const p = findP(pid); if(!p) return;
  if(p.sizes || p.colors){
    askVariantModal(p.id, 1);
    return;
  }
  const isScaleUnit = ['kg','kilogram','gram','gr'].includes(String(p.unit||'').toLowerCase());
  if(isScaleUnit && liveScaleWeight > 0){
    addCart(p.id, liveScaleWeight, '', true);
    return;
  }
  addCart(p.id, 1);
}

function addCart(pid, n=1, variant='', isExplicitQty=false){
  const p=findP(pid);if(!p)return;
  const c=curCart();
  
  // Canlı Terazi Kontrolü (Kg / Gramajlı ürün ise ve canlı terazi açıksa / tartım varsa ve miktar zorunlu belirtilmemişse)
  const isScaleUnit = ['kg','kilogram','gram','gr'].includes(String(p.unit||'').toLowerCase());
  let finalQty = n;
  if(isScaleUnit && liveScaleWeight > 0 && !isExplicitQty && (n === 1 || n === undefined || n === null)){
    finalQty = liveScaleWeight;
    toast(`⚖️ Canlı Terazi: ${num(finalQty)} kg "${p.name}" sepete eklendi!`, 'ok');
  }

  const ln=c.items.find(l=>l.pid===pid&&l.mode==='base'&&((l.variant||'')===(variant||'')));
  if(ln) ln.qty=round3(ln.qty+finalQty);
  else c.items.push({pid,mode:'base',qty:finalQty,price:p.price,variant:variant||''});
  lastPid=pid;
  drawCart();
  const b=$('.cartwrap');if(b)b.scrollTop=b.scrollHeight;
  $('#scan')?.focus();
  if(window.innerWidth<=1000 && curMposTab==='prods'){
    toast(`+${num(finalQty)} ${p.name} ${variant?`(${variant})`:''} sepete eklendi`,'ok');
  }
}

function askAddUnknownProduct(code){
  if(!$('#modalBg').hidden)return;
  modal(`
    <div style="text-align:center;padding:12px 6px">
      <div style="font-size:46px;margin-bottom:8px">📦</div>
      <h2 style="margin:0 0 8px">Ürün Sistemde Bulunamadı</h2>
      <p style="font-size:15px;color:var(--txt);margin:0 0 18px;line-height:1.5">
        <b>"${h(code)}"</b> barkoduna ait kayıtlı ürün yok.<br>
        Bu barkodla hemen yeni ürün kartı açmak ister misiniz?
      </p>
      <div style="display:flex;gap:12px;justify-content:center">
        <button class="btn ln" onclick="closeModal();$('#scan')?.focus()">Vazgeç</button>
        <button class="btn or" onclick="closeModal();prodForm(null,'${code}')">➕ Yeni Ürün Ekle</button>
      </div>
    </div>
  `);
}

const usedItem=l=>{const p=findP(l.pid);return l.mode==='roll'?l.qty*(p.rollLen||0):l.qty};
function cartSub(c=curCart()){return round2(c.items.reduce((a,l)=>a+l.qty*l.price,0))}

function qty(i,d){
  const c=curCart();const l=c.items[i];
  if(!l)return;
  const p=findP(l.pid);
  const isDec=['metre','kg','kilogram','gram','gr','litre','lt'].includes(String(p?.unit||'').toLowerCase());
  const n=round3(l.qty+d);
  if(n<=0) c.items.splice(i,1);
  else l.qty=n;
  saveCarts();
  drawCart();
}

function setCartItemWeightFromScale(idx){
  const c = curCart();
  if(!c || !c.items[idx]) return;
  if(liveScaleWeight <= 0){
    toast('Canlı terazide tartım yok (0.000 KG). Teraziye ürün koyunuz veya terazi ayarlarından tartım giriniz.', 'warn');
    return;
  }
  c.items[idx].qty = round3(liveScaleWeight);
  saveCarts();
  drawCart();
  const p = findP(c.items[idx].pid);
  toast(`⚖️ "${p?.name||'Ürün'}" miktarı terazideki ${num(liveScaleWeight)} kg olarak güncellendi!`, 'ok');
}

function drawCart(){
  const body=$('#cartBody');if(!body)return;
  const c=curCart();
  c.items=c.items.filter(l=>findP(l.pid));
  saveCarts();

  /* Sepet Sekmelerini Çiz */
  const tb=$('#cartTabsBar');
  if(tb){
    const parkedCount = carts.filter((x, idx) => idx !== activeCartIdx && x.items.length > 0).length;
    tb.innerHTML=`
      <div style="display:flex;gap:6px;align-items:center;overflow-x:auto;flex:1;min-width:0;padding-bottom:2px">
        ${carts.map((cartItem,i)=>{
          const sub=cartSub(cartItem);
          const cnt=cartItem.items.length;
          return `<div class="cart-tab ${i===activeCartIdx?'on':''} ${cartItem.isParked?'parked-tab':''}" onclick="switchCart(${i})">
            <span class="tab-title" title="Adını değiştirmek için çift tıklayın" ondblclick="renameCart(${i},event)">${cartItem.isParked?'⏸️':'🛒'} ${h(cartItem.name)}</span>
            <span class="tab-badge">${cnt?`${cnt} ürün • ${money(sub)}`:'Boş'}</span>
            <button class="tab-close" onclick="removeCart(${i},event)" title="Kapat/Temizle">✕</button>
          </div>`;
        }).join('')}
        <button class="btn or sm new-tab-btn" onclick="addCartTab()" title="Yeni boş sepet sekmesi aç">＋ Yeni Sepet</button>
      </div>
      <div style="display:flex;gap:6px;align-items:center;flex:none;margin-left:6px">
        <button type="button" class="btn sm" onclick="parkCurrentCart()" style="background:#0f766e;color:#fff;border-radius:8px;font-weight:700;padding:6px 10px;white-space:nowrap" title="Müşteri beklenirken mevcut sepeti beklemeye al">
          ⏸️ Park Et
        </button>
        ${parkedCount > 0 ? `
          <button type="button" class="btn sm" onclick="parkCartModal()" style="background:#e11d48;color:#fff;border-radius:8px;font-weight:700;padding:6px 10px;white-space:nowrap;animation:pulse 1.8s infinite" title="Bekleyen sepetleri listele">
            ⏳ Bekleyen (${parkedCount})
          </button>
        ` : ''}
        <button type="button" class="btn sm rd" onclick="clearCurrentCart()" style="border-radius:8px;padding:6px 9px" title="Bu sepeti temizle">
          🗑️
        </button>
      </div>
    `;
  }

  const sub=cartSub(c);
  if(c.discount>sub) c.discount=sub;
  const tot=round2(sub-(c.discount||0));
  if(!c.due) c.due=dkey(addDays(new Date(),S.settings.creditDays));

  /* Sepet Satırları */
  body.innerHTML=c.items.length?c.items.map((l,i)=>{
    const p=findP(l.pid);
    const isDec=['metre','kg','kilogram','gram','gr','litre','lt'].includes(String(p.unit||'').toLowerCase());
    const modeSel=p.unit==='metre'&&p.rollPrice?` <select onchange="setMode(${i},this.value)" class="msel"><option value="base" ${l.mode==='base'?'selected':''}>Metre</option><option value="roll" ${l.mode==='roll'?'selected':''}>Adet (${num(p.rollLen)} m)</option></select>`:'';
    const over=usedItem(l)>p.stock+1e-9;
    const varBadge=l.variant?` <span class="tag t-blue" style="font-size:10.5px;padding:1px 6px;margin-left:4px;vertical-align:middle">${h(l.variant)}</span>`:'';
    return `<tr class="${l.pid===lastPid?'hl':''}">
      <td class="mut hide-sm">${i+1}</td>
      <td class="c-prod">
        <b>${h(p.name)}</b>${varBadge}${modeSel}
        <div class="c-prod-meta"><span class="${over?'bad':'mut'}">${h(p.barcode)} • Stok: ${stockOf(p)}${over?' • YETERSİZ STOK!':''}</span> <span class="c-unit-mob mobile-only">• Birim: ${money(l.price)}</span></div>
      </td>
      <td class="c c-qty">
        <div class="qc">
          <button class="qb" type="button" onclick="qty(${i},${isDec?'-0.5':'-1'})">−</button>
          <input type="number" inputmode="decimal" step="${isDec?'0.001':'1'}" min="0" value="${l.qty}" onchange="curCart().items[${i}].qty=Math.max(0,round3(parse(this.value)));saveCarts();drawCart()">
          <button class="qb" type="button" onclick="qty(${i},${isDec?'0.5':'1'})">+</button>
        </div>
        <small class="mut hide-sm">${l.mode==='roll'?'adet':unitOf(p)}</small>
        ${(isDec && liveScaleWeight > 0) ? `<button type="button" class="btn sm ln" onclick="setCartItemWeightFromScale(${i})" title="Canlı terazideki tartımı (${num(liveScaleWeight)} kg) bu satıra aktar" style="font-size:10px;padding:2px 5px;margin-top:3px;display:block;width:100%;border-color:#22c55e;color:#15803d;font-weight:700">⚖️ Teraziden Al (${num(liveScaleWeight)} kg)</button>` : ''}
      </td>
      <td class="r hide-sm c-unit">
        <input class="pin" type="number" inputmode="decimal" step="0.01" value="${l.price}" onchange="curCart().items[${i}].price=parse(this.value);saveCarts();drawCart()">
        ${p.wprice ? `<button type="button" class="btn sm ${l.price===p.wprice?'ok':'ln'}" onclick="setCartPriceMode(${i}, '${l.price===p.wprice?'normal':'wholesale'}')" style="font-size:10px;padding:1px 5px;display:block;margin-top:2px;width:100%" title="Perakende / Toptan Fiyat Geçişi">${l.price===p.wprice?'✓ Toptan':'🏷️ Toptan'}</button>` : ''}
      </td>
      <td class="r c-total"><b class="c-total-val">${money(l.qty*l.price)}</b></td>
      <td class="c c-del"><button class="btn rd sm del-btn" type="button" onclick="removeCartItem(${i})" title="Bu ürünü sepetten çıkar">✕</button></td>
    </tr>`;
  }).join(''):'<tr><td colspan="6" class="cempty"><div class="cempty-icon">🛒</div><b>Sepetiniz Boş</b><small>Barkod okutun, arama yapın veya sağdaki menüden ürün ekleyin</small></td></tr>';

  /* Son Okutulan Ürün Kutusu */
  const lp=lastPid&&findP(lastPid), ll=lp&&c.items.find(l=>l.pid===lastPid);
  $('#lastBox').innerHTML=lp&&ll?`<div class="lastb">
    <div class="lim">${getProductIconHtml(lp, getActiveSector().icon)}</div>
    <div class="lnm"><small>SON OKUTULAN ÜRÜN</small><b>${h(lp.name)}</b></div>
    <div class="lpr"><small>${num(ll.qty)} ${ll.mode==='roll'?'adet':unitOf(lp)} × ${money(ll.price)}</small><b>${money(ll.qty*ll.price)}</b></div>
  </div>`:'';

  /* Ödeme ve Kasa Paneli */
  const itemCount=c.items.reduce((a,i)=>a+i.qty,0);
  $('#payPanel').innerHTML=`
    <div class="ptop">
      <div><small>ÜRÜN / KALEM</small><b>${c.items.length} kalem (${num(itemCount)})</b></div>
      <div><small>ARA TOPLAM</small><b>${money(sub)}</b></div>
      <div><small>İSKONTO (₺)</small><input type="number" inputmode="decimal" step="0.01" min="0" value="${c.discount||''}" placeholder="0" onchange="curCart().discount=Math.max(0,parse(this.value));drawCart()"></div>
      <div class="grand"><small>ÖDENECEK TUTAR</small><b>${money(tot)}</b></div>
    </div>
    <div class="pay">
      <button class="${c.method==='nakit'?'on':''}" onclick="curCart().method='nakit';drawCart()">💵 NAKİT</button>
      <button class="${c.method==='kart'?'on':''}" onclick="curCart().method='kart';drawCart()">💳 KREDİ KARTI</button>
      <button class="${c.method==='parcali'?'on':''}" onclick="curCart().method='parcali';initSplitPay(${tot});drawCart()">🌗 PARÇALI</button>
      <button class="${c.method==='veresiye'?'on':''}" onclick="curCart().method='veresiye';drawCart()">📒 VERESİYE</button>
    </div>
    ${c.method==='parcali'?(()=>{
      const scash = parse(c.paidCash || 0);
      const scard = parse(c.paidCard || 0);
      const stotal = round2(scash + scard);
      const sdiff = round2(tot - stotal);
      const isExact = Math.abs(sdiff) < 0.01 && (scash > 0 || scard > 0);
      return `<div id="splitBoxContainer" style="background:#f8fafc;border:1.5px solid ${isExact?'#22c55e':'#f59e0b'};border-radius:10px;padding:10px;margin:6px 0">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px">
          <span style="font-size:12px;font-weight:700;color:var(--navy)">🌗 Parçalı Ödeme Dağılımı:</span>
          <span id="splitStatusLabel" style="font-size:12px;font-weight:700;color:${isExact?'#16a34a':'#d97706'}">
            ${isExact ? '✓ Tutar Tam Eşleşti' : (sdiff > 0 ? `Kalan Dağıtılacak: ${money(sdiff)}` : `Fazla Dağıtıldı: ${money(Math.abs(sdiff))}`)}
          </span>
        </div>
        <div class="prow" style="gap:10px;margin-bottom:6px">
          <div style="flex:1">
            <label style="font-size:11px;font-weight:700;color:#1e293b;display:block;margin-bottom:2px">💵 Nakit Tutarı (₺)</label>
            <input type="number" id="splitCashInput" inputmode="decimal" step="0.01" value="${c.paidCash !== undefined && c.paidCash !== '' ? c.paidCash : ''}" placeholder="0.00" 
              style="width:100%;font-size:15px;font-weight:700;border:1.5px solid ${scash>0?'#16a34a':'#cbd5e1'};border-radius:6px;padding:6px 8px"
              oninput="handleSplitCashInput(this.value, ${tot})">
          </div>
          <div style="flex:1">
            <label style="font-size:11px;font-weight:700;color:#1e293b;display:block;margin-bottom:2px">💳 Kart / POS Tutarı (₺)</label>
            <input type="number" id="splitCardInput" inputmode="decimal" step="0.01" value="${c.paidCard !== undefined && c.paidCard !== '' ? c.paidCard : ''}" placeholder="0.00" 
              style="width:100%;font-size:15px;font-weight:700;border:1.5px solid ${scard>0?'#2563eb':'#cbd5e1'};border-radius:6px;padding:6px 8px"
              oninput="handleSplitCardInput(this.value, ${tot})">
          </div>
        </div>
        <div style="display:flex;gap:6px;justify-content:flex-end">
          <button type="button" class="btn sm ln" onclick="setSplitHalf(${tot})" style="font-size:11px;padding:3px 8px">Yarı Yarıya (%50 - %50)</button>
        </div>
      </div>`;
    })():''}
    ${c.method==='veresiye'?`<div class="prow" style="flex-wrap:wrap">
      <div style="flex:2;min-width:180px">
        <select onchange="curCart().cust=this.value">
          ${'<option value="">— Müşteri Seçin —</option>'+S.customers.map(cu=>`<option value="${cu.id}" ${cu.id===c.cust?'selected':''}>${h(cu.name)} (Borç: ${money(balanceOf(cu.id))})</option>`).join('')}
        </select>
      </div>
      <button class="btn or" onclick="custForm(null,true)">+ Yeni Müşteri</button>
      <div style="min-width:130px"><input type="date" value="${c.due}" onchange="curCart().due=this.value" title="Vade Tarihi"></div>
    </div>`:''}
    ${c.method==='nakit'?`<div class="nakit-panel-wrap">
      <div class="nakit-top-row">
        <div class="nakit-inp-box">
          <label class="nakit-lbl">💵 ALINAN NAKİT (₺)</label>
          <input id="given" type="number" inputmode="decimal" step="0.01" value="${c.given||''}" placeholder="0.00" oninput="curCart().given=this.value;chg(${tot})">
        </div>
        <div class="chgbox">
          <span>PARA ÜSTÜ</span>
          <b id="chg">—</b>
        </div>
      </div>
      <div class="nakit-quick-btns">
        <button type="button" class="btn ln sm nakit-btn tam-btn" onclick="setQuickGiven('${tot}',${tot})">Tam</button>
        <button type="button" class="btn ln sm nakit-btn" onclick="setQuickGiven('10',${tot})">10 ₺</button>
        <button type="button" class="btn ln sm nakit-btn" onclick="setQuickGiven('20',${tot})">20 ₺</button>
        <button type="button" class="btn ln sm nakit-btn" onclick="setQuickGiven('50',${tot})">50 ₺</button>
        <button type="button" class="btn ln sm nakit-btn" onclick="setQuickGiven('100',${tot})">100 ₺</button>
        <button type="button" class="btn ln sm nakit-btn" onclick="setQuickGiven('200',${tot})">200 ₺</button>
        <button type="button" class="btn ln sm nakit-btn" onclick="setQuickGiven('500',${tot})">500 ₺</button>
      </div>
    </div>`:''}
    <button class="paygo" ${c.items.length?'':'disabled'} onclick="checkout()">✔ SATIŞI ONAYLA <small class="hide-sm">F9</small></button>
  `;

  /* Mobil Sayaçlar ve Kayan Bar Senkronizasyonu */
  const bCount=$('#mposCountBadge');
  const fCount=$('#mposFloatCount');
  const fTot=$('#mposFloatTotal');
  if(bCount) bCount.textContent=c.items.length?`${c.items.length}`:'0';
  if(fCount) fCount.textContent=`${c.items.length} Kalem (${num(itemCount)})`;
  if(fTot) fTot.textContent=money(tot);

  if(c.method==='nakit'&&c.given) chg(tot);
}

function setQuickGiven(val, tot){
  const c = curCart();
  c.given = String(val);
  const inp = $('#given');
  if(inp) inp.value = val;
  chg(tot);
}

function setMode(i,m){
  const c=curCart();const p=findP(c.items[i].pid);
  c.items[i].mode=m;c.items[i].price=m==='roll'?p.rollPrice:p.price;
  drawCart();
}

function setCartPriceMode(i, mode){
  const c=curCart();const p=findP(c.items[i].pid);
  if(!p) return;
  if(mode==='wholesale' && p.wprice){
    c.items[i].price = p.wprice;
    toast(`"${p.name}" için toptan fiyat uygulandı: ${money(p.wprice)}`, 'ok');
  } else {
    c.items[i].price = p.price;
    toast(`"${p.name}" için normal perakende fiyat uygulandı: ${money(p.price)}`, 'ok');
  }
  saveCarts();
  drawCart();
}

function chg(t){
  const g=parse(curCart().given);
  const e=$('#chg');
  if(e) e.textContent=g?money(Math.max(0,g-t)):'—';
}

function initSplitPay(tot){
  const c=curCart();
  if(c.paidCash === undefined && c.paidCard === undefined){
    c.paidCash = '';
    c.paidCard = '';
  }
}

function handleSplitCashInput(rawVal, tot){
  const c = curCart();
  const cardInp = $('#splitCardInput');
  const cashInp = $('#splitCashInput');
  
  if(rawVal === '' || rawVal === null){
    c.paidCash = '';
    c.paidCard = '';
    if(cardInp) cardInp.value = '';
  } else {
    const cash = Math.max(0, parse(rawVal));
    c.paidCash = cash;
    // Kalanı otomatik olarak Karta / POS'a yaz
    const autoCard = round2(Math.max(0, tot - cash));
    c.paidCard = autoCard;
    if(cardInp) cardInp.value = autoCard > 0 ? autoCard : '';
  }
  updateSplitDOMState(tot);
}

function handleSplitCardInput(rawVal, tot){
  const c = curCart();
  const cashInp = $('#splitCashInput');
  const cardInp = $('#splitCardInput');
  
  if(rawVal === '' || rawVal === null){
    c.paidCard = '';
    c.paidCash = '';
    if(cashInp) cashInp.value = '';
  } else {
    const card = Math.max(0, parse(rawVal));
    c.paidCard = card;
    // Kalanı otomatik olarak Nakit'e yaz
    const autoCash = round2(Math.max(0, tot - card));
    c.paidCash = autoCash;
    if(cashInp) cashInp.value = autoCash > 0 ? autoCash : '';
  }
  updateSplitDOMState(tot);
}

function setSplitHalf(tot){
  const c = curCart();
  const half = round2(tot / 2);
  const other = round2(tot - half);
  c.paidCash = half;
  c.paidCard = other;
  const cashInp = $('#splitCashInput');
  const cardInp = $('#splitCardInput');
  if(cashInp) cashInp.value = half;
  if(cardInp) cardInp.value = other;
  updateSplitDOMState(tot);
}

function updateSplitDOMState(tot){
  const c = curCart();
  const cashInp = $('#splitCashInput');
  const cardInp = $('#splitCardInput');
  const box = $('#splitBoxContainer');
  const lbl = $('#splitStatusLabel');
  if(!box || !lbl) return;

  const scash = parse(c.paidCash || 0);
  const scard = parse(c.paidCard || 0);
  const stotal = round2(scash + scard);
  const sdiff = round2(tot - stotal);
  const isExact = Math.abs(sdiff) < 0.01 && (scash > 0 || scard > 0);

  box.style.borderColor = isExact ? '#22c55e' : '#f59e0b';
  lbl.style.color = isExact ? '#16a34a' : '#d97706';
  lbl.textContent = isExact ? '✓ Tutar Tam Eşleşti' : (sdiff > 0 ? `Kalan Dağıtılacak: ${money(sdiff)}` : `Fazla Dağıtıldı: ${money(Math.abs(sdiff))}`);

  if(cashInp) cashInp.style.borderColor = scash > 0 ? '#16a34a' : '#cbd5e1';
  if(cardInp) cardInp.style.borderColor = scard > 0 ? '#2563eb' : '#cbd5e1';
}

/* ---------- Satış Tamamlama ---------- */
async function checkout(){
  const c=curCart();
  if(!c.items.length||busy)return;
  if(c.items.some(l=>l.qty<=0)){toast('Miktar 0 olamaz','err');return}
  if(c.method==='veresiye'){
    if(!c.cust){toast('Veresiye satış için müşteri seçin!','err');return}
    const targetCust = S.customers.find(u=>u.id===c.cust);
    if(targetCust && targetCust.creditLimit && targetCust.creditLimit > 0){
      const currentDebt = balanceOf(targetCust.id);
      const sub = cartSub(c);
      const saleTot = round2(sub - (c.discount || 0));
      const projectedDebt = round2(currentDebt + saleTot);
      if(projectedDebt > targetCust.creditLimit){
        const limitMsg = `⚠️ MÜŞTERİ BORÇ LİMİTİ AŞILDI!\n\nMüşteri: ${targetCust.name}\nMevcut Borç: ${money(currentDebt)}\nBu Satış: ${money(saleTot)}\nToplam Olacak: ${money(projectedDebt)}\nBelirlenen Limit: ${money(targetCust.creditLimit)}\n\nBu satışa yine de İZİN VERİLSİN mi?`;
        if(!confirm(limitMsg)) return;
      }
    }
  }

  if(c.method==='parcali'){
    const sub = cartSub(c);
    const saleTot = round2(sub - (c.discount || 0));
    const cashVal = c.paidCash !== '' && c.paidCash !== undefined ? parse(c.paidCash) : 0;
    const cardVal = c.paidCard !== '' && c.paidCard !== undefined ? parse(c.paidCard) : 0;
    const sumVal = round2(cashVal + cardVal);
    const diffVal = round2(saleTot - sumVal);

    if(cashVal <= 0 && cardVal <= 0){
      toast('Lütfen parçalı ödemede Nakit ve Kart tutarlarını belirleyiniz!', 'err');
      return;
    }
    if(Math.abs(diffVal) >= 0.01){
      if(diffVal > 0){
        toast(`Parçalı ödeme eksik! Kalan ${money(diffVal)} dağıtılmalıdır.`, 'err');
      } else {
        toast(`Parçalı ödeme fazla! ${money(Math.abs(diffVal))} tutarında fazlalık var.`, 'err');
      }
      return;
    }
  }

  // Akıllı Banka / ÖKC POS Cihazı Entegrasyonu Kontrolü
  const cardAmount = c.method === 'kart' ? round2(cartSub(c) - (c.discount || 0)) : (c.method === 'parcali' ? (c.paidCard || 0) : 0);
  if(cardAmount > 0 && localStorage.getItem('msg_pos_auto_prompt') !== 'disabled'){
    const posConfirmed = await promptSmartPosTerminalModal(cardAmount);
    if(!posConfirmed) return;
  }

  busy=true;
  const r=await cmd('sale',{
    items:c.items.map(l=>({pid:l.pid,mode:l.mode,qty:l.qty,price:l.price,kdv:num(findP(l.pid)?.kdv??20)})),
    discount:c.discount||0,
    method:c.method||'nakit',
    paidCash:c.paidCash||0,
    paidCard:c.paidCard||0,
    customerId:c.cust,
    dueDate:c.method==='veresiye'?new Date(c.due+'T23:59:59').toISOString():null
  });
  busy=false;

  if(!r){drawCart();drawGrid();drawQuick();return}

  const sale=S.sales.find(s=>s.id===r.result.saleId);
  const pids=c.items.map(l=>l.pid);

  // Bu sepeti temizle
  c.items=[];c.discount=0;c.cust='';c.given='';lastPid=null;
  toast(`Satış #${sale.no} tamamlandı: ${money(sale.total)}`,'ok');

  pids.map(findP).filter(p=>p&&isLow(p)).forEach(p=>toast(`⚠️ Stok azaldı: ${p.name} (${stockOf(p)})`,'err'));
  drawCart();drawGrid();drawQuick();

  printChoiceModal(sale.id);
  $('#scan')?.focus();
}

/* ==========================================================================
   AKILLI BANKA / ÖKC POS CİHAZI ENTEGRASYON MODÜLÜ (GMP-3 / EFT-POS)
   ========================================================================== */
function promptSmartPosTerminalModal(amount){
  return new Promise((resolve) => {
    const posDevice = localStorage.getItem('msg_pos_device') || 'Hugin / Beko / Ingenico (GMP-3)';
    const posIp = localStorage.getItem('msg_pos_ip') || 'USB / COM Port';

    modal(`
      <div style="text-align:center;padding:12px 6px">
        <div style="font-size:48px;margin-bottom:8px">💳</div>
        <h2 style="margin:0 0 6px;color:var(--navy);font-size:22px">POS Cihazına Tutar Aktarılıyor...</h2>
        <div style="background:#091224;border:2px solid #3b82f6;border-radius:14px;padding:16px;margin:14px 0">
          <small style="color:#94a3b8;font-weight:700">POS CİHAZINA GÖNDERİLEN TUTAR</small>
          <div style="font-size:38px;font-weight:900;color:#60a5fa;margin:4px 0">${money(amount)}</div>
          <div style="font-size:12px;color:#94a3b8">
            Cihaz: <b style="color:#fff">${h(posDevice)}</b> • Bağlantı: <b style="color:#fff">${h(posIp)}</b>
          </div>
        </div>

        <div style="display:flex;align-items:center;justify-content:center;gap:10px;margin-bottom:18px">
          <div style="width:12px;height:12px;border-radius:50%;background:#3b82f6;animation:scalePulse 1.2s infinite"></div>
          <span style="font-size:14px;color:#334155;font-weight:600">POS cihazından kartı okutunuz veya temassız yaklaştırınız...</span>
        </div>

        <div style="display:flex;gap:10px;justify-content:center">
          <button class="btn ln" onclick="closeModal();resolve(false)">✕ İşlemi İptal Et</button>
          <button class="btn ok lg" onclick="closeModal();resolve(true)" style="background:#16a34a;color:#fff;font-weight:800;padding:12px 24px">
            ✔ POS Onaylandı (Satışı Bitir)
          </button>
        </div>
      </div>
    `);
  });
}

/* ==========================================================================
   WHATSAPP DİJİTAL FİŞ MOTORU (GÖRSEL JPG / PDF / PANO ENTEGRASYONU)
   ========================================================================== */

function drawQRCodeOnCanvas(ctx, text, x, y, size){
  if(typeof ZXing !== 'undefined' && ZXing.QRCodeWriter){
    try {
      const writer = new ZXing.QRCodeWriter();
      const matrix = writer.encode(text, ZXing.BarcodeFormat.QR_CODE, size, size, new Map());
      const w = matrix.getWidth();
      const h = matrix.getHeight();
      const pw = size / w;
      const ph = size / h;
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(x - 6, y - 6, size + 12, size + 12);
      ctx.fillStyle = '#14213d';
      for(let i = 0; i < h; i++){
        for(let j = 0; j < w; j++){
          if(matrix.get(j, i)){
            ctx.fillRect(Math.round(x + j * pw), Math.round(y + i * ph), Math.ceil(pw), Math.ceil(ph));
          }
        }
      }
      return true;
    } catch(e) {
      console.warn('QR draw error:', e);
    }
  }
  return false;
}

function generateReceiptCanvas(saleId){
  const s = S.sales.find(x => x.id === saleId);
  if(!s) return null;
  const c = S.customers.find(x => x.id === s.customerId);
  const sec = getActiveSector();
  const shop = (S.settings?.shop || sec?.name || 'MSG YAZILIM').trim();
  const phone = (S.settings?.phone || '').trim();
  const addr = (S.settings?.address || '').trim();
  const payTxt = ({nakit:'Nakit', kart:'Kredi Kartı', veresiye:'Veresiye', parcali:`Parçalı (Nakit: ${money(s.paidCash)} + Kart: ${money(s.paidCard)})`})[s.method] || s.method;

  const canvas = document.createElement('canvas');
  const ctx = canvas.getContext('2d');

  const W = 620;
  const scale = 2;

  // Dinamik yükseklik hesaplama
  const kdvInfo = calculateKdvBreakdown(s.items, s.discount, s.total);
  let H = 340;
  H += (s.items.length * 52);
  if(s.discount) H += 48;
  else if(s.items.length > 1) H += 26;
  if(c && s.method === 'veresiye') H += 28;
  if(addr || phone) H += 24;
  if(kdvInfo.groups && kdvInfo.groups.length > 0) H += 36 + (kdvInfo.groups.length * 19);
  H += 190;

  canvas.width = W * scale;
  canvas.height = H * scale;
  ctx.scale(scale, scale);

  // Arka plan
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(0, 0, W, H);

  // Dış çerçeve
  ctx.strokeStyle = '#e2e8f0';
  ctx.lineWidth = 1;
  ctx.strokeRect(0, 0, W, H);

  // Üst modern renk şeridi
  const grad = ctx.createLinearGradient(0, 0, W, 0);
  grad.addColorStop(0, '#14213d');
  grad.addColorStop(1, '#2563eb');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, W, 12);

  let y = 44;

  // Firma Adı
  ctx.textAlign = 'center';
  ctx.fillStyle = '#14213d';
  ctx.font = 'bold 26px "Segoe UI", system-ui, sans-serif';
  const displayShop = shop.toUpperCase();
  ctx.fillText(displayShop, W / 2, y);
  y += 24;

  // Fiş Başlığı / Rozet
  ctx.fillStyle = '#d97706';
  ctx.font = 'bold 13px "Segoe UI", system-ui, sans-serif';
  ctx.fillText('🧾 DİJİTAL PERAKENDE SATIŞ FİŞİ', W / 2, y);
  y += 20;

  // Adres & Telefon
  if(addr || phone){
    ctx.fillStyle = '#64748b';
    ctx.font = '12px "Segoe UI", system-ui, sans-serif';
    const contactLine = [addr, phone ? `Tel: ${phone}` : ''].filter(Boolean).join(' • ');
    ctx.fillText(contactLine, W / 2, y);
    y += 20;
  }

  y += 6;

  // Kesikli ayraç çizgisi
  ctx.setLineDash([5, 5]);
  ctx.strokeStyle = '#cbd5e1';
  ctx.beginPath();
  ctx.moveTo(24, y);
  ctx.lineTo(W - 24, y);
  ctx.stroke();
  ctx.setLineDash([]);
  y += 18;

  // Fiş Bilgi Kartı (Fiş No, Tarih, Kasiyer, Müşteri)
  const metaBoxY = y;
  const metaBoxH = 68;
  ctx.fillStyle = '#f8fafc';
  ctx.beginPath();
  if(ctx.roundRect) ctx.roundRect(24, metaBoxY, W - 48, metaBoxH, 10);
  else ctx.rect(24, metaBoxY, W - 48, metaBoxH);
  ctx.fill();
  ctx.strokeStyle = '#e2e8f0';
  ctx.stroke();

  ctx.textAlign = 'left';
  // Sol sütun
  ctx.fillStyle = '#475569';
  ctx.font = '12px "Segoe UI", system-ui, sans-serif';
  ctx.fillText('Fiş No:', 38, metaBoxY + 26);
  ctx.fillStyle = '#14213d';
  ctx.font = 'bold 15px "Segoe UI", system-ui, sans-serif';
  ctx.fillText(`#${s.no}`, 88, metaBoxY + 26);

  ctx.fillStyle = '#475569';
  ctx.font = '12px "Segoe UI", system-ui, sans-serif';
  ctx.fillText('Tarih:', 38, metaBoxY + 50);
  ctx.fillStyle = '#1e293b';
  ctx.font = '600 12px "Segoe UI", system-ui, sans-serif';
  ctx.fillText(fdt(s.date), 88, metaBoxY + 50);

  // Sağ sütun
  const midX = W / 2 + 10;
  ctx.fillStyle = '#475569';
  ctx.font = '12px "Segoe UI", system-ui, sans-serif';
  ctx.fillText('Kasiyer:', midX, metaBoxY + 26);
  ctx.fillStyle = '#1e293b';
  ctx.font = '600 12px "Segoe UI", system-ui, sans-serif';
  ctx.fillText(s.cashier || 'Yönetici', midX + 54, metaBoxY + 26);

  ctx.fillStyle = '#475569';
  ctx.font = '12px "Segoe UI", system-ui, sans-serif';
  ctx.fillText('Müşteri:', midX, metaBoxY + 50);
  ctx.fillStyle = '#1e293b';
  ctx.font = 'bold 12px "Segoe UI", system-ui, sans-serif';
  const custName = (c ? c.name : 'Perakende Müşteri');
  ctx.fillText(custName.length > 20 ? custName.slice(0, 20) + '…' : custName, midX + 54, metaBoxY + 50);

  y = metaBoxY + metaBoxH + 18;

  // Ürün Tablo Başlığı
  ctx.fillStyle = '#14213d';
  ctx.beginPath();
  if(ctx.roundRect) ctx.roundRect(24, y, W - 48, 30, 6);
  else ctx.rect(24, y, W - 48, 30);
  ctx.fill();

  ctx.fillStyle = '#ffffff';
  ctx.font = 'bold 11px "Segoe UI", system-ui, sans-serif';
  ctx.textAlign = 'left';
  ctx.fillText('ÜRÜN ADI', 36, y + 19);
  ctx.textAlign = 'center';
  ctx.fillText('ADET x BİRİM', W - 170, y + 19);
  ctx.textAlign = 'right';
  ctx.fillText('TUTAR', W - 36, y + 19);
  y += 38;

  // Ürün Satırları
  s.items.forEach((it, idx) => {
    const isEven = idx % 2 === 0;
    if(isEven){
      ctx.fillStyle = '#f8fafc';
      ctx.fillRect(24, y - 6, W - 48, 46);
    }

    // Ürün İsmi
    ctx.textAlign = 'left';
    ctx.fillStyle = '#0f172a';
    ctx.font = 'bold 13px "Segoe UI", system-ui, sans-serif';
    let pTitle = `${idx + 1}. ${it.name}`;
    if(it.variant) pTitle += ` (${it.variant})`;
    if(pTitle.length > 34) pTitle = pTitle.slice(0, 33) + '…';
    ctx.fillText(pTitle, 36, y + 14);

    // Miktar x Fiyat
    ctx.textAlign = 'center';
    ctx.fillStyle = '#475569';
    ctx.font = '600 12px "Segoe UI", system-ui, sans-serif';
    ctx.fillText(`${num(it.qty)} ${it.unit || 'adet'} × ${money(it.price)}`, W - 170, y + 26);

    // Satır Tutarı
    ctx.textAlign = 'right';
    ctx.fillStyle = '#14213d';
    ctx.font = 'bold 14px "Segoe UI", system-ui, sans-serif';
    ctx.fillText(money(round2(it.qty * it.price)), W - 36, y + 26);

    // Çizgi
    ctx.strokeStyle = '#f1f5f9';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(28, y + 36);
    ctx.lineTo(W - 28, y + 36);
    ctx.stroke();

    y += 48;
  });

  y += 6;

  // Kesikli çizgi
  ctx.setLineDash([5, 5]);
  ctx.strokeStyle = '#cbd5e1';
  ctx.beginPath();
  ctx.moveTo(24, y);
  ctx.lineTo(W - 24, y);
  ctx.stroke();
  ctx.setLineDash([]);
  y += 18;

  // İskonto ve Ara Toplam
  const subTotalVal = s.subtotal || round2(s.total + (s.discount || 0));
  if(s.discount || s.items.length > 1){
    ctx.textAlign = 'left';
    ctx.fillStyle = '#64748b';
    ctx.font = '13px "Segoe UI", system-ui, sans-serif';
    ctx.fillText('Ara Toplam:', 36, y + 14);
    ctx.textAlign = 'right';
    ctx.fillText(money(subTotalVal), W - 36, y + 14);
    y += 22;
  }

  if(s.discount){
    ctx.textAlign = 'left';
    ctx.fillStyle = '#dc2626';
    ctx.font = '13px "Segoe UI", system-ui, sans-serif';
    ctx.fillText('İskonto:', 36, y + 14);
    ctx.textAlign = 'right';
    ctx.fillText(`- ${money(s.discount)}`, W - 36, y + 14);
    y += 24;
  }

  // GENEL TOPLAM Vurgu Kutusu
  const totalBoxY = y;
  const totalBoxH = 58;
  const tGrad = ctx.createLinearGradient(24, totalBoxY, W - 24, totalBoxY);
  tGrad.addColorStop(0, '#14213d');
  tGrad.addColorStop(1, '#1e293b');
  ctx.fillStyle = tGrad;
  ctx.beginPath();
  if(ctx.roundRect) ctx.roundRect(24, totalBoxY, W - 48, totalBoxH, 10);
  else ctx.rect(24, totalBoxY, W - 48, totalBoxH);
  ctx.fill();

  ctx.textAlign = 'left';
  ctx.fillStyle = '#e2e8f0';
  ctx.font = 'bold 15px "Segoe UI", system-ui, sans-serif';
  ctx.fillText('GENEL TOPLAM', 42, totalBoxY + 36);

  ctx.textAlign = 'right';
  ctx.fillStyle = '#fca311';
  ctx.font = 'bold 24px "Segoe UI", system-ui, sans-serif';
  ctx.fillText(money(s.total), W - 42, totalBoxY + 37);

  y = totalBoxY + totalBoxH + 16;

  // KDV Dağılım Tablosu (Resmi KDV Detayı)
  if(kdvInfo.groups && kdvInfo.groups.length > 0){
    const kdvBoxY = y;
    const kdvBoxH = 26 + (kdvInfo.groups.length * 18);
    ctx.fillStyle = '#f8fafc';
    ctx.beginPath();
    if(ctx.roundRect) ctx.roundRect(24, kdvBoxY, W - 48, kdvBoxH, 6);
    else ctx.rect(24, kdvBoxY, W - 48, kdvBoxH);
    ctx.fill();
    ctx.strokeStyle = '#e2e8f0';
    ctx.stroke();

    ctx.fillStyle = '#64748b';
    ctx.font = 'bold 10px "Segoe UI", system-ui, sans-serif';
    ctx.textAlign = 'left';
    ctx.fillText('KDV ORANI & TÜRÜ', 36, kdvBoxY + 16);
    ctx.textAlign = 'center';
    ctx.fillText('KDV MATRAHI (KDV HARİÇ)', W / 2 + 10, kdvBoxY + 16);
    ctx.textAlign = 'right';
    ctx.fillText('HESAPLANAN KDV', W - 36, kdvBoxY + 16);

    let ky = kdvBoxY + 32;
    kdvInfo.groups.forEach(g => {
      ctx.textAlign = 'left';
      ctx.fillStyle = '#334155';
      ctx.font = '11px "Segoe UI", system-ui, sans-serif';
      ctx.fillText(`%${g.rate} (${g.label})`, 36, ky);

      ctx.textAlign = 'center';
      ctx.fillStyle = '#475569';
      ctx.fillText(money(g.matrah), W / 2 + 10, ky);

      ctx.textAlign = 'right';
      ctx.fillStyle = '#0f172a';
      ctx.font = 'bold 11px "Segoe UI", system-ui, sans-serif';
      ctx.fillText(money(g.kdv), W - 36, ky);

      ky += 18;
    });

    y = kdvBoxY + kdvBoxH + 14;
  }

  // Ödeme Yöntemi
  ctx.textAlign = 'left';
  ctx.fillStyle = '#475569';
  ctx.font = '12px "Segoe UI", system-ui, sans-serif';
  ctx.fillText('Ödeme Şekli:', 36, y + 14);
  ctx.fillStyle = '#1e293b';
  ctx.font = 'bold 13px "Segoe UI", system-ui, sans-serif';
  ctx.fillText(payTxt, 115, y + 14);

  if(c && s.method === 'veresiye'){
    const bal = balanceOf(c.id);
    y += 22;
    ctx.textAlign = 'left';
    ctx.fillStyle = '#dc2626';
    ctx.font = 'bold 12px "Segoe UI", system-ui, sans-serif';
    ctx.fillText(`Kalan Güncel Veresiye Borcunuz: ${money(bal)}`, 36, y + 14);
  }

  y += 32;

  // QR Kod
  const qrSize = 100;
  const qrX = (W - qrSize) / 2;
  const qrText = `${shop} - Fis #${s.no} - Toplam: ${money(s.total)} - ${fdt(s.date)}`;
  const hasQr = drawQRCodeOnCanvas(ctx, qrText, qrX, y, qrSize);
  if(hasQr){
    y += qrSize + 16;
    ctx.textAlign = 'center';
    ctx.fillStyle = '#94a3b8';
    ctx.font = '11px "Segoe UI", system-ui, sans-serif';
    ctx.fillText('Fiş Doğrulama & İletişim Karekodu', W / 2, y);
    y += 20;
  }

  // Alt Bilgi & Teşekkür
  ctx.textAlign = 'center';
  ctx.fillStyle = '#94a3b8';
  ctx.font = 'italic 11px "Segoe UI", system-ui, sans-serif';
  ctx.fillText('Mali değeri yoktur • Bilgi amaçlı düzenlenmiştir.', W / 2, y);
  y += 18;

  ctx.fillStyle = '#14213d';
  ctx.font = 'bold 13px "Segoe UI", system-ui, sans-serif';
  ctx.fillText('Bizi tercih ettiğiniz için teşekkür ederiz! 🙏', W / 2, y);

  return canvas;
}

function getWaReceiptMessage(saleId){
  const s = S.sales.find(x => x.id === saleId);
  if(!s) return '';
  const c = S.customers.find(x => x.id === s.customerId);
  const sec = getActiveSector();
  const shop = (S.settings?.shop || sec?.name || 'MSG YAZILIM').trim();
  const payTxt = ({nakit:'Nakit', kart:'Kredi Kartı', veresiye:'Veresiye', parcali:`Parçalı (Nakit: ${money(s.paidCash)} + Kart: ${money(s.paidCard)})`})[s.method] || s.method;
  const kdvInfo = calculateKdvBreakdown(s.items, s.discount, s.total);
  
  let msg = `*${shop.toUpperCase()}*\n`;
  msg += `🧾 *DİJİTAL SATIŞ FİŞİ #${s.no}*\n`;
  msg += `📅 Tarih: ${fdt(s.date)}\n`;
  if(c) msg += `👤 Müşteri: ${c.name}\n`;
  msg += `------------------------\n`;
  s.items.forEach((it, idx) => {
    const itKdv = it.kdv !== undefined ? ` (%${it.kdv} KDV)` : '';
    msg += `${idx+1}. ${it.name} ${it.variant?`(${it.variant})`:''}${itKdv}\n`;
    msg += `   ${num(it.qty)} ${it.unit||'adet'} x ${money(it.price)} = *${money(round2(it.qty*it.price))}*\n`;
  });
  msg += `------------------------\n`;
  if(s.discount || s.items.length > 1) msg += `Ara Toplam: ${money(s.subtotal || round2(s.total + (s.discount||0)))}\n`;
  if(s.discount) msg += `İskonto: -${money(s.discount)}\n`;
  msg += `💰 *GENEL TOPLAM: ${money(s.total)}*\n`;
  if(kdvInfo.groups && kdvInfo.groups.length > 0){
    msg += `\n*KDV Dağılımı (Dahil):*\n`;
    kdvInfo.groups.forEach(g => {
      msg += ` • %${g.rate} KDV: Matrah: ${money(g.matrah)} | KDV: *${money(g.kdv)}*\n`;
    });
    msg += ` • Toplam Hesaplanan KDV: *${money(kdvInfo.totalKdv)}*\n`;
  }
  msg += `\n💳 Ödeme Şekli: ${payTxt}\n`;
  if(c && s.method==='veresiye'){
    const bal = balanceOf(c.id);
    msg += `📌 Güncel Kalan Borcunuz: *${money(bal)}*\n`;
  }
  msg += `\nSayın Müşterimiz, alışveriş fişinizin görseli hazırlanmıştır.\nBizi tercih ettiğiniz için teşekkür ederiz! 🙏`;
  return msg;
}

// Aktif fiş görseli referansı
let currentWaReceiptCanvas = null;

// PDF Blob oluşturucu (Saf JavaScript - Harici kütüphane gerektirmez)
async function canvasToPdfBlob(canvas){
  const jpegBlob = await new Promise(res => canvas.toBlob(res, 'image/jpeg', 0.95));
  const arrayBuffer = await jpegBlob.arrayBuffer();
  const jpegBytes = new Uint8Array(arrayBuffer);
  const imgWidth = canvas.width;
  const imgHeight = canvas.height;

  // Termal / A5 uyumlu PDF punto genişliği: 320 pt
  const ptWidth = 320;
  const ptHeight = Math.round(ptWidth * (imgHeight / imgWidth));

  const chunks = [];
  const offsets = [];
  let pos = 0;

  function writeStr(str){
    const bytes = new TextEncoder().encode(str);
    chunks.push(bytes);
    pos += bytes.length;
  }
  function writeBytes(b){
    chunks.push(b);
    pos += b.length;
  }

  writeStr("%PDF-1.4\n%\xFF\xFF\xFF\xFF\n");
  offsets[1] = pos;
  writeStr("1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj\n");
  offsets[2] = pos;
  writeStr("2 0 obj\n<< /Type /Pages /Kids [3 0 R] /Count 1 >>\nendobj\n");
  offsets[3] = pos;
  writeStr(`3 0 obj\n<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${ptWidth} ${ptHeight}] /Resources << /XObject << /Im1 4 0 R >> >> /Contents 5 0 R >>\nendobj\n`);
  offsets[4] = pos;
  writeStr(`4 0 obj\n<< /Type /XObject /Subtype /Image /Width ${imgWidth} /Height ${imgHeight} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${jpegBytes.length} >>\nstream\n`);
  writeBytes(jpegBytes);
  writeStr("\nendstream\nendobj\n");
  offsets[5] = pos;
  const content = `q\n${ptWidth} 0 0 ${ptHeight} 0 0 cm\n/Im1 Do\nQ\n`;
  const contentBytes = new TextEncoder().encode(content);
  writeStr(`5 0 obj\n<< /Length ${contentBytes.length} >>\nstream\n${content}endstream\nendobj\n`);
  const xrefOffset = pos;
  writeStr("xref\n0 6\n0000000000 65535 f \n");
  for (let i = 1; i <= 5; i++){
    writeStr(offsets[i].toString().padStart(10, "0") + " 00000 n \n");
  }
  writeStr(`trailer\n<< /Size 6 /Root 1 0 R >>\nstartxref\n${xrefOffset}\n%%EOF\n`);

  return new Blob(chunks, { type: 'application/pdf' });
}

function sendReceiptViaWa(saleId, phoneInput){
  const s = S.sales.find(x => x.id === saleId);
  if(!s) return;
  const c = S.customers.find(x => x.id === s.customerId);
  const sec = getActiveSector();
  const shop = (S.settings?.shop || sec?.name || 'MSG YAZILIM').trim();
  const targetPhone = phoneInput || (c?.phone) || '';

  // Geniş, modern ve dokunmatik uyumlu WhatsApp Dijital Fiş Modalı
  modal(`
    <div style="padding:4px 2px">
      <!-- Başlık Çubuğu -->
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px;border-bottom:1px solid var(--line);padding-bottom:10px">
        <div style="display:flex;align-items:center;gap:12px">
          <div style="width:44px;height:44px;border-radius:12px;background:#25d366;color:#fff;display:flex;align-items:center;justify-content:center;font-size:24px;box-shadow:0 4px 12px rgba(37,211,102,0.3)">💬</div>
          <div>
            <h3 style="margin:0;font-size:18px;color:var(--navy);font-weight:800">WhatsApp Dijital Fiş Gönderimi</h3>
            <small style="color:#64748b">Fiş #${s.no} • <b>${h(shop)}</b> ${c?`• Müşteri: <b>${h(c.name)}</b>`:''}</small>
          </div>
        </div>
        <button class="btn ln sm" onclick="closeModal()">✕</button>
      </div>

      <!-- Telefon Numarası Girişi -->
      <div style="background:#f0fdf4;border:1px solid #bbf7d0;border-radius:14px;padding:12px 14px;margin-bottom:14px">
        <label style="display:block;font-size:13px;font-weight:700;margin-bottom:6px;color:#166534">
          📱 Müşteri WhatsApp Telefon Numarası:
        </label>
        <div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap">
          <input id="waPhoneInput" type="tel" value="${h(targetPhone)}" placeholder="05xx xxx xx xx (Opsiyonel / Rehberden seçilebilir)" 
            onkeydown="if(event.key==='Enter') waSendJpg('${s.id}')"
            style="flex:1;min-width:200px;font-size:15px;font-weight:700;padding:10px 14px;border-radius:10px;border:2px solid #86efac;background:#fff" />
        </div>
        <div style="font-size:11px;color:#15803d;margin-top:6px;display:flex;align-items:center;gap:5px">
          <span>💡</span> <span><b>Mobilde:</b> Numara girmeden de doğrudan WhatsApp rehberinizden müşteri seçip gönderebilirsiniz.</span>
        </div>
      </div>

      <!-- ANA GÖNDERME BUTONLARI (RESİM / PDF) -->
      <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(210px,1fr));gap:10px;margin-bottom:14px">
        <button class="btn ok lg" onclick="waSendJpg('${s.id}')" style="background:#16a34a;color:#fff;font-weight:800;padding:14px 12px;border-radius:12px;display:flex;align-items:center;gap:10px;box-shadow:0 4px 12px rgba(22,163,74,0.25)">
          <span style="font-size:26px">📸</span>
          <div style="text-align:left">
            <div style="font-size:15px;line-height:1.2">Görsel (JPG) Olarak Gönder</div>
            <small style="opacity:0.9;font-weight:normal;font-size:11px">Doğrudan resim olarak WhatsApp'a iletir</small>
          </div>
        </button>

        <button class="btn lg" onclick="waSendPdf('${s.id}')" style="background:#2563eb;color:#fff;font-weight:800;padding:14px 12px;border-radius:12px;display:flex;align-items:center;gap:10px;box-shadow:0 4px 12px rgba(37,99,235,0.25)">
          <span style="font-size:26px">📄</span>
          <div style="text-align:left">
            <div style="font-size:15px;line-height:1.2">PDF Belgesi Olarak Gönder</div>
            <small style="opacity:0.9;font-weight:normal;font-size:11px">PDF fiş dosyası olarak WhatsApp'a iletir</small>
          </div>
        </button>
      </div>

      <!-- Önizleme ve Hızlı Araçlar -->
      <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:14px;align-items:start">
        <!-- Sol: Canlı Fiş Önizleme -->
        <div style="text-align:center;background:#f8fafc;border-radius:12px;padding:12px;border:1px solid #e2e8f0">
          <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px">
            <span style="font-size:12px;font-weight:700;color:#475569">🧾 Hazırlanan Fiş Önizlemesi:</span>
            <span class="tag t-ok" style="font-size:11px">HD Çözünürlük</span>
          </div>
          <div id="waReceiptPreviewBox" style="max-height:320px;overflow-y:auto;border-radius:8px;box-shadow:0 4px 12px rgba(0,0,0,0.06);background:#fff;display:inline-block;width:100%">
            <div style="padding:40px;color:#94a3b8">Fiş oluşturuluyor...</div>
          </div>
        </div>

        <!-- Sağ: Alternatif İndirme & Format Seçenekleri -->
        <div style="display:flex;flex-direction:column;gap:8px">
          <div style="font-size:11px;font-weight:700;color:#64748b;margin-bottom:2px">DİĞER SEÇENEKLER & İNDİRME:</div>

          <button class="btn" onclick="waDownloadJpg('${s.id}')" style="background:#0284c7;color:#fff;font-weight:700;padding:10px 12px;border-radius:10px;display:flex;align-items:center;gap:10px;text-align:left">
            <span style="font-size:20px">📥</span>
            <div>
              <div style="font-size:13px">JPG Resim İndir</div>
              <small style="opacity:0.85;font-weight:normal">Fis_${s.no}.jpg olarak cihaza kaydeder</small>
            </div>
          </button>

          <button class="btn" onclick="waDownloadPdf('${s.id}')" style="background:#4f46e5;color:#fff;font-weight:700;padding:10px 12px;border-radius:10px;display:flex;align-items:center;gap:10px;text-align:left">
            <span style="font-size:20px">📑</span>
            <div>
              <div style="font-size:13px">PDF Fiş İndir</div>
              <small style="opacity:0.85;font-weight:normal">Fis_${s.no}.pdf olarak kaydeder</small>
            </div>
          </button>

          <button class="btn" onclick="waCopyImageOnly('${s.id}')" style="background:#d97706;color:#fff;font-weight:700;padding:10px 12px;border-radius:10px;display:flex;align-items:center;gap:10px;text-align:left">
            <span style="font-size:20px">📋</span>
            <div>
              <div style="font-size:13px">Görseli Panoya Kopyala</div>
              <small style="opacity:0.85;font-weight:normal">Panoya kopyalar, sohbete Ctrl+V ile yapıştırın</small>
            </div>
          </button>

          <button class="btn ln" onclick="waSendTextOnly('${s.id}')" style="padding:9px 12px;border-radius:10px;color:#475569;font-weight:600;text-align:left;display:flex;align-items:center;gap:8px">
            <span>💬</span>
            <div>
              <div style="font-size:12px">Sadece Sade Metin Olarak Gönder</div>
              <small style="opacity:0.85;font-weight:normal">Görsel olmadan salt metin mesajı atar</small>
            </div>
          </button>

          <div style="margin-top:auto;padding-top:10px;display:flex;gap:8px">
            <button class="btn ln sm" onclick="printChoiceModal('${s.id}')" style="flex:1">⬅️ Fiş Seçeneklerine Dön</button>
            <button class="btn ln sm" onclick="closeModal()" style="flex:1">✕ Kapat</button>
          </div>
        </div>
      </div>
    </div>
  `, true);

  // Fiş görselini asenkron oluştur ve önizlemeye yerleştir
  setTimeout(() => {
    try {
      const canvas = generateReceiptCanvas(saleId);
      if(!canvas) return;
      currentWaReceiptCanvas = canvas;

      const img = new Image();
      img.src = canvas.toDataURL('image/jpeg', 0.95);
      img.style.width = '100%';
      img.style.height = 'auto';
      img.style.display = 'block';
      img.style.borderRadius = '8px';

      const previewBox = document.getElementById('waReceiptPreviewBox');
      if(previewBox){
        previewBox.innerHTML = '';
        previewBox.appendChild(img);
      }
    } catch(err) {
      console.error('Receipt preview error:', err);
    }
  }, 50);
}

// 1. WhatsApp ile JPG (Görsel) Gönderimi
async function waSendJpg(saleId){
  const s = S.sales.find(x => x.id === saleId);
  if(!s) return;
  const canvas = currentWaReceiptCanvas || generateReceiptCanvas(saleId);
  if(!canvas){ toast('Fiş oluşturulamadı', 'err'); return; }

  const sec = getActiveSector();
  const shop = (S.settings?.shop || sec?.name || 'MSG YAZILIM').trim();
  const input = document.getElementById('waPhoneInput');
  const rawPhone = (input ? input.value : '') || '';
  const cleanPhone = cleanPhoneForWa(rawPhone);

  const captionMsg = `*${shop.toUpperCase()}*\n🧾 *Dijital Satış Fişiniz (#${s.no})*\n📅 Tarih: ${fdt(s.date)}\n💰 Toplam Tutar: *${money(s.total)}*\n\nAlışveriş fişinizin görseli ekte sunulmuştur. Bizi tercih ettiğiniz için teşekkür ederiz! 🙏`;

  // Mobilde doğrudan dosya paylaşımı (Web Share API)
  try {
    const blob = await new Promise(res => canvas.toBlob(res, 'image/jpeg', 0.95));
    const safeShop = shop.replace(/[^a-zA-Z0-9çşğüöıİĞÜŞÖÇ_]/g, '_');
    const file = new File([blob], `Fis_${s.no}_${safeShop}.jpg`, { type: 'image/jpeg' });

    if(navigator.canShare && navigator.canShare({ files: [file] })){
      await navigator.share({
        title: `${shop} - Fiş #${s.no}`,
        text: captionMsg,
        files: [file]
      });
      toast('✅ WhatsApp paylaşım penceresi açıldı', 'ok');
      return;
    }
  } catch(err) {
    if(err.name === 'AbortError') return;
    console.warn('Native share error:', err);
  }

  // Masaüstü / Desteklenmeyen Tarayıcı Fallback:
  let copied = false;
  try {
    const pngBlob = await new Promise(res => canvas.toBlob(res, 'image/png'));
    if(navigator.clipboard && window.ClipboardItem && pngBlob){
      await navigator.clipboard.write([
        new ClipboardItem({ 'image/png': pngBlob })
      ]);
      copied = true;
    }
  } catch(e) {
    console.warn('Clipboard write error:', e);
  }

  waDownloadJpg(saleId, false);

  if(cleanPhone && cleanPhone.length >= 10){
    const url = `https://wa.me/${cleanPhone}?text=${encodeURIComponent(captionMsg)}`;
    window.open(url, '_blank');
  } else {
    window.open('https://web.whatsapp.com', '_blank');
  }

  if(copied){
    toast('✅ Fiş resmi panoya kopyalandı! WhatsApp açıldığında sohbete Ctrl+V (Yapıştır) yapıp doğrudan resim olarak gönderin.', 'ok');
  } else {
    toast('✅ Fiş JPG indirildi! WhatsApp açıldığında indirilen görseli sohbete sürükleyip gönderin.', 'ok');
  }
}

// 2. WhatsApp ile PDF Belgesi Gönderimi
async function waSendPdf(saleId){
  const s = S.sales.find(x => x.id === saleId);
  if(!s) return;
  const canvas = currentWaReceiptCanvas || generateReceiptCanvas(saleId);
  if(!canvas){ toast('Fiş oluşturulamadı', 'err'); return; }

  const sec = getActiveSector();
  const shop = (S.settings?.shop || sec?.name || 'MSG YAZILIM').trim();
  const input = document.getElementById('waPhoneInput');
  const rawPhone = (input ? input.value : '') || '';
  const cleanPhone = cleanPhoneForWa(rawPhone);

  const captionMsg = `*${shop.toUpperCase()}*\n🧾 *Dijital Satış Fişiniz (#${s.no})*\n📅 Tarih: ${fdt(s.date)}\n💰 Toplam Tutar: *${money(s.total)}*\n\nAlışveriş fişinizin PDF belgesi ekte sunulmuştur. Bizi tercih ettiğiniz için teşekkür ederiz! 🙏`;

  // Mobilde doğrudan PDF dosya paylaşımı (Web Share API)
  try {
    const pdfBlob = await canvasToPdfBlob(canvas);
    const safeShop = shop.replace(/[^a-zA-Z0-9çşğüöıİĞÜŞÖÇ_]/g, '_');
    const file = new File([pdfBlob], `Fis_${s.no}_${safeShop}.pdf`, { type: 'application/pdf' });

    if(navigator.canShare && navigator.canShare({ files: [file] })){
      await navigator.share({
        title: `${shop} - Fiş #${s.no} (PDF)`,
        text: captionMsg,
        files: [file]
      });
      toast('✅ PDF fiş paylaşım penceresi açıldı', 'ok');
      return;
    }
  } catch(err) {
    if(err.name === 'AbortError') return;
    console.warn('Native share error:', err);
  }

  // Masaüstü Fallback:
  await waDownloadPdf(saleId, false);

  if(cleanPhone && cleanPhone.length >= 10){
    const url = `https://wa.me/${cleanPhone}?text=${encodeURIComponent(captionMsg)}`;
    window.open(url, '_blank');
  } else {
    window.open('https://web.whatsapp.com', '_blank');
  }

  toast('📥 PDF Fiş indirildi! WhatsApp Web açıldığında PDF dosyasını sohbete sürükleyip gönderebilirsiniz.', 'ok');
}

// Geriye dönük uyumluluk için takma ad (alias)
const waSendAction = waSendJpg;
const waNativeShare = waSendJpg;

// JPG İndirme
function waDownloadJpg(saleId, showToast = true){
  const s = S.sales.find(x => x.id === saleId);
  if(!s) return;
  const canvas = currentWaReceiptCanvas || generateReceiptCanvas(saleId);
  if(!canvas) return;

  const sec = getActiveSector();
  const shop = (S.settings?.shop || sec?.name || 'MSG').replace(/[^a-zA-Z0-9çşğüöıİĞÜŞÖÇ_]/g, '_');
  const a = document.createElement('a');
  a.href = canvas.toDataURL('image/jpeg', 0.95);
  a.download = `Fis_${s.no}_${shop}.jpg`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);

  if(showToast) toast(`📥 Fis_${s.no}_${shop}.jpg indirildi`, 'ok');
}

// PDF Fiş İndirme
async function waDownloadPdf(saleId, showToast = true){
  const s = S.sales.find(x => x.id === saleId);
  if(!s) return;
  const canvas = currentWaReceiptCanvas || generateReceiptCanvas(saleId);
  if(!canvas) return;

  const sec = getActiveSector();
  const shop = (S.settings?.shop || sec?.name || 'MSG').replace(/[^a-zA-Z0-9çşğüöıİĞÜŞÖÇ_]/g, '_');
  const pdfBlob = await canvasToPdfBlob(canvas);
  const url = URL.createObjectURL(pdfBlob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `Fis_${s.no}_${shop}.pdf`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 5000);

  if(showToast) toast(`📥 Fis_${s.no}_${shop}.pdf indirildi`, 'ok');
}

// PDF Fiş Açma / Yazdırma
function waPrintOrPdf(saleId){
  printDoc(saleId, 'a5');
}

// Yalnızca Görseli Panoya Kopyalama
async function waCopyImageOnly(saleId){
  const canvas = currentWaReceiptCanvas || generateReceiptCanvas(saleId);
  if(!canvas){
    toast('Görsel hazırlanamadı', 'err');
    return;
  }
  try {
    const pngBlob = await new Promise(res => canvas.toBlob(res, 'image/png'));
    if(navigator.clipboard && window.ClipboardItem && pngBlob){
      await navigator.clipboard.write([
        new ClipboardItem({ 'image/png': pngBlob })
      ]);
      toast('📋 Fiş görseli panoya kopyalandı! İstediğiniz yere Ctrl+V ile yapıştırabilirsiniz.', 'ok');
      return;
    }
  } catch(e) {
    console.warn('Copy error:', e);
  }
  toast('Panoya kopyalama bu tarayıcıda desteklenmiyor, lütfen JPG İndir butonunu kullanın.', 'err');
}

// Sadece Metin WhatsApp
function waSendTextOnly(saleId){
  const s = S.sales.find(x => x.id === saleId);
  if(!s) return;
  const input = document.getElementById('waPhoneInput');
  const rawPhone = (input ? input.value : '') || '';
  const cleanPhone = cleanPhoneForWa(rawPhone);

  if(!cleanPhone || cleanPhone.length < 10){
    toast('Lütfen geçerli bir telefon numarası girin', 'err');
    if(input) input.focus();
    return;
  }

  const msg = getWaReceiptMessage(saleId);
  const url = `https://wa.me/${cleanPhone}?text=${encodeURIComponent(msg)}`;
  window.open(url, '_blank');
}

function printChoiceModal(saleId){
  const s=S.sales.find(x=>x.id===saleId);
  if(!s)return;
  const c=S.customers.find(x=>x.id===s.customerId);
  modal(`
  <div style="text-align:center;padding:10px 4px">
    <div style="font-size:46px;margin-bottom:8px">🧾</div>
    <h2 style="margin:0 0 6px">Satış Tamamlandı • Fiş #${s.no}</h2>
    <p class="mut" style="margin:0 0 18px;font-size:15px">
      Toplam Tutar: <b style="color:var(--navy);font-size:18px">${money(s.total)}</b>
      ${c?` • Müşteri: <b>${h(c.name)}</b>`:''}
    </p>
    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(130px,1fr));gap:10px;margin-bottom:14px">
      <button class="btn or" onclick="receipt('${s.id}');closeModal()" style="padding:14px 6px;border-radius:12px">
        <div style="font-size:22px;margin-bottom:4px">🧾</div>
        <b>Küçük Fiş</b><br><small style="opacity:0.85">80mm / 58mm Termal</small>
      </button>
      <button class="btn" style="background:#2563eb;color:#fff;padding:14px 6px;border-radius:12px" onclick="printDoc('${s.id}','a5');closeModal()">
        <div style="font-size:22px;margin-bottom:4px">📑</div>
        <b>A5 Satış Fişi</b><br><small style="opacity:0.85">Yarım Sayfa</small>
      </button>
      <button class="btn gr" onclick="printDoc('${s.id}','a4');closeModal()" style="padding:14px 6px;border-radius:12px">
        <div style="font-size:22px;margin-bottom:4px">📄</div>
        <b>A4 Fatura / Fiş</b><br><small style="opacity:0.85">Tam Sayfa</small>
      </button>
      <button class="btn" style="background:#16a34a;color:#fff;padding:14px 6px;border-radius:12px" onclick="sendReceiptViaWa('${s.id}')">
        <div style="font-size:22px;margin-bottom:4px">💬</div>
        <b>WhatsApp Fişi</b><br><small style="opacity:0.85">${c&&c.phone?'Müşteriye Gönder':'Resim / PDF Fiş'}</small>
      </button>
    </div>
    <button class="btn ln" onclick="closeModal()" style="width:100%">✕ Kapat (Yazdırmadan Geç)</button>
  </div>
  `);
}

function receipt(id){
  const s=S.sales.find(x=>x.id===id),c=S.customers.find(x=>x.id===s.customerId);
  const sec=getActiveSector();
  const kdvInfo = calculateKdvBreakdown(s.items, s.discount, s.total);
  printHTML(`<div style="width:300px;margin:auto;font-size:13px">
    <h2 style="text-align:center;margin:0">${sec.icon} ${h(S.settings?.shop||sec.name)}</h2>
    <div style="text-align:center;font-size:11px;color:#555">${h(sec.name)}</div>
    <div style="text-align:center">${h(S.settings.address||'')} ${h(S.settings.phone||'')}</div>
    <hr>
    Fiş No: #${s.no}<br>${fdt(s.date)}${s.cashier?`<br>Kasiyer: ${h(s.cashier)}`:''}
    <hr>
    <table style="width:100%">
      ${s.items.map(i=>{
        const ret = num(i.returnedQty||0);
        return `<tr><td colspan="2"><b>${h(i.name)}</b>${i.variant?` <small>(${h(i.variant)})</small>`:''} <small style="color:#666">(%${i.kdv!==undefined?i.kdv:20})</small>${ret>0?` <span style="color:#ea580c;font-weight:bold;font-size:11px">[${num(ret)} ${i.unit} İADE EDİLDİ]</span>`:''}</td></tr><tr><td>${num(i.qty)} ${i.unit||'adet'} x ${money(i.price)}</td><td class="r" style="text-align:right">${money(i.qty*i.price)}</td></tr>`;
      }).join('')}
    </table>
    <hr>
    ${s.discount?`İskonto: ${money(s.discount)}<br>`:''}
    <b style="font-size:18px">TOPLAM: ${money(s.total)}</b><br>
    ${s.returns && s.returns.length > 0 ? `
    <div style="margin-top:4px;padding:3px 0;color:#ea580c;font-size:11px;border-top:1px dashed #ea580c">
      <b>İADELER:</b> Toplam ${money(s.returns.reduce((a,r)=>a+r.refundAmount,0))} tutarında ürün iadesi yapılmıştır.
    </div>` : ''}
    ${kdvInfo.groups && kdvInfo.groups.length > 0 ? `
    <div style="margin-top:6px;padding:4px 0;border-top:1px dashed #ccc;border-bottom:1px dashed #ccc;font-size:11px">
      <div style="font-weight:bold;margin-bottom:2px">KDV DAĞILIMI (Fiyata Dahil):</div>
      ${kdvInfo.groups.map(g => `<div style="display:flex;justify-content:space-between"><span>%${g.rate} (${g.label}):</span><span>Matrah: ${money(g.matrah)} | KDV: <b>${money(g.kdv)}</b></span></div>`).join('')}
      <div style="display:flex;justify-content:space-between;font-weight:bold;margin-top:2px;border-top:1px dotted #ccc;padding-top:2px"><span>Top. KDV:</span><span>${money(kdvInfo.totalKdv)}</span></div>
    </div>` : ''}
    <div style="margin-top:4px">Ödeme Şekli: ${({nakit:'Nakit',kart:'Kredi Kartı',veresiye:'Veresiye',parcali:`Parçalı (Nakit: ${money(s.paidCash)} + Kart: ${money(s.paidCard)})`})[s.method]||s.method}</div>
    ${c?`<br>Müşteri: ${h(c.name)}<br>Vade Tarihi: ${fdate(s.dueDate)}`:''}
    <hr>
    <div style="text-align:center">Bizi tercih ettiğiniz için teşekkür ederiz!</div>
  </div>`,'Fiş');
}

function printDoc(id, type='a4'){
  const s=S.sales.find(x=>x.id===id), c=S.customers.find(x=>x.id===s.customerId);
  const sec=getActiveSector();
  const isA5 = type==='a5';
  const shop = S.settings?.shop || sec.name;
  const phone = S.settings.phone || '';
  const addr = S.settings.address || '';
  const kdvInfo = calculateKdvBreakdown(s.items, s.discount, s.total);

  const html = `
  <style>
    @page { size: ${isA5?'A5 portrait':'A4 portrait'}; margin: ${isA5?'8mm':'14mm'}; }
    body { font-family: 'Segoe UI', Arial, sans-serif; color: #1e2433; margin: 0; padding: 0; font-size: ${isA5?'11px':'13px'}; }
    .header { display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 2px solid #14213d; padding-bottom: 10px; margin-bottom: 12px; }
    .brand-title { font-size: ${isA5?'18px':'24px'}; font-weight: 800; color: #14213d; text-transform: uppercase; letter-spacing: 1px; }
    .shop-meta { font-size: 11px; color: #555; margin-top: 3px; line-height: 1.4; }
    .doc-badge { text-align: right; }
    .doc-title { font-size: ${isA5?'15px':'20px'}; font-weight: 700; color: #fca311; text-transform: uppercase; }
    .doc-meta { font-size: 11px; color: #333; margin-top: 4px; line-height: 1.4; }
    .info-boxes { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-bottom: 12px; }
    .ibox { border: 1px solid #e3e7ef; border-radius: 8px; padding: 8px 10px; background: #fafbfd; }
    .ibox-title { font-weight: 700; font-size: 10px; color: #6b7488; text-transform: uppercase; margin-bottom: 3px; border-bottom: 1px solid #e3e7ef; padding-bottom: 2px; }
    table.data-table { width: 100%; border-collapse: collapse; margin-bottom: 12px; }
    table.data-table th { background: #14213d; color: #fff; text-align: left; padding: 7px 8px; font-size: 11px; text-transform: uppercase; }
    table.data-table td { border-bottom: 1px solid #e3e7ef; padding: 6px 8px; font-size: ${isA5?'11px':'12px'}; vertical-align: middle; }
    table.data-table tr:nth-child(even) td { background: #fcfdfe; }
    .bottom-layout { display: flex; justify-content: space-between; align-items: flex-start; gap: 16px; margin-bottom: 16px; }
    .kdv-box { border: 1px solid #e2e8f0; border-radius: 6px; padding: 6px 10px; background: #f8fafc; font-size: 11px; width: 55%; }
    .totals-area { display: flex; justify-content: flex-end; width: 42%; }
    .totals-table { width: 100%; border-collapse: collapse; }
    .totals-table td { padding: 4px 6px; font-size: 12px; }
    .totals-table tr.grand-row td { font-size: ${isA5?'14px':'17px'}; font-weight: 800; color: #14213d; border-top: 2px solid #14213d; }
    .sign-area { display: flex; justify-content: space-between; margin-top: ${isA5?'20px':'45px'}; padding-top: 10px; border-top: 1px dashed #cfd6e4; }
    .sign-box { text-align: center; width: 180px; font-size: 11px; }
    .sign-line { margin-top: 35px; border-top: 1px solid #000; }
  </style>

  <div class="header">
    <div>
      <div class="brand-title">${sec.icon} ${h(shop)}</div>
      <div class="shop-meta">${h(addr)}<br>Tel: ${h(phone||'—')}</div>
    </div>
    <div class="doc-badge">
      <div class="doc-title">${isA5?'SATIŞ BELGESİ (A5)':'SATIŞ FİŞİ / TESLİM FORMU (A4)'}</div>
      <div class="doc-meta">
        <b>Belge No:</b> #${s.no}<br>
        <b>Tarih:</b> ${fdt(s.date)}<br>
        ${s.cashier?`<b>Kasiyer:</b> ${h(s.cashier)}<br>`:''}
        <b>Ödeme:</b> ${({nakit:'Nakit',kart:'Kredi Kartı',veresiye:'Veresiye',parcali:'Parçalı Ödeme'})[s.method]||s.method}
      </div>
    </div>
  </div>

  <div class="info-boxes">
    <div class="ibox">
      <div class="ibox-title">Satıcı Bilgileri</div>
      <b>${h(shop)}</b><br>
      ${h(addr)}<br>
      Tel: ${h(phone||'—')}
    </div>
    <div class="ibox">
      <div class="ibox-title">Müşteri Bilgileri</div>
      <b>${c?h(c.name):'Perakende Müşteri'}</b><br>
      ${c&&c.phone?`Tel: ${h(c.phone)}<br>`:''}
      ${c&&c.address?`Adres: ${h(c.address)}<br>`:''}
      ${s.method==='veresiye'?`<b>Vade Tarihi:</b> ${fdate(s.dueDate)}`:''}
    </div>
  </div>

  <table class="data-table">
    <thead>
      <tr>
        <th style="width:28px">#</th>
        <th>Ürün / Hizmet Açıklaması</th>
        <th>Barkod</th>
        <th style="text-align:center">KDV</th>
        <th style="text-align:center">Miktar</th>
        <th style="text-align:right">Birim Fiyat</th>
        <th style="text-align:right">Toplam Tutar</th>
      </tr>
    </thead>
    <tbody>
      ${s.items.map((i,idx)=>`<tr>
        <td>${idx+1}</td>
        <td><b>${h(i.name)}</b>${i.variant?` <small>(${h(i.variant)})</small>`:''}</td>
        <td><code>${h(i.barcode||'—')}</code></td>
        <td style="text-align:center">%${i.kdv!==undefined?i.kdv:20}</td>
        <td style="text-align:center">${num(i.qty)} ${i.unit}</td>
        <td style="text-align:right">${money(i.price)}</td>
        <td style="text-align:right"><b>${money(i.qty*i.price)}</b></td>
      </tr>`).join('')}
    </tbody>
  </table>

  <div class="bottom-layout">
    <div class="kdv-box">
      <div style="font-weight:bold;margin-bottom:4px;color:#1e293b">KDV Dağılım Tablosu (Fiyata Dahil):</div>
      <table style="width:100%;border-collapse:collapse;font-size:11px">
        <tr style="border-bottom:1px solid #cbd5e1;color:#64748b">
          <th style="text-align:left;padding:2px 0">Oran</th>
          <th style="text-align:right;padding:2px 0">KDV Matrahı</th>
          <th style="text-align:right;padding:2px 0">KDV Tutarı</th>
        </tr>
        ${kdvInfo.groups && kdvInfo.groups.length > 0 ? kdvInfo.groups.map(g=>`
        <tr>
          <td style="padding:2px 0">%${g.rate} (${g.label})</td>
          <td style="text-align:right;padding:2px 0">${money(g.matrah)}</td>
          <td style="text-align:right;padding:2px 0;font-weight:600">${money(g.kdv)}</td>
        </tr>`).join('') : '<tr><td colspan="3" style="padding:2px 0">—</td></tr>'}
        <tr style="border-top:1px solid #cbd5e1;font-weight:bold">
          <td style="padding:3px 0">Toplam:</td>
          <td style="text-align:right;padding:3px 0">${money(kdvInfo.totalMatrah)}</td>
          <td style="text-align:right;padding:3px 0">${money(kdvInfo.totalKdv)}</td>
        </tr>
      </table>
    </div>

    <div class="totals-area">
      <table class="totals-table">
        <tr><td>Ara Toplam:</td><td style="text-align:right">${money(s.subtotal||s.total)}</td></tr>
        ${s.discount?`<tr><td>İskonto:</td><td style="text-align:right;color:#dc2626">- ${money(s.discount)}</td></tr>`:''}
        <tr class="grand-row"><td>TOPLAM TUTAR:</td><td style="text-align:right">${money(s.total)}</td></tr>
        <tr><td colspan="2" style="font-size:11px;color:#555;padding-top:4px"><b>Ödeme Türü:</b> ${({nakit:'Nakit',kart:'Kredi Kartı',veresiye:'Veresiye',parcali:`Parçalı (Nakit: ${money(s.paidCash)} + Kart: ${money(s.paidCard)})`})[s.method]||s.method}</td></tr>
      </table>
    </div>
  </div>

  <div class="sign-area">
    <div class="sign-box">
      <b>Teslim Eden</b><br>
      <small>${h(shop)}</small>
      <div class="sign-line">İmza / Kaşe</div>
    </div>
    <div class="sign-box">
      <b>Teslim Alan</b><br>
      <small>${c?h(c.name):'Müşteri'}</small>
      <div class="sign-line">İmza</div>
    </div>
  </div>
  `;

  printHTML(html, `${shop} - Belge #${s.no}`);
}

/* ==========================================================================
   KAMERA İLE KAREKOD (QR) VE BARKOD OKUMA (HTML5-QRCODE)
   ========================================================================== */
let html5QrCode=null;
let camCb=null;
let camLast={c:'',t:0};
let zxingReader=null;
let html5HelperScanner=null;

async function stopCam(){
  if(html5QrCode){
    try{await html5QrCode.stop()}catch(e){}
    try{html5QrCode.clear()}catch(e){}
    html5QrCode=null;
  }
}

function closeCamModal(){
  stopCam();
  const b=$('#camModalBg');
  if(b) b.hidden=true;
  const m=$('#camModal');
  if(m) m.innerHTML='';
}

function triggerNativeCamera(){
  const inp=$('#mobileCameraCapture');
  if(inp){
    inp.value='';
    inp.click();
  }
}

function triggerGalleryPick(){
  const inp=$('#mobileGalleryPick');
  if(inp){
    inp.value='';
    inp.click();
  }
}

// Yüksek Başarımlı Barkod & Karekod Çözücü (EAN-13, EAN-8, CODE-128, CODE-39, UPC ve QR Kodlar)
async function decodeBarcodeFromImageFile(file){
  if(!file)return null;
  const objectUrl=URL.createObjectURL(file);

  try{
    // Adım 1: ZXing BrowserMultiFormatReader ile doğrudan tarama
    if(typeof ZXing!=='undefined'&&ZXing.BrowserMultiFormatReader){
      if(!zxingReader) zxingReader=new ZXing.BrowserMultiFormatReader();
      try{
        const res=await zxingReader.decodeFromImageUrl(objectUrl);
        if(res&&res.getText&&res.getText()){
          URL.revokeObjectURL(objectUrl);
          return res.getText().trim();
        }
      }catch(_){}
    }

    // Adım 2: Görseli yeniden boyutlandırıp ZXing ile canvas üzerinden tarama
    const resizedRes=await new Promise((resolve)=>{
      const img=new Image();
      img.onload=async()=>{
        try{
          const maxDim=1280;
          let w=img.naturalWidth||img.width;
          let h=img.naturalHeight||img.height;
          if(w>maxDim||h>maxDim){
            const ratio=Math.min(maxDim/w,maxDim/h);
            w=Math.round(w*ratio);
            h=Math.round(h*ratio);
          }
          const canvas=document.createElement('canvas');
          canvas.width=w;
          canvas.height=h;
          const ctx=canvas.getContext('2d');
          ctx.drawImage(img,0,0,w,h);

          if(typeof ZXing!=='undefined'&&ZXing.BrowserMultiFormatReader){
            if(!zxingReader) zxingReader=new ZXing.BrowserMultiFormatReader();
            try{
              const r=await zxingReader.decodeFromCanvas(canvas);
              if(r&&r.getText()) return resolve(r.getText().trim());
            }catch(_){}
          }
          resolve(null);
        }catch(_){
          resolve(null);
        }
      };
      img.onerror=()=>resolve(null);
      img.src=objectUrl;
    });

    if(resizedRes){
      URL.revokeObjectURL(objectUrl);
      return resizedRes;
    }

    // Adım 3: Html5Qrcode.scanFile ile ikincil tarama
    if(typeof Html5Qrcode!=='undefined'){
      try{
        let el=document.getElementById('qrScanFileHelper');
        if(!el){
          el=document.createElement('div');
          el.id='qrScanFileHelper';
          el.style.display='none';
          document.body.appendChild(el);
        }
        if(!html5HelperScanner){
          html5HelperScanner=new Html5Qrcode('qrScanFileHelper',false);
        }
        const res=await html5HelperScanner.scanFile(file,false);
        if(res){
          URL.revokeObjectURL(objectUrl);
          return String(res).trim();
        }
      }catch(_){}
    }

    URL.revokeObjectURL(objectUrl);
    return null;
  }catch(err){
    URL.revokeObjectURL(objectUrl);
    throw err;
  }
}

async function handleCapturedBarcodeFile(file){
  if(!file)return;
  toast('⏳ Barkod okunuyor...','info');
  const m=$('#camMsg');
  if(m){
    m.innerHTML='<div style="padding:10px;text-align:center;color:var(--navy)">⏳ <b>Barkod fotoğraftan çözümleniyor...</b></div>';
  }

  try{
    const code=await decodeBarcodeFromImageFile(file);
    if(!code) throw new Error('NOT_FOUND');
    camHit(code);
  }catch(err){
    beep(false);
    toast('⚠️ Barkod okunamadı. Lütfen barkoda biraz daha yaklaşıp net çekin.','err');
    if(m){
      m.innerHTML=`
        <div style="background:#fee2e2;border:1px solid #fca5a5;border-radius:10px;padding:12px;margin:8px 0;text-align:center">
          <b style="color:#991b1b">⚠️ Barkod Net Okunamadı</b>
          <p style="margin:4px 0 10px;font-size:12px;color:#7f1d1d">
            Lütfen ışıklı bir ortamda, kamerayı barkoda biraz daha yaklaştırarak tekrar çekin.
          </p>
          <div style="display:flex;gap:8px">
            <button class="btn" style="background:#2563eb;color:#fff;flex:1;font-weight:700;padding:10px" onclick="triggerNativeCamera()">
              📸 Tekrar Fotoğraf Çek
            </button>
            <button class="btn ln" style="padding:10px" onclick="triggerGalleryPick()">
              📁 Galeriden Seç
            </button>
          </div>
        </div>
      `;
    }
  }
}

function camHit(code){
  const clean=String(code||'').trim();
  if(!clean)return;
  const now=Date.now();
  if(clean===camLast.c&&now-camLast.t<1800)return;
  camLast={c:clean,t:now};

  if(camCb){
    beep(true);
    const cb=camCb;
    closeCamModal();
    cb(clean);
    return;
  }

  // Satış ekranında okutulduysa (POS)
  beep(true);
  const p=handleCode(clean,1);
  const m=$('#camMsg');
  if(p){
    toast(`✅ ${p.name} (${money(p.price)}) sepete eklendi!`,'ok');
    if(m){
      m.innerHTML=`
        <div style="padding:10px;background:#dcfce7;border:1px solid #86efac;border-radius:10px;color:#166534;margin-bottom:10px;text-align:center">
          <b style="font-size:15px">✅ Sepete Eklendi!</b><br>
          <span style="font-size:13px">${h(p.name)} — <b>${money(p.price)}</b></span>
        </div>
        <div style="display:flex;gap:8px">
          <button class="btn" style="background:#2563eb;color:#fff;flex:1;padding:10px;font-weight:700" onclick="triggerNativeCamera()">
            📸 Bir Sonraki Ürünü Çek
          </button>
          <button class="btn or" style="flex:1;padding:10px;font-weight:700" onclick="closeCamModal()">
            🛒 Sepete Dön
          </button>
        </div>
      `;
    }
  }else{
    beep(false);
    toast(`❌ Kayıtlı ürün bulunamadı: ${clean}`,'err');
    if(m){
      m.innerHTML=`
        <div style="padding:10px;background:#fee2e2;border:1px solid #fca5a5;border-radius:10px;color:#991b1b;margin-bottom:10px;text-align:center">
          <b>❌ Ürün Bulunamadı:</b> <code>${h(clean)}</code>
        </div>
        <div style="display:flex;flex-direction:column;gap:8px">
          <button class="btn or" style="width:100%;font-weight:700;padding:10px" onclick="closeCamModal();prodForm(null,'${h(clean)}')">
            ➕ Bu Barkodla Yeni Ürün Ekle
          </button>
          <button class="btn ln" style="width:100%" onclick="triggerNativeCamera()">
            📸 Başka Barkod Çek
          </button>
        </div>
      `;
    }
  }
}

async function openCamScan(cb){
  camCb=cb||null;

  // Kamera girişlerini dinleyiciye bağla
  const camIn=$('#mobileCameraCapture');
  if(camIn&&!camIn._bound){
    camIn.onchange=e=>handleCapturedBarcodeFile(e.target.files&&e.target.files[0]);
    camIn._bound=true;
  }
  const galIn=$('#mobileGalleryPick');
  if(galIn&&!galIn._bound){
    galIn.onchange=e=>handleCapturedBarcodeFile(e.target.files&&e.target.files[0]);
    galIn._bound=true;
  }

  // Canlı video akışı desteği var mı? (HTTPS üzerinde hem telefonda hem masaüstünde tam çalışır)
  const canLiveVideo=!!(navigator.mediaDevices&&navigator.mediaDevices.getUserMedia);

  if(!canLiveVideo){
    triggerNativeCamera();
    return;
  }

  // Canlı Video Barkod Okuyucu (WebRTC / HTML5 Canlı Kamera)
  const box=$('#camModal');
  if(!box)return;
  box.innerHTML=`
    <button class="mclose" onclick="closeCamModal()" title="Kapat">✕</button>
    <h2>📷 Canlı Barkod Okuyucu</h2>
    <div id="qrReaderBox" style="width:100%;max-width:440px;margin:auto;border-radius:12px;overflow:hidden;background:#000;min-height:240px;position:relative"></div>
    <div id="camMsg" style="text-align:center;margin-top:10px;font-size:13px">
      <p class="mut">Barkod veya karekodu kameranın karşısına tutun…</p>
    </div>
    <div style="display:flex;gap:8px;justify-content:center;margin-top:10px;flex-wrap:wrap">
      <button class="btn ln sm" style="padding:8px 12px" onclick="triggerNativeCamera()">
        📸 Fotoğrafla Oku
      </button>
      <button class="btn ln sm" style="padding:8px 12px" onclick="triggerGalleryPick()">
        📁 Galeriden Seç
      </button>
    </div>
    <div class="mfoot" style="margin-top:10px"><button class="btn ln" onclick="closeCamModal()">Kapat</button></div>
  `;
  $('#camModalBg').hidden=false;

  try{
    html5QrCode=new Html5Qrcode("qrReaderBox");
    await html5QrCode.start(
      { facingMode: "environment" },
      { fps: 20, qrbox: { width: 280, height: 180 }, aspectRatio: 1.0 },
      (decodedText)=>{ camHit(decodedText); },
      (err)=>{}
    );
  }catch(err){
    console.warn("Canlı kamera başlatılamadı, fotoğraf moduna geçiliyor:", err);
    triggerNativeCamera();
  }
}

/* ==========================================================================
   ÜRÜNLER VE STOK YÖNETİMİ
   ========================================================================== */
let pFilter='',pCat='',pOnly='';

function pProducts(){
  const cats=[...new Set(S.products.map(p=>p.category).filter(Boolean))].sort();
  $('#view').innerHTML=`<div class="bar" style="flex-wrap:wrap;gap:8px">
    <div style="display:flex;gap:6px;flex:1.5;min-width:200px">
      <input id="pq" placeholder="🔍 Ürün adı veya barkod ara" value="${h(pFilter)}" style="flex:1">
      <button class="btn cam sm" type="button" onclick="openCamScan(c=>{$('#pq').value=c;pFilter=c;drawProducts();toast('Barkod arandı: '+c,'ok')})" title="Kamera ile Barkod Tara" style="padding:0 12px;font-size:16px;border-radius:10px">📷</button>
    </div>
    <select id="pc" style="flex:1;min-width:140px">
      <option value="">Tüm Kategoriler</option>
      ${cats.map(c=>`<option ${c===pCat?'selected':''}>${h(c)}</option>`).join('')}
    </select>
    <select id="po" style="flex:1;min-width:140px">
      <option value="">Tüm Ürünler</option>
      <option value="low" ${pOnly==='low'?'selected':''}>Azalan / Biten Ürünler</option>
    </select>
    <div class="grow"></div>
    <button class="btn sm" style="background:#0f766e;color:#fff" onclick="openSupplierOrderModal()" title="Kritik ve biten stokları toptancı sipariş listesine dönüştür">📋 Sipariş Listesi</button>
    ${isAdmin()?`
      <button class="btn sm" style="background:#7c3aed;color:#fff" onclick="openBulkPriceUpdateModal()" title="Kategori veya tüm ürünlere toplu yüzde zam/indirim uygula">⚡ Toplu Fiyat</button>
      <label class="btn ln sm" style="margin:0;cursor:pointer" title="Excel / CSV dosyasından toplu ürün yükle">📥 Excel'den Yükle<input type="file" accept=".csv,.txt" hidden onchange="importProductsCSV(this)"></label>
      <button class="btn ln sm" onclick="exportProductsCSV()" title="Tüm Ürünleri Excel CSV Olarak İndir">📊 Excel İndir</button>
      <button class="btn or sm" onclick="prodForm()">+ Yeni Ürün Ekle</button>
    `:''}
  </div>
  <div class="card tw" id="ptab"></div>`;

  const upd=()=>{pFilter=$('#pq').value;pCat=$('#pc').value;pOnly=$('#po').value;drawProducts()};
  $('#pq').oninput=upd;$('#pc').onchange=upd;$('#po').onchange=upd;
  drawProducts();
}

function exportProductsCSV(){
  if(!S.products.length){ toast('Dışa aktarılacak ürün bulunamadı.','err'); return; }
  const sec = getActiveSector();
  const headers = ['Barkod', 'Ürün Adı', 'Kategori', 'Birim', 'Alış Fiyatı', 'Satış Fiyatı', 'Mevcut Stok', 'Min Stok', 'Raf / Konum', 'Marka'];
  const rows = S.products.map(p => [
    `"${(p.barcode || '').replace(/"/g, '""')}"`,
    `"${(p.name || '').replace(/"/g, '""')}"`,
    `"${(p.category || 'Genel').replace(/"/g, '""')}"`,
    `"${(p.unit || sec.defaultUnit || 'adet').replace(/"/g, '""')}"`,
    num(p.cost),
    num(p.price),
    num(p.stock),
    num(p.min),
    `"${(p.rack || '').replace(/"/g, '""')}"`,
    `"${(p.brand || '').replace(/"/g, '""')}"`
  ]);
  const csvContent = '\uFEFF' + [headers.join(';'), ...rows.map(r => r.join(';'))].join('\r\n');
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = `msg-urunler-${dkey(new Date())}.csv`;
  a.click();
  toast('Ürün listesi Excel CSV formatında indirildi!', 'ok');
}

function importProductsCSV(inputEl){
  const file = inputEl.files[0];
  if(!file) return;
  const reader = new FileReader();
  reader.onload = async () => {
    try {
      const text = reader.result;
      const lines = text.split(/\r?\n/).map(l => l.trim()).filter(Boolean);
      if(lines.length < 2){ toast('CSV dosyası boş veya geçersiz!', 'err'); return; }
      
      const sep = lines[0].includes(';') ? ';' : ',';
      const sec = getActiveSector();
      let imported = 0;
      
      for(let i = 1; i < lines.length; i++){
        const parts = lines[i].split(sep).map(s => s.replace(/^"|"$/g, '').trim());
        if(!parts || parts.length < 2) continue;
        
        const bc = parts[0] || genBarcode();
        const name = parts[1];
        if(!name) continue;
        const category = parts[2] || 'Genel';
        const unit = parts[3] || sec.defaultUnit || 'adet';
        const cost = parse(parts[4]) || 0;
        const price = parse(parts[5]) || 0;
        const stock = parse(parts[6]) || 0;
        const min = parse(parts[7]) || 5;
        const rack = parts[8] || '';
        const brand = parts[9] || '';
        
        await cmd('prodSave', {
          id: null,
          data: { name, barcode: bc, category, unit, cost, price, stock, min, rack, brand }
        });
        imported++;
      }
      
      toast(`Tebrikler! ${imported} ürün Excel'den sisteme aktarıldı!`, 'ok');
      route();
    } catch(err) {
      toast('Excel CSV okuma hatası: ' + err.message, 'err');
    }
    inputEl.value = '';
  };
  reader.readAsText(file, 'utf-8');
}

/* ==========================================================================
   KRİTİK STOK SİPARİŞ LİSTESİ (TOPTANCI SİPARİŞ FORMU & WHATSAPP)
   ========================================================================== */
function openSupplierOrderModal(){
  const lowProducts = S.products.filter(isLow);
  if(!lowProducts.length){
    toast('Azalan veya kritik seviyede ürün bulunmuyor. Tüm stoklar yeterli! 🎉', 'ok');
    return;
  }
  const sec = getActiveSector();
  const shop = S.settings?.shop || sec.name;

  modal(`
    <div style="padding:4px 2px">
      <div style="display:flex;align-items:center;justify-content:space-between;border-bottom:2px solid var(--navy);padding-bottom:10px;margin-bottom:12px">
        <div>
          <h2 style="margin:0;font-size:19px;color:var(--navy);display:flex;align-items:center;gap:6px">
            📋 Toptancı Sipariş Listesi (${lowProducts.length} Ürün)
          </h2>
          <small class="mut">Kritik ve tükenen ürünler otomatik listelenmiştir</small>
        </div>
        <button class="btn ln sm" onclick="closeModal()">✕</button>
      </div>

      <div style="max-height:55vh;overflow-y:auto;border:1px solid #e2e8f0;border-radius:10px;margin-bottom:14px">
        <table style="width:100%;border-collapse:collapse;font-size:13px">
          <thead>
            <tr style="background:#f8fafc;position:sticky;top:0;border-bottom:1px solid #cbd5e1">
              <th style="padding:8px">Ürün Adı / Barkod</th>
              <th style="padding:8px" class="c">Mevcut Stok</th>
              <th style="padding:8px" class="c">Min. Sınır</th>
              <th style="padding:8px" class="r">Sipariş Miktarı</th>
            </tr>
          </thead>
          <tbody>
            ${lowProducts.map((p, idx) => {
              const recOrder = Math.max(1, Math.ceil((p.min || 5) * 2 - p.stock));
              return `
                <tr style="border-bottom:1px solid #f1f5f9">
                  <td style="padding:8px">
                    <b>${h(p.name)}</b><br>
                    <small class="mut">${h(p.barcode)} • ${h(p.category||'Genel')}</small>
                  </td>
                  <td style="padding:8px" class="c">
                    <span class="tag ${p.stock<=0?'t-bad':'t-warn'}">${stockOf(p)}</span>
                  </td>
                  <td style="padding:8px" class="c mut">${num(p.min||5)} ${unitOf(p)}</td>
                  <td style="padding:8px" class="r">
                    <input type="number" step="1" min="1" id="ord_qty_${idx}" data-pid="${p.id}" value="${recOrder}" style="width:70px;text-align:right;padding:4px 6px;border:1.5px solid #cbd5e1;border-radius:6px;font-weight:700">
                    <small class="mut">${unitOf(p)}</small>
                  </td>
                </tr>
              `;
            }).join('')}
          </tbody>
        </table>
      </div>

      <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:10px">
        <button class="btn or" onclick="sendSupplierOrderWA()" style="padding:10px 8px;font-weight:700;border-radius:10px;background:#16a34a;color:#fff">
          💬 WhatsApp ile Toptancıya Gönder
        </button>
        <button class="btn" style="background:#2563eb;color:#fff;padding:10px 8px;font-weight:700;border-radius:10px" onclick="printSupplierOrderPDF()">
          🖨️ Sipariş Listesini Yazdır
        </button>
        <button class="btn ln" onclick="closeModal()" style="border-radius:10px">✕ Kapat</button>
      </div>
    </div>
  `);
}

function getCollectedSupplierOrder(){
  const lowProducts = S.products.filter(isLow);
  const items = [];
  lowProducts.forEach((p, idx) => {
    const inp = $(`#ord_qty_${idx}`);
    const q = inp ? parse(inp.value) : Math.max(1, (p.min||5)*2 - p.stock);
    if(q > 0){
      items.push({ p, qty: q });
    }
  });
  return items;
}

function sendSupplierOrderWA(){
  const items = getCollectedSupplierOrder();
  if(!items.length){ toast('Sipariş edilecek ürün yok','err'); return; }
  const phone = prompt('Siparişin gönderileceği toptancı telefon numarasını girin (Örn: 05xx xxx xx xx):');
  if(!phone || !phone.trim()) return;
  const cleanPhone = cleanPhoneForWa(phone.trim());
  const sec = getActiveSector();
  const shop = S.settings?.shop || sec.name;

  let msg = `*${shop.toUpperCase()} - MAL SİPARİŞ LİSTESİ*\n`;
  msg += `📅 Tarih: ${new Date().toLocaleDateString('tr-TR')}\n`;
  msg += `📦 Toplam ${items.length} Kalem Sipariş:\n`;
  msg += `------------------------------------\n`;
  items.forEach((it, i) => {
    msg += `${i+1}. *${it.p.name}*\n`;
    msg += `   Barkod: ${it.p.barcode}\n`;
    msg += `   Sipariş Miktarı: *${num(it.qty)} ${unitOf(it.p)}*\n`;
  });
  msg += `------------------------------------\n`;
  msg += `Lütfen siparişin onayını ve tahmini teslimat gününü bildiriniz. Hayırlı işler.`;

  window.open(`https://wa.me/${cleanPhone}?text=${encodeURIComponent(msg)}`, '_blank');
}

function printSupplierOrderPDF(){
  const items = getCollectedSupplierOrder();
  if(!items.length){ toast('Sipariş edilecek ürün yok','err'); return; }
  const sec = getActiveSector();
  const shop = S.settings?.shop || sec.name;

  printHTML(`
    <style>
      @page { size: A4 portrait; margin: 15mm; }
      body { font-family: 'Segoe UI', Arial, sans-serif; color: #1e2433; }
      .header { display: flex; justify-content: space-between; border-bottom: 2px solid #14213d; padding-bottom: 10px; margin-bottom: 16px; }
      table { width: 100%; border-collapse: collapse; margin-top: 10px; }
      th, td { padding: 8px; border-bottom: 1px solid #cbd5e1; font-size: 13px; }
      th { background: #14213d; color: #fff; text-align: left; }
    </style>
    <div class="header">
      <div>
        <h1 style="margin:0;font-size:22px;color:#14213d">${sec.icon} ${h(shop)}</h1>
        <small>Toptancı Mal Sipariş ve Talep Formu</small>
      </div>
      <div style="text-align:right">
        <h3 style="margin:0;color:#0284c7">SİPARİŞ FORMU</h3>
        <small>Tarih: ${new Date().toLocaleDateString('tr-TR')}</small>
      </div>
    </div>
    <table>
      <thead>
        <tr>
          <th style="width:30px">#</th>
          <th>Ürün Adı</th>
          <th>Barkod</th>
          <th>Kategori</th>
          <th style="text-align:center">Mevcut Stok</th>
          <th style="text-align:right">Talep Edilen Sipariş Miktarı</th>
        </tr>
      </thead>
      <tbody>
        ${items.map((it, i) => `
          <tr>
            <td>${i+1}</td>
            <td><b>${h(it.p.name)}</b></td>
            <td><code>${h(it.p.barcode)}</code></td>
            <td>${h(it.p.category||'Genel')}</td>
            <td style="text-align:center">${stockOf(it.p)}</td>
            <td style="text-align:right;font-size:15px"><b>${num(it.qty)} ${unitOf(it.p)}</b></td>
          </tr>
        `).join('')}
      </tbody>
    </table>
    <div style="margin-top:40px;display:flex;justify-content:flex-end">
      <div style="text-align:center;width:220px">
        <b>Sipariş Veren İşletme Yetkilisi</b>
        <div style="margin-top:35px;border-top:1px solid #000">İmza / Kaşe</div>
      </div>
    </div>
  `, `Siparis-Listesi-${dkey(new Date())}`);
}

/* ==========================================================================
   TOPLU FİYAT GÜNCELLEME (ENFLASYON & YÜZDE ZAM / İNDİRİM MOTORU)
   ========================================================================== */
function openBulkPriceUpdateModal(){
  const cats = [...new Set(S.products.map(p=>p.category).filter(Boolean))].sort();

  modal(`
    <div style="padding:4px 2px">
      <div style="display:flex;align-items:center;justify-content:space-between;border-bottom:2px solid var(--navy);padding-bottom:10px;margin-bottom:14px">
        <h2 style="margin:0;font-size:19px;color:var(--navy);display:flex;align-items:center;gap:6px">
          ⚡ Toplu Fiyat Güncelleme (Zam / İndirim Motoru)
        </h2>
        <button class="btn ln sm" onclick="closeModal()">✕</button>
      </div>

      <div style="background:#fef3c7;border:1px solid #fde68a;border-radius:10px;padding:10px 12px;margin-bottom:14px;font-size:12px;color:#92400e;line-height:1.4">
        💡 Seçtiğiniz kategoriye veya tüm ürünlere tek tıkla yüzde (%) veya sabit tutar (₺) artış / indirim uygulayabilirsiniz.
      </div>

      <div class="row">
        <div class="f">
          <label>Kapsam / Kategori Seçimi</label>
          <select id="bulk_cat">
            <option value="ALL">⭐ Tüm Ürünler (${S.products.length} Ürün)</option>
            ${cats.map(c => `<option value="${h(c)}">${h(c)} (${S.products.filter(p=>p.category===c).length} Ürün)</option>`).join('')}
          </select>
        </div>
        <div class="f">
          <label>Hangi Fiyat Değişecek?</label>
          <select id="bulk_target">
            <option value="price">Yalnızca Perakende Satış Fiyatı</option>
            <option value="both">Hem Satış Hem Alış Maliyeti</option>
            <option value="wprice">Toptan / Özel Fiyatlar</option>
          </select>
        </div>
      </div>

      <div class="row">
        <div class="f">
          <label>İşlem Türü</label>
          <select id="bulk_type">
            <option value="pct_up">Yüzde Zam / Artış (+) %</option>
            <option value="pct_down">Yüzde İndirim (-) %</option>
            <option value="fixed_up">Sabit Tutar Artış (+) ₺</option>
            <option value="fixed_down">Sabit Tutar İndirim (-) ₺</option>
          </select>
        </div>
        <div class="f">
          <label>Değer / Oran</label>
          <input type="number" id="bulk_val" step="0.5" min="0" placeholder="Örn: 10 (%10 için)" style="font-size:16px;font-weight:700">
        </div>
      </div>

      <div class="row">
        <div class="f">
          <label>Kuruş Yuvarlama</label>
          <select id="bulk_round">
            <option value="none">Yuvarlama Yapma (Kuruşlu Kalsın)</option>
            <option value="int">En Yakın Tam Sayıya Yuvarla (Örn: 49.80 -> 50 ₺)</option>
            <option value="dot90">.90 Kuruşa Tamamla (Örn: 49.90 ₺)</option>
          </select>
        </div>
      </div>

      <div class="mfoot" style="margin-top:16px">
        <button class="btn ln" onclick="closeModal()">İptal</button>
        <button class="btn or" onclick="executeBulkPriceUpdate()" style="font-weight:700;padding:10px 18px">
          🚀 Fiyatları Güncelle ve Kaydet
        </button>
      </div>
    </div>
  `);
}

async function executeBulkPriceUpdate(){
  const cat = $('#bulk_cat').value;
  const target = $('#bulk_target').value;
  const type = $('#bulk_type').value;
  const val = parse($('#bulk_val').value);
  const roundOpt = $('#bulk_round').value;

  if(val <= 0){
    toast('Lütfen 0 dan büyük bir oran veya tutar girin', 'err');
    return;
  }

  const targetProds = cat === 'ALL' ? S.products : S.products.filter(p => p.category === cat);
  if(!targetProds.length){
    toast('Seçilen kategoride güncellenecek ürün bulunamadı', 'err');
    return;
  }

  const confirmMsg = `${cat === 'ALL' ? 'TÜM ÜRÜNLER (' + targetProds.length + ' adet)' : '"' + cat + '" kategorisindeki ' + targetProds.length + ' ürün'} için fiyat güncellemesi yapılacaktır. Emin misiniz?`;
  if(!confirm(confirmMsg)) return;

  let updatedCount = 0;
  for(const p of targetProds){
    const updatedData = { ...p };
    
    const applyFormula = (currentVal) => {
      let n = currentVal || 0;
      if(type === 'pct_up') n = n * (1 + val / 100);
      else if(type === 'pct_down') n = n * (1 - val / 100);
      else if(type === 'fixed_up') n = n + val;
      else if(type === 'fixed_down') n = Math.max(0, n - val);

      if(roundOpt === 'int') n = Math.round(n);
      else if(roundOpt === 'dot90') n = Math.floor(n) + 0.90;
      else n = round2(n);
      return Math.max(0, n);
    };

    if(target === 'price' || target === 'both'){
      updatedData.price = applyFormula(p.price);
    }
    if(target === 'both'){
      updatedData.cost = applyFormula(p.cost);
    }
    if(target === 'wprice' && p.wprice){
      updatedData.wprice = applyFormula(p.wprice);
    }

    await cmd('prodSave', { id: p.id, data: updatedData });
    updatedCount++;
  }

  closeModal();
  toast(`🎉 Tebrikler! ${updatedCount} ürünün fiyatı başarıyla güncellendi!`, 'ok');
  route();
}

function showImageModal(src, title){
  if(!src) return;
  modal(`
    <div style="text-align:center;padding:4px">
      <h3 style="margin:0 0 10px;font-size:17px;color:var(--navy)">${h(title||'Ürün Görseli')}</h3>
      <div style="max-height:65vh;overflow:hidden;border-radius:14px;background:#0f172a;display:grid;place-items:center;box-shadow:0 8px 30px rgba(0,0,0,0.3)">
        <img src="${h(src)}" style="max-width:100%;max-height:65vh;object-fit:contain;display:block">
      </div>
      <div class="mfoot" style="margin-top:12px;justify-content:center">
        <button class="btn ln sm" onclick="closeModal()">✕ Kapat</button>
      </div>
    </div>
  `);
}

function drawProducts(){
  const q=pFilter.toLowerCase(), ad=isAdmin();
  const sec=getActiveSector();
  const l=S.products.filter(p=>(!q||p.name.toLowerCase().includes(q)||p.barcode.includes(q))&&(!pCat||p.category===pCat)&&(pOnly!=='low'||isLow(p)));
  if(!l.length){
    $('#ptab').innerHTML='<p class="mut" style="text-align:center;padding:30px">Ürün bulunamadı.</p>';
    return;
  }
  $('#ptab').innerHTML=`
    <div class="desktop-only">
      <table>
        <tr>
          <th style="width:58px;text-align:center">Görsel</th>
          <th>Ürün Adı</th>
          <th>Barkod / Kod</th>
          <th>Birim</th>
          ${ad?'<th class="r">Alış</th>':''}
          <th class="r">Satış</th>
          <th class="r">Mevcut Stok</th>
          <th></th>
        </tr>
        ${l.map(p=>{
          const tags = [];
          if(p.plu) tags.push(`<span class="tag t-ok" style="font-size:10px">⚖️ PLU: ${h(p.plu)}</span>`);
          if(p.sizes) tags.push(`<span class="tag t-blue" style="font-size:10px">👗 ${h(p.sizes)}</span>`);
          if(p.colors) tags.push(`<span class="tag t-gray" style="font-size:10px">🎨 ${h(p.colors)}</span>`);
          if(p.imei) tags.push(`<span class="tag t-warn" style="font-size:10px">📱 IMEI: ${h(p.imei)}</span>`);
          if(p.isbn) tags.push(`<span class="tag t-gray" style="font-size:10px">📚 ISBN: ${h(p.isbn)}</span>`);
          if(p.rack) tags.push(`<span class="tag t-gray" style="font-size:10px">📍 ${h(p.rack)}</span>`);
          if(p.expiry) tags.push(`<span class="tag t-bad" style="font-size:10px">⌛ SKT: ${h(p.expiry)}</span>`);
          return `<tr>
          <td style="width:58px;text-align:center;vertical-align:middle">
            <div class="thumb" style="margin:auto;cursor:${p.img?'pointer':'default'}" onclick="${p.img?`showImageModal('${h(p.img)}','${h(p.name).replace(/'/g,"\\'")}')`:''}" title="${p.img?'Büyütmek için tıklayın':''}">
              ${getProductIconHtml(p, sec.icon)}
            </div>
          </td>
          <td>
            <b>${h(p.name)}</b>
            <br><small class="mut">${h(p.category||'Genel')}</small>
            ${tags.length?`<div style="margin-top:3px;display:flex;gap:4px;flex-wrap:wrap">${tags.join('')}</div>`:''}
          </td>
          <td><code>${h(p.barcode)}</code></td>
          <td><span class="tag t-gray">${unitOf(p)}</span></td>
          ${ad?`<td class="r">${money(p.cost)}</td>`:''}
          <td class="r">
            <b>${money(p.price)} / ${unitOf(p)}</b>
            ${p.wprice?`<br><small style="color:#0284c7;font-weight:700">Toptan: ${money(p.wprice)}</small>`:''}
            ${p.rollPrice?`<br><small class="mut">Top: ${money(p.rollPrice)} (${num(p.rollLen)} m)</small>`:''}
          </td>
          <td class="r"><span class="tag ${p.stock<=0?'t-bad':isLow(p)?'t-warn':'t-ok'}">${stockOf(p)}</span></td>
          <td class="r" style="white-space:nowrap">
            ${ad?`<button class="btn sm gr" onclick="stockIn('${p.id}')">+Stok</button> <button class="btn sm ln" onclick="prodForm('${p.id}')">Düzenle</button> `:''}
            <button class="btn sm ln" onclick="bcOne('${p.id}')">🏷️ Barkod</button>
            ${ad?` <button class="btn sm rd" onclick="delProd('${p.id}')">Sil</button>`:''}
          </td>
        </tr>`}).join('')}
      </table>
    </div>
    <div class="mobile-only prod-cards-wrap">
      ${l.map(p=>`
        <div class="m-card">
          <div class="m-card-top">
            <div class="m-card-thumb" style="cursor:${p.img?'pointer':'default'}" onclick="${p.img?`showImageModal('${h(p.img)}','${h(p.name).replace(/'/g,"\\'")}')`:''}" title="${p.img?'Büyütmek için tıklayın':''}">
              ${getProductIconHtml(p, sec.icon)}
            </div>
            <div class="m-card-info">
              <b>${h(p.name)}</b>
              <div class="m-card-sub"><span class="tag t-gray">${h(p.category||'Genel')}</span> <code>${h(p.barcode)}</code></div>
              ${p.sizes?`<div style="margin-top:2px"><span class="tag t-blue" style="font-size:10px">👗 ${h(p.sizes)}</span></div>`:''}
              ${p.plu?`<div style="margin-top:2px"><span class="tag t-ok" style="font-size:10px">⚖️ PLU: ${h(p.plu)}</span></div>`:''}
            </div>
            <div class="m-card-price">
              <b class="m-price-val">${money(p.price)} / ${unitOf(p)}</b>
              <span class="tag ${p.stock<=0?'t-bad':isLow(p)?'t-warn':'t-ok'}">${stockOf(p)}</span>
            </div>
          </div>
          ${(ad && p.cost) || p.rollPrice ? `
            <div class="m-card-extra">
              ${ad && p.cost ? `<small class="mut">Alış: <b>${money(p.cost)}</b></small>` : ''}
              ${p.rollPrice ? `<small class="mut">Top: <b>${money(p.rollPrice)}</b> (${num(p.rollLen)} m)</small>` : ''}
            </div>
          ` : ''}
          <div class="m-card-actions">
            ${ad?`<button class="btn sm gr" onclick="stockIn('${p.id}')">+ Stok</button> <button class="btn sm ln" onclick="prodForm('${p.id}')">Düzenle</button>`:''}
            <button class="btn sm ln" onclick="bcOne('${p.id}')">🏷️ Barkod</button>
            ${ad?`<button class="btn sm rd" onclick="delProd('${p.id}')">Sil</button>`:''}
          </div>
        </div>
      `).join('')}
    </div>
  `;
}

let tmpImg, tmpIcon;
function prodForm(id,preBarcode){
  const sec = getActiveSector();
  const p=id?findP(id):{
    name:'',barcode:preBarcode||'',category:'',unit:sec.defaultUnit||'adet',cost:'',price:'',
    rollLen:'',rollPrice:'',stock:0,min:S.settings.defMin,img:null,icon:'',
    plu:'',sizes:'',colors:'',hanger:'',imei:'',deviceModel:'',isbn:'',author:'',rack:'',brand:'',expiry:''
  };
  tmpImg=undefined;
  tmpIcon=p.icon || '';
  const cats=[...new Set(S.products.map(x=>x.category).filter(Boolean))];
  const sf = sec.fields || [];

  modal(`<h2>${id?'Ürünü Düzenle':`Yeni Ürün Ekle (${sec.icon} ${sec.name})`}</h2>
  <div class="row">
    <div style="flex:2">
      <div class="f"><label>Ürün Adı *</label><input id="f_name" value="${h(p.name)}" placeholder="${sec.namePlaceholder || 'Ürün Adı yazın...'}"></div>
      <div class="f">
        <label>Barkod / Karekod / Ürün Kodu</label>
        <div style="display:flex;gap:6px">
          <input id="f_bc" value="${h(p.barcode)}" placeholder="${sec.barcodePlaceholder || 'Barkod okutun veya yazın'}" onkeydown="if(event.key==='Enter'){event.preventDefault();bcDup(this.value,'${id||''}');$('#f_cat').focus()}" onchange="bcDup(this.value,'${id||''}')">
          <button class="btn cam" type="button" title="Kamerayla Barkod Oku" onclick="openCamScan(c=>{$('#f_bc').value=c;bcDup(c,'${id||''}');toast('Barkod okundu: '+c,'ok')})">📷 Oku</button>
          <button class="btn ln" type="button" onclick="$('#f_bc').value=genBarcode()">Oluştur</button>
        </div>
      </div>
    </div>
    <div class="fix" style="text-align:center">
      <label>Ürün Görseli / İkonu</label>
      <div id="f_prev" style="width:96px;height:96px;margin:auto;border-radius:14px;overflow:hidden;background:#f8fafc;border:2px dashed #cbd5e1;display:grid;place-items:center;box-shadow:0 2px 6px rgba(0,0,0,0.04)">
        ${p.img?`<img src="${p.img}" style="width:100%;height:100%;object-fit:cover;display:block">`:`<span style="font-size:46px">${p.icon || getProductIconChar(p, sec.icon)}</span>`}
      </div>
      <div style="display:flex;gap:4px;margin-top:8px;justify-content:center;flex-wrap:wrap">
        <button class="btn sm" type="button" onclick="$('#f_cam').click()" title="Kamerayla Fotoğraf Çek">📷 Çek</button>
        <button class="btn sm ln" type="button" onclick="$('#f_img').click()" title="Görsel Yükle">🖼️ Seç</button>
        <button class="btn sm ln" type="button" onclick="openIconPicker(ic=>{tmpIcon=ic;tmpImg='';$('#f_prev').innerHTML='<span style=\\'font-size:46px\\'>'+ic+'</span>'})" title="Kütüphaneden İkon Seç">✨ İkon</button>
      </div>
      <input type="file" id="f_img" accept="image/*" hidden>
      <input type="file" id="f_cam" accept="image/*" capture="environment" hidden>
    </div>
  </div>
  <div class="row">
    <div class="f"><label>Kategori</label><input id="f_cat" list="cats" value="${h(p.category||'')}"><datalist id="cats">${cats.map(c=>`<option>${h(c)}`).join('')}</datalist></div>
    <div class="f">
      <label>Satış Birimi</label>
      <select id="f_unit" onchange="unitUI()">
        ${sec.units.map(u=>`<option value="${u}" ${(p.unit||'').toLowerCase()===u?'selected':''}>${u.toUpperCase()} Bazında</option>`).join('')}
      </select>
    </div>
    <div class="f">
      <label>KDV Oranı (GİB Yasal)</label>
      <select id="f_kdv">
        ${KDV_RATES.map(k=>`<option value="${k.rate}" ${(p.kdv!==undefined ? p.kdv : (sec.defaultKdv||20))===k.rate?'selected':''}>%${k.rate} - ${k.label} (${k.desc})</option>`).join('')}
      </select>
    </div>
  </div>
  <div class="row">
    <div class="f"><label id="l_cost">Alış Fiyatı (₺)</label><input id="f_cost" type="number" step="0.01" value="${p.cost}"></div>
    <div class="f"><label id="l_price">Perakende Satış (₺ / KDV Dahil)</label><input id="f_price" type="number" step="0.01" value="${p.price}"></div>
    <div class="f"><label id="l_wprice" style="color:#0284c7">🏷️ Toptan / Özel Fiyat (₺)</label><input id="f_wprice" type="number" step="0.01" value="${p.wprice||''}" placeholder="Opsiyonel"></div>
  </div>

  <!-- Sektöre Özel Ekstra Alanlar -->
  ${(sf.includes('scale')||sf.includes('plu')) ? `
    <div class="row" style="background:#f0fdf4;border:1px solid #bbf7d0;border-radius:10px;padding:8px 10px;margin-bottom:10px">
      <div class="f"><label style="color:#166534">⚖️ Terazi PLU Kodu (Opsiyonel)</label><input id="f_plu" value="${h(p.plu||'')}" placeholder="Örn: 105 (27/28 terazi barkodundaki ürün kodu)"></div>
      ${sf.includes('expiry') ? `<div class="f"><label style="color:#166534">⌛ Son Tüketim Tarihi (SKT)</label><input id="f_exp" type="date" value="${h(p.expiry||'')}"></div>` : ''}
    </div>
  ` : ''}

  ${(sf.includes('sizes')||sf.includes('variants')) ? `
    <div class="row" style="background:#fdf4ff;border:1px solid #f5d0fe;border-radius:10px;padding:8px 10px;margin-bottom:10px">
      <div class="f">
        <label style="color:#86198f">👗 Bedenler (Virgülle yazın veya seçin)</label>
        <input id="f_sizes" value="${h(p.sizes||'')}" placeholder="Örn: S, M, L, XL veya 38, 40, 42">
        <div style="display:flex;gap:4px;flex-wrap:wrap;margin-top:6px">
          ${(sec.sizes||[]).map(s=>`<span class="tag t-gray" style="cursor:pointer;font-weight:700" onclick="addChipVal('f_sizes','${s}')">+${s}</span>`).join('')}
        </div>
      </div>
      <div class="f">
        <label style="color:#86198f">🎨 Renkler</label>
        <input id="f_colors" value="${h(p.colors||'')}" placeholder="Örn: Siyah, Beyaz, Kırmızı">
        <div style="display:flex;gap:4px;flex-wrap:wrap;margin-top:6px">
          ${(sec.colors||[]).slice(0,6).map(c=>`<span class="tag t-gray" style="cursor:pointer" onclick="addChipVal('f_colors','${c}')">+${c}</span>`).join('')}
        </div>
      </div>
    </div>
  ` : ''}

  ${sf.includes('imei') ? `
    <div class="row" style="background:#eef2ff;border:1px solid #c7d2fe;border-radius:10px;padding:8px 10px;margin-bottom:10px">
      <div class="f"><label style="color:#3730a3">📱 Cihaz IMEI / Seri No</label><input id="f_imei" value="${h(p.imei||'')}" placeholder="15 haneli IMEI veya Cihaz Seri Numarası"></div>
      <div class="f"><label style="color:#3730a3">Cihaz Modeli & Garanti</label><input id="f_model" value="${h(p.deviceModel||'')}" placeholder="Örn: 128GB - 1 Yıl Distribütör Garantili"></div>
    </div>
  ` : ''}

  ${sf.includes('isbn') ? `
    <div class="row" style="background:#ecfeff;border:1px solid #a5f3fc;border-radius:10px;padding:8px 10px;margin-bottom:10px">
      <div class="f"><label style="color:#155e75">📚 ISBN No</label><input id="f_isbn" value="${h(p.isbn||'')}" placeholder="978-..."></div>
      <div class="f"><label style="color:#155e75">Yazar & Yayınevi</label><input id="f_author" value="${h(p.author||'')}" placeholder="Örn: Yaşar Kemal / YKY"></div>
    </div>
  ` : ''}

  ${sf.includes('rack')||sf.includes('brand') ? `
    <div class="row">
      ${sf.includes('rack') ? `<div class="f"><label>📍 Raf / Reyon / Konum</label><input id="f_rack" value="${h(p.rack||'')}" placeholder="Örn: A-12, Çekmece 3, Askı 2"></div>` : ''}
      ${sf.includes('brand') ? `<div class="f"><label>Marka / Üretici</label><input id="f_brand" value="${h(p.brand||'')}" placeholder="Örn: Bosch, Stanley, Nike"></div>` : ''}
    </div>
  ` : ''}

  <div class="row" id="rollBox">
    <div class="f"><label>Top / Makara Uzunluğu (Metre)</label><input id="f_rl" type="number" step="0.01" value="${p.rollLen||''}" placeholder="Örn: 100"></div>
    <div class="f"><label>Top / Makara Satış Fiyatı (₺)</label><input id="f_rp" type="number" step="0.01" value="${p.rollPrice||''}" placeholder="Boş bırakılabilir"></div>
  </div>
  <div class="row">
    <div class="f"><label id="l_stock">Mevcut Stok</label><input id="f_stock" type="number" step="0.001" value="${p.stock}" data-orig="${p.stock}"></div>
    <div class="f"><label>Minimum Stok (Alarm Sınırı)</label><input id="f_min" type="number" step="0.001" value="${p.min??''}"></div>
  </div>
  ${id?'<p class="mut" style="font-size:12px">Stok kutusunu sadece sayım düzeltmesi için değiştirin; yeni mal girişi için "+Stok" kullanın.</p>':''}
  <div class="mfoot"><button class="btn ln" onclick="closeModal()">İptal</button><button class="btn or" onclick="saveProd('${id||''}')">Kaydet</button></div>`);

  $('#f_img').onchange=$('#f_cam').onchange=async e=>{
    if(e.target.files[0]){
      tmpImg=await resizeImage(e.target.files[0]);
      $('#f_prev').innerHTML=`<img src="${tmpImg}" style="width:100%;height:100%;object-fit:cover;display:block">`;
    }
  };
  unitUI();
}

function addChipVal(inputId, val){
  const el = $('#' + inputId); if(!el) return;
  const cur = el.value.split(/[,/]/).map(s=>s.trim()).filter(Boolean);
  if(!cur.includes(val)){
    cur.push(val);
    el.value = cur.join(', ');
  }
}

function bcDup(v,id){
  const clean=String(v||'').trim();
  if(!clean)return;
  const p=S.products.find(x=>x.barcode===clean&&x.id!==id);
  if(p) toast(`⚠️ Bu barkod/karekod zaten "${p.name}" ürününde kayıtlı!`,'err');
}

function unitUI(){
  const u=$('#f_unit').value;
  const isMeter = u==='metre';
  const rb = $('#rollBox');
  if(rb) rb.hidden = !isMeter;
  $('#l_price').textContent = `Satış Fiyatı (₺ / ${u})`;
  $('#l_cost').textContent = `Alış Fiyatı (₺ / ${u})`;
  $('#l_stock').textContent = `Mevcut Stok (${u})`;
}

async function saveProd(id){
  const name=$('#f_name').value.trim();
  if(!name){toast('Ürün adı zorunludur!','err');return}
  const unit=$('#f_unit').value, sf=$('#f_stock');
  const data={
    name,
    barcode:$('#f_bc').value.trim()||genBarcode(),
    category:$('#f_cat').value.trim(),
    unit,
    kdv: parse($('#f_kdv')?.value ?? (sec.defaultKdv || 20)),
    cost:parse($('#f_cost').value),
    price:parse($('#f_price').value),
    wprice:$('#f_wprice')?.value===''?null:parse($('#f_wprice')?.value),
    rollLen:parse($('#f_rl')?.value),
    rollPrice:parse($('#f_rp')?.value),
    min:$('#f_min').value===''?null:parse($('#f_min').value),
    plu:$('#f_plu')?.value.trim()||'',
    sizes:$('#f_sizes')?.value.trim()||'',
    colors:$('#f_colors')?.value.trim()||'',
    hanger:$('#f_hanger')?.value.trim()||'',
    imei:$('#f_imei')?.value.trim()||'',
    deviceModel:$('#f_model')?.value.trim()||'',
    isbn:$('#f_isbn')?.value.trim()||'',
    author:$('#f_author')?.value.trim()||'',
    rack:$('#f_rack')?.value.trim()||'',
    brand:$('#f_brand')?.value.trim()||'',
    expiry:$('#f_exp')?.value.trim()||'',
    icon: tmpIcon !== undefined ? tmpIcon : (id ? (findP(id)?.icon || '') : '')
  };
  if(!id||sf.value!==sf.dataset.orig) data.stock=parse(sf.value);
  if(tmpImg!==undefined) data.img=tmpImg;

  if(await cmd('prodSave',{id:id||null,data})){
    closeModal();
    toast('Ürün başarıyla kaydedildi','ok');
    route();
  }
}

async function delProd(id){
  const p=findP(id);
  if(confirm(`"${p.name}" silinsin mi? (Geçmiş satış kayıtları korunur)`)){
    await cmd('prodDel',{id});
    route();
  }
}

function stockIn(id){
  const p=findP(id);
  modal(`<h2>Stok Girişi: ${h(p.name)}</h2><p class="mut">Mevcut Stok: <b>${stockOf(p)}</b></p>
  <div class="row">
    <div class="f"><label>Gelen Miktar (${unitOf(p)})</label><input id="si_q" type="number" step="0.01"></div>
    <div class="f"><label>Yeni Alış Fiyatı (Opsiyonel)</label><input id="si_c" type="number" step="0.01" value="${p.cost}"></div>
  </div>
  <div class="mfoot"><button class="btn ln" onclick="closeModal()">İptal</button><button class="btn gr" onclick="doStockIn('${id}')">Stoğa Ekle</button></div>`);
  setTimeout(()=>$('#si_q').focus(),50);
}

async function doStockIn(id){
  const q=parse($('#si_q').value);
  if(q<=0){toast('Geçerli miktar girin','err');return}
  if(await cmd('stockIn',{id,qty:q,cost:parse($('#si_c').value)})){
    closeModal();
    toast(`${q} eklendi`,'ok');
    route();
  }
}

/* ==========================================================================
   BARKOD VE ETİKET YAZDIRMA
   ========================================================================== */
let labelSel={};
function pBarcodes(){
  const showPriceDef = localStorage.getItem('hrd_label_show_price') !== 'false';
  $('#view').innerHTML=`<div class="card">
    <h3>Barkod Etiketi Yazdır</h3>
    <p class="mut">Etiket yazdırmak istediğiniz ürünleri seçin, adedini belirleyin ve yazdırın (Code 128 standardı, tüm optik okuyucularla uyumludur).</p>
    <div class="bar" style="flex-wrap:wrap;gap:10px">
      <input id="bq" placeholder="🔍 Ürün ara">
      <label style="display:inline-flex;align-items:center;gap:6px;cursor:pointer;font-weight:600;user-select:none;background:var(--card,#f8fafc);padding:6px 12px;border-radius:6px;border:1px solid var(--border,#cbd5e1)">
        <input type="checkbox" id="bcShowPrice" ${showPriceDef?'checked':''} onchange="localStorage.setItem('hrd_label_show_price',this.checked)" style="width:16px;height:16px;accent-color:var(--pri,#2563eb)"> 🏷️ Fiyatı Göster
      </label>
      <button class="btn or" onclick="printLabels()">🖨️ Seçilenleri Yazdır</button>
      <button class="btn ln" onclick="selAll()">Hepsini Seç</button>
    </div>
    <div class="tw" id="btab"></div>
  </div>
  <div class="card">
    <h3>Serbest Barkod Oluştur</h3>
    <div class="row">
      <div class="f"><label>Barkod Kodu</label><input id="free" placeholder="Boş bırakırsanız otomatik üretilir"></div>
      <div class="fix"><button class="btn" onclick="freeBC()">Önizle</button></div>
    </div>
    <div id="freeOut" style="text-align:center"></div>
  </div>`;
  $('#bq').oninput=drawB;drawB();
}

function drawB(){
  const q=($('#bq').value||'').toLowerCase();
  $('#btab').innerHTML=`<table><tr><th></th><th>Ürün</th><th>Barkod</th><th>Önizleme</th><th>Adet</th></tr>${S.products.filter(p=>!q||p.name.toLowerCase().includes(q)||p.barcode.includes(q)).map(p=>`<tr><td><input type="checkbox" style="width:auto" ${labelSel[p.id]?'checked':''} onchange="labelSel['${p.id}']=this.checked?(labelSel['${p.id}']||1):0"></td><td>${h(p.name)}</td><td><code>${h(p.barcode)}</code></td><td>${barcodeSVG(p.barcode,{mod:1,h:34,w:150,text:false})}</td><td style="width:80px"><input type="number" min="1" value="${labelSel[p.id]||1}" onchange="labelSel['${p.id}']=Math.max(1,+this.value);this.closest('tr').querySelector('input[type=checkbox]').checked=true"></td></tr>`).join('')}</table>`;
}

function selAll(){S.products.forEach(p=>labelSel[p.id]=labelSel[p.id]||1);drawB()}
function labelHTML(p,n,showPrice=true){
  let o='';
  for(let i=0;i<n;i++)
    o+=`<div class="lab"><b>${h(S.settings?.shop||'MSG YAZILIM')}</b><b>${h(p.name)}</b>${barcodeSVG(p.barcode,{mod:2,h:50})}${showPrice?`<b>${money(p.price)}${p.unit==='metre'?' / m':''}</b>`:''}</div>`;
  return o;
}
function printLabels(){
  const showPrice=$('#bcShowPrice')?$('#bcShowPrice').checked:(localStorage.getItem('hrd_label_show_price')!=='false');
  const l=S.products.filter(p=>labelSel[p.id]);
  if(!l.length){toast('Ürün seçin','err');return}
  printHTML(l.map(p=>labelHTML(p,labelSel[p.id],showPrice)).join(''),'Etiketler');
}
function bcOne(id){
  const p=findP(id);
  const showPriceDef=localStorage.getItem('hrd_label_show_price')!=='false';
  modal(`<h2>${h(p.name)}</h2>
    <div style="text-align:center">${barcodeSVG(p.barcode,{mod:3,h:90,w:360})}</div>
    <div class="row" style="margin-top:12px;gap:12px;align-items:center">
      <div class="f" style="flex:1">
        <label>Etiket Adedi</label>
        <input id="bn" type="number" min="1" value="1">
      </div>
      <div class="f" style="flex:1">
        <label>Fiyat Seçeneği</label>
        <label style="display:inline-flex;align-items:center;gap:6px;cursor:pointer;margin-top:6px;font-weight:600">
          <input type="checkbox" id="bn_price" ${showPriceDef?'checked':''} onchange="localStorage.setItem('hrd_label_show_price',this.checked)" style="width:18px;height:18px;accent-color:var(--pri,#2563eb)"> Etikette Fiyat Yazsın
        </label>
      </div>
    </div>
    <div class="mfoot">
      <button class="btn ln" onclick="closeModal()">Kapat</button>
      <button class="btn or" onclick="printHTML(labelHTML(findP('${id}'),Math.max(1,+$('#bn').value),$('#bn_price').checked),'Etiket')">🖨️ Yazdır</button>
    </div>`);
}

let freeVal='';
function freeBC(){
  freeVal=$('#free').value.trim()||genBarcode();
  $('#freeOut').innerHTML=barcodeSVG(freeVal,{mod:3,h:90,w:360})+`<div style="margin-top:10px"><button class="btn or" onclick="printHTML('<div class=lab>'+barcodeSVG(freeVal,{mod:2,h:50})+'</div>')">🖨️ Yazdır</button></div>`;
}

/* ==========================================================================
   VERESİYE VE MÜŞTERİ YÖNETİMİ
   ========================================================================== */
function pCust(){
  $('#view').innerHTML=`<div class="bar">
    <input id="cq" placeholder="🔍 Müşteri ara">
    <div class="grow"></div>
    <button class="btn or" onclick="custForm()">+ Yeni Müşteri Ekle</button>
  </div>
  ${overdueList().length?`<div class="card" style="border-left:5px solid var(--bad)">
    <h3 class="bad">⏰ Geciken Ödemeler (Vadesi Geçenler)</h3>
    <div class="tw"><table>${overdueList().map(o=>`<tr><td><b>${h(o.c.name)}</b> <small class="mut">${h(o.c.phone||'')}</small></td><td>Fiş #${o.s.no} • ${fdate(o.s.date)}</td><td><span class="tag t-bad">${o.days} gün gecikti</span></td><td class="r"><b>${money(o.rem)}</b></td><td class="r"><button class="btn sm gr" onclick="payForm('${o.c.id}')">Tahsil Et</button></td></tr>`).join('')}</table></div>
  </div>`:''}
  <div class="card tw" id="ctab"></div>`;

  const d=()=>{
    const q=$('#cq').value.toLowerCase();
    const l=S.customers.filter(c=>!q||c.name.toLowerCase().includes(q)||(c.phone||'').includes(q));
    if(!l.length){
      $('#ctab').innerHTML='<p class="mut" style="text-align:center;padding:30px">Kayıtlı müşteri yok.</p>';
      return;
    }
    $('#ctab').innerHTML=`
      <div class="desktop-only">
        <table>
          <tr><th>Müşteri Adı</th><th>Telefon</th><th class="r">Kalan Borç (Güncel)</th><th>Durum</th><th></th></tr>
          ${l.map(c=>{
            const b=balanceOf(c.id);
            const rows=creditRows(c.id);
            const totalDiff=round2(rows.reduce((a,r)=>a+(r.rem>0?r.priceDiff:0),0));
            const late=rows.some(r=>r.late);
            return `<tr>
              <td><b>${h(c.name)}</b></td>
              <td>${h(c.phone||'')}</td>
              <td class="r">
                <b>${money(b)}</b>
                ${totalDiff>0.01?`<br><small style="color:#d97706;font-weight:700" title="Stoktaki fiyat artışlarından doğan güncel fark">📈 +${money(totalDiff)} Fiyat Artışı</small>`:''}
              </td>
              <td>${late?'<span class="tag t-bad">Gecikmiş</span>':b>0?'<span class="tag t-warn">Borçlu</span>':'<span class="tag t-ok">Temiz</span>'}</td>
              <td class="r" style="white-space:nowrap">
                <button class="btn sm gr" onclick="payForm('${c.id}')">Tahsilat</button>
                <button class="btn sm ln" onclick="custDetail('${c.id}')">Ekstre / Fiyat Detayı</button>
                <button class="btn sm ln" onclick="custForm('${c.id}')">Düzenle</button>
              </td>
            </tr>`;
          }).join('')}
        </table>
      </div>
      <div class="mobile-only prod-cards-wrap">
        ${l.map(c=>{
          const b=balanceOf(c.id);
          const rows=creditRows(c.id);
          const totalDiff=round2(rows.reduce((a,r)=>a+(r.rem>0?r.priceDiff:0),0));
          const late=rows.some(r=>r.late);
          return `
            <div class="m-card">
              <div class="m-card-top">
                <div class="m-card-info">
                  <b style="font-size:15px">${h(c.name)}</b>
                  ${c.phone ? `<small class="mut">📞 <a href="tel:${h(c.phone)}" style="color:inherit;text-decoration:none;font-weight:600">${h(c.phone)}</a></small>` : ''}
                </div>
                <div class="m-card-price">
                  <b class="m-price-val" style="color:${b>0?'var(--bad)':'var(--ok)'}">${money(b)}</b>
                  ${late?'<span class="tag t-bad">Gecikmiş</span>':b>0?'<span class="tag t-warn">Borçlu</span>':'<span class="tag t-ok">Temiz</span>'}
                </div>
              </div>
              ${totalDiff>0.01?`
                <div style="background:#fffbeb;border:1px solid #fde68a;border-radius:8px;padding:6px 10px;font-size:12px">
                  <span style="color:#b45309;font-weight:700">📈 +${money(totalDiff)} Stok Fiyat Artışı Eklendi</span>
                </div>
              `:''}
              <div class="m-card-actions">
                <button class="btn sm gr" style="flex:1.2" onclick="payForm('${c.id}')">💰 Tahsilat</button>
                <button class="btn sm ln" style="flex:1" onclick="custDetail('${c.id}')">📋 Ekstre</button>
                <button class="btn sm ln" onclick="custForm('${c.id}')">✏️</button>
              </div>
            </div>
          `;
        }).join('')}
      </div>
    `;
  };
  $('#cq').oninput=d;d();
}

function custForm(id,fromPos){
  const c=id?S.customers.find(x=>x.id===id):{name:'',phone:'',address:'',creditLimit:''};
  modal(`<h2>${id?'Müşteri Düzenle':'Yeni Müşteri Ekle'}</h2>
  <div class="f"><label>Müşteri Ad Soyad / Firma Ünvanı *</label><input id="c_n" value="${h(c.name)}"></div>
  <div class="row">
    <div class="f"><label>Telefon</label><input id="c_p" value="${h(c.phone||'')}"></div>
    <div class="f"><label style="color:#dc2626">⚠️ Veresiye Borç Limiti (₺)</label><input id="c_lim" type="number" step="100" value="${c.creditLimit||''}" placeholder="Örn: 5000 (Boş = Limitsiz)"></div>
  </div>
  <div class="f"><label>Adres / Not</label><input id="c_a" value="${h(c.address||'')}"></div>
  <div class="mfoot"><button class="btn ln" onclick="closeModal()">İptal</button><button class="btn or" onclick="saveCust('${id||''}',${!!fromPos})">Kaydet</button></div>`);
}

async function saveCust(id,fromPos){
  const r=await cmd('custSave',{
    id:id||null,
    data:{
      name:$('#c_n').value,
      phone:$('#c_p').value,
      address:$('#c_a').value,
      creditLimit:$('#c_lim')?.value===''?null:parse($('#c_lim')?.value)
    }
  });
  if(!r)return;
  if(fromPos){curCart().cust=r.result.id}
  closeModal();
  if(fromPos)drawCart();else route();
}

function payForm(cid){
  const c=S.customers.find(x=>x.id===cid), b=balanceOf(cid);
  const rows=creditRows(cid);
  const totalDiff=round2(rows.reduce((a,r)=>a+(r.rem>0?r.priceDiff:0),0));
  modal(`<h2>Tahsilat Yap: ${h(c.name)}</h2>
  <p style="font-size:15px">Toplam Kalan Güncel Borç: <b class="bad" style="font-size:18px">${money(b)}</b></p>
  ${totalDiff>0.01?`<div style="background:#fff7e6;border:1px solid #fca311;border-radius:8px;padding:8px 12px;margin-bottom:12px;font-size:12px;color:#92400e">
    <b>📈 Fiyat Artışı Uyarısı:</b> Bu müşterinin aldığı ürünlerin güncel raf/stok fiyatları yükseldiği için borç tutarına <b>+${money(totalDiff)}</b> fiyat artışı yansıtılmıştır.
  </div>`:''}
  <div class="row">
    <div class="f"><label>Tahsil Edilen Tutar (₺)</label><input id="pm_a" type="number" step="0.01" value="${b}"></div>
    <div class="f"><label>Ödeme Türü</label><select id="pm_m"><option value="nakit">Nakit</option><option value="kart">Kredi Kartı</option></select></div>
  </div>
  <div class="mfoot"><button class="btn ln" onclick="closeModal()">İptal</button><button class="btn gr" onclick="doPay('${cid}')">Tahsil Et</button></div>`);
}

async function doPay(cid){
  const a=parse($('#pm_a').value);
  if(a<=0){toast('Geçerli tutar girin','err');return}
  if(await cmd('payment',{customerId:cid,amount:a,method:$('#pm_m').value})){
    closeModal();toast('Tahsilat kaydedildi','ok');route();
  }
}

function custDetail(cid){
  const c=S.customers.find(x=>x.id===cid), rows=creditRows(cid), pays=S.payments.filter(p=>p.customerId===cid);
  const curB=balanceOf(cid);
  const totalDiff=round2(rows.reduce((a,r)=>a+(r.rem>0?r.priceDiff:0),0));

  modal(`<h2>${h(c.name)} — Müşteri Ekstresi & Güncel Fiyat Analizi</h2>
  <div style="display:flex;gap:16px;align-items:center;margin-bottom:12px;flex-wrap:wrap">
    <div>Toplam Güncel Borç: <b class="bad" style="font-size:20px">${money(curB)}</b></div>
    ${totalDiff>0.01?`<div class="tag t-warn" style="font-size:13px;padding:4px 10px">📈 Toplam Fiyat Artışı Farkı: +${money(totalDiff)}</div>`:''}
    <div class="mut">${h(c.phone||'')}</div>
    ${c.phone ? `
      <a href="https://wa.me/${cleanPhoneForWa(c.phone)}?text=${encodeURIComponent(`Sayın ${c.name},\n${S.settings?.shop || 'İşletmemiz'} nezdindeki güncel hesap bakiyeniz: ${money(curB)}'dir.\nDetaylı bilgi için lütfen iletişime geçiniz.\nİyi günler dileriz.`)}" target="_blank" class="btn sm ok" style="text-decoration:none;display:inline-flex;align-items:center;gap:4px">
        💬 WhatsApp Özeti Gönder
      </a>
    ` : ''}
    <div style="margin-left:auto"><button class="btn sm ln" onclick="window.print()">🖨️ Yazdır</button></div>
  </div>

  <h3>Veresiye Satışlar ve Ürün Fiyat Değişimleri</h3>
  ${rows.length?rows.map(r=>`
    <div style="border:1px solid var(--line);border-radius:10px;padding:10px;margin-bottom:12px;background:#fafbfd">
      <div style="display:flex;justify-content:space-between;align-items:center;border-bottom:1px solid var(--line);padding-bottom:6px;margin-bottom:6px">
        <div>
          <b>Fiş #${r.s.no}</b> • Satış Tarihi: ${fdate(r.s.date)} • Vade: ${fdate(r.s.dueDate)}
          ${r.late?' <span class="tag t-bad">Vadesi Geçmiş</span>':''}
        </div>
        <div style="text-align:right">
          Orijinal Tutar: <b>${money(r.origTotal)}</b>
          ${r.hasIncrease?` ➔ <b style="color:#d97706" title="Fiyat artışlı güncel tutar">Güncel: ${money(r.curTotal)} (+${money(r.priceDiff)})</b>`:''}
          • Kalan Borç: <b class="bad">${money(r.rem)}</b>
        </div>
      </div>
      <table style="font-size:12px;background:#fff">
        <tr style="background:#f1f4f9">
          <th>Ürün</th>
          <th class="c">Miktar</th>
          <th class="r">Aldığı Fiyat</th>
          <th class="r">Stoktaki Güncel Fiyat</th>
          <th class="r">Fark / Artış</th>
          <th class="r">Güncel Tutar</th>
        </tr>
        ${r.itemsDetail.map(it=>`
          <tr style="${it.increased?'background:#fffdf5':''}">
            <td><b>${h(it.name)}</b></td>
            <td class="c">${num(it.qty)} ${it.unit}</td>
            <td class="r">${money(it.origPrice)}</td>
            <td class="r">${it.increased?`<b style="color:#d97706">${money(it.curPrice)}</b>`:`${money(it.curPrice)}`}</td>
            <td class="r">${it.increased?`<span class="tag t-warn">+${money(it.diffPerUnit)}/br (${money(it.lineDiff)})</span>`:'<span class="mut">—</span>'}</td>
            <td class="r"><b>${money(it.curTotal)}</b></td>
          </tr>
        `).join('')}
      </table>
    </div>
  `).join(''):'<p class="mut">Veresiye satışı yok</p>'}

  <h3 style="margin-top:16px">Yapılan Ödemeler ve Tahsilatlar</h3>
  <table>
    <tr><th>Tarih</th><th>Yöntem</th><th class="r">Tahsil Edilen Tutar</th></tr>
    ${pays.map(p=>`<tr><td>${fdt(p.date)}</td><td>${p.method==='kart'?'Kredi Kartı':'Nakit'}</td><td class="r"><b>${money(p.amount)}</b></td></tr>`).join('')||'<tr><td colspan=3 class="mut c">Ödeme kaydı yok</td></tr>'}
  </table>
  <div class="mfoot"><button class="btn ln" onclick="closeModal()">Kapat</button></div>`,true);
}

/* ==========================================================================
   SATIŞ GEÇMİŞİ
   ========================================================================== */
function pSales(){
  $('#view').innerHTML=`<div class="bar">
    <label style="margin:0">Tarih:</label><input type="date" id="sd" value="${dkey(new Date())}">
    <button class="btn ln" onclick="$('#sd').value='';drawSales()">Tümü</button>
    <select id="sm"><option value="">Tüm Ödeme Türleri</option><option value="nakit">Nakit</option><option value="kart">Kredi Kartı</option><option value="veresiye">Veresiye</option></select>
  </div>
  <div class="card tw" id="stab"></div>`;
  $('#sd').onchange=drawSales;$('#sm').onchange=drawSales;drawSales();
}

function drawSales(){
  const d=$('#sd').value, m=$('#sm').value;
  const l=S.sales.filter(s=>(!d||dkey(s.date)===d)&&(!m||s.method===m)).sort((a,b)=>b.date.localeCompare(a.date));
  const tot=round2(l.filter(s=>!s.void).reduce((a,s)=>a+s.total,0));
  if(!l.length){
    $('#stab').innerHTML='<p class="mut c" style="padding:28px">Satış kaydı yok</p>';
    return;
  }
  $('#stab').innerHTML=`
    <p style="margin:0 0 12px"><b>${l.length}</b> adet satış • Toplam Ciro: <b style="color:var(--ok);font-size:16px">${money(tot)}</b></p>
    <div class="desktop-only">
      <table>
        <tr><th>Fiş No</th><th>Tarih</th><th>Satılan Kalemler</th><th>Ödeme</th><th class="r">Tutar</th><th></th></tr>
        ${l.map(s=>{
          const c=S.customers.find(x=>x.id===s.customerId);
          return `<tr style="${s.void?'opacity:.5;text-decoration:line-through':''}">
            <td>#${s.no}</td>
            <td>${fdt(s.date)}${s.cashier?`<br><small class="mut">${h(s.cashier)}</small>`:''}</td>
            <td>${h(s.items.map(i=>`${i.name} (${num(i.qty)} ${i.unit})`).join(', ')).slice(0,100)}</td>
            <td><span class="tag ${s.method==='veresiye'?'t-warn':s.method==='kart'?'t-blue':s.method==='parcali'?'t-warn':'t-ok'}">${({nakit:'Nakit',kart:'Kredi Kartı',veresiye:'Veresiye',parcali:'Parçalı'})[s.method]||s.method}</span>${s.method==='parcali'?`<br><small class="mut">Nakit: ${money(s.paidCash)} • Kart: ${money(s.paidCard)}</small>`:''}${c?`<br><small>${h(c.name)}</small>`:''}</td>
            <td class="r"><b>${money(s.total)}</b></td>
            <td class="r" style="white-space:nowrap">
              <button class="btn sm" style="background:#16a34a;color:#fff;padding:4px 8px" onclick="sendReceiptViaWa('${s.id}')" title="WhatsApp ile Gönder">💬</button>
              <button class="btn sm ln" onclick="printChoiceModal('${s.id}')">🖨️ Yazdır</button>
              ${s.void?'<span class="tag t-gray">İptal Edildi</span>':`
                <button class="btn sm" style="background:#ea580c;color:#fff;padding:4px 8px" onclick="openReturnModal('${s.id}')" title="Kalem Bazlı / Parçalı İade Al">↩️ İade Al</button>
                ${isAdmin()?`<button class="btn sm rd" onclick="voidSale('${s.id}')" title="Tüm Fişi İptal Et">✕ İptal</button>`:''}
              `}
            </td>
          </tr>`;
        }).join('')}
      </table>
    </div>
    <div class="mobile-only prod-cards-wrap">
      ${l.map(s=>{
        const c=S.customers.find(x=>x.id===s.customerId);
        return `
          <div class="m-card" style="${s.void?'opacity:.5':''}">
            <div class="m-card-top">
              <div>
                <b style="font-size:15px">Fiş #${s.no}</b>
                <small class="mut" style="display:block">${fdt(s.date)}${s.cashier?` • ${h(s.cashier)}`:''}</small>
              </div>
              <div class="m-card-price">
                <b class="m-price-val" style="color:var(--navy)">${money(s.total)}</b>
                <span class="tag ${s.method==='veresiye'?'t-warn':s.method==='kart'?'t-blue':s.method==='parcali'?'t-warn':'t-ok'}">${({nakit:'Nakit',kart:'Kart',veresiye:'Veresiye',parcali:'Parçalı'})[s.method]||s.method}</span>
              </div>
            </div>
            ${c?`<div style="font-size:12px;font-weight:600;color:var(--navy)">👤 ${h(c.name)}</div>`:''}
            ${s.method==='parcali'?`<div style="font-size:11px;color:var(--mut);margin-top:2px">Nakit: ${money(s.paidCash)} • Kart: ${money(s.paidCard)}</div>`:''}
            <div style="font-size:12px;color:var(--mut);line-height:1.4;background:var(--bg);padding:6px 10px;border-radius:8px">
              ${h(s.items.map(i=>`${i.name} (${num(i.qty)} ${i.unit})`).join(', '))}
            </div>
            <div class="m-card-actions">
              <button class="btn sm" style="background:#16a34a;color:#fff" onclick="sendReceiptViaWa('${s.id}')" title="WhatsApp ile Fiş Gönder">💬 WhatsApp</button>
              <button class="btn sm ln" style="flex:1" onclick="printChoiceModal('${s.id}')">🖨️ Fiş Yazdır</button>
              ${s.void?'<span class="tag t-gray" style="align-self:center">İptal Edildi</span>':`
                <button class="btn sm" style="background:#ea580c;color:#fff" onclick="openReturnModal('${s.id}')">↩️ İade Al</button>
                ${isAdmin()?`<button class="btn sm rd" onclick="voidSale('${s.id}')">✕ İptal</button>`:''}
              `}
            </div>
          </div>
        `;
      }).join('')}
    </div>
  `;
}

function openReturnModal(saleId){
  const s = S.sales.find(x => x.id === saleId);
  if(!s) return;
  const c = S.customers.find(x => x.id === s.customerId);
  const sub = s.subtotal || round2(s.items.reduce((a, i) => a + i.qty * i.price, 0));
  const discRatio = sub > 0 ? Math.max(0, Math.min(1, (s.discount || 0) / sub)) : 0;
  const isFullyVoid = s.void;

  modal(`
    <div style="padding:4px 2px">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;border-bottom:2px solid var(--navy);padding-bottom:8px">
        <div>
          <h2 style="margin:0;font-size:19px;color:var(--navy);display:flex;align-items:center;gap:6px">
            ↩️ Ürün / Kalem İadesi Al • Fiş #${s.no} ${isFullyVoid ? '<span class="tag t-gray" style="font-size:12px">Tamamı İade Edildi</span>' : ''}
          </h2>
          <small class="mut">${fdt(s.date)} • Toplam Fiş: <b>${money(s.total)}</b> (${({nakit:'Nakit',kart:'Kredi Kartı',veresiye:'Veresiye',parcali:'Parçalı Ödeme'})[s.method]||s.method}) ${c?`• Müşteri: <b>${h(c.name)}</b>`:''}</small>
        </div>
        <button class="btn ln sm" onclick="closeModal()">✕</button>
      </div>

      <p class="mut" style="font-size:13px;margin:0 0 12px">
        ${isFullyVoid ? 'Bu fişteki tüm ürünler başarıyla iade alınmıştır.' : 'İade edilecek ürünün satırından iade miktarını (adet/kg vb.) belirleyip <b>"İade Al"</b> butonuna basınız. İade edilen miktar doğrudan <b>stoğa geri eklenir</b>.'}
      </p>

      <div style="overflow-x:auto;margin-bottom:16px">
        <table style="width:100%;font-size:13px;border-collapse:collapse">
          <thead>
            <tr style="background:#f1f5f9;color:#334155;border-bottom:2px solid #cbd5e1">
              <th style="padding:8px 6px;text-align:left">Ürün Adı</th>
              <th style="padding:8px 6px;text-align:right">Birim Fiyat</th>
              <th style="padding:8px 6px;text-align:center">Satılan</th>
              <th style="padding:8px 6px;text-align:center">İade Edilen</th>
              <th style="padding:8px 6px;text-align:center">Kalan</th>
              <th style="padding:8px 6px;text-align:center;min-width:180px">İade Edilecek Miktar</th>
              <th style="padding:8px 6px;text-align:right">İade Tutarı</th>
              <th style="padding:8px 6px;text-align:center;width:95px">İşlem</th>
            </tr>
          </thead>
          <tbody>
            ${s.items.map((i, idx) => {
              const returned = round3(num(i.returnedQty || 0));
              const available = round3(Math.max(0, i.qty - returned));
              const isAllReturned = available <= 0.0001;
              const unitPrice = num(i.price);
              const effectiveRefundUnit = round2(unitPrice * (1 - discRatio));

              return `
                <tr style="border-bottom:1px solid #e2e8f0;${isAllReturned?'opacity:0.5;background:#f8fafc':''}">
                  <td style="padding:8px 6px">
                    <b>${h(i.name)}</b>
                    ${i.variant?`<small class="mut">(${h(i.variant)})</small>`:''}
                    <div style="font-size:11px;color:#64748b">Barkod: ${h(i.barcode||'—')}</div>
                  </td>
                  <td style="padding:8px 6px;text-align:right">${money(unitPrice)}</td>
                  <td style="padding:8px 6px;text-align:center"><b>${num(i.qty)}</b> ${i.unit}</td>
                  <td style="padding:8px 6px;text-align:center;color:${returned>0?'#ea580c':'#64748b'}">${num(returned)} ${i.unit}</td>
                  <td style="padding:8px 6px;text-align:center;color:${available>0?'#16a34a':'#94a3b8'}"><b>${num(available)}</b> ${i.unit}</td>
                  <td style="padding:8px 6px;text-align:center">
                    ${isAllReturned ? '<span class="tag t-gray">Tamamen İade</span>' : `
                      <div style="display:flex;align-items:center;justify-content:center;gap:4px">
                        <button class="btn sm ln" type="button" style="padding:3px 7px;font-weight:700" title="Miktarı 1 Azalt" onclick="stepReturnQty(${idx}, -1, ${available}, ${effectiveRefundUnit})">-</button>
                        <input type="number" id="retQty_${idx}" step="0.001" min="0" max="${available}" value="0" 
                          style="width:70px;padding:4px 4px;border:1.5px solid #cbd5e1;border-radius:6px;text-align:center;font-weight:700;font-size:13px"
                          onfocus="if(this.value==='0')this.value=''"
                          onblur="if(this.value===''||isNaN(Number(this.value)))this.value='0';updateReturnCalc(${idx}, ${effectiveRefundUnit})"
                          oninput="updateReturnCalc(${idx}, ${effectiveRefundUnit})">
                        <button class="btn sm ln" type="button" style="padding:3px 7px;font-weight:700" title="Miktarı 1 Arttır" onclick="stepReturnQty(${idx}, 1, ${available}, ${effectiveRefundUnit})">+</button>
                        <button class="btn sm" type="button" style="background:#f1f5f9;color:#334155;border:1px solid #cbd5e1;padding:3px 6px;font-size:11px;font-weight:600" title="Tüm Kalanı Seç" onclick="setReturnQty(${idx}, ${available}, ${available}, ${effectiveRefundUnit})">Tümü</button>
                      </div>
                    `}
                  </td>
                  <td style="padding:8px 6px;text-align:right;font-weight:700;color:#ea580c" id="retAmount_${idx}">
                    ${isAllReturned ? '—' : money(0)}
                  </td>
                  <td style="padding:8px 6px;text-align:center">
                    ${isAllReturned ? '✓' : `
                      <button class="btn sm" style="background:#ea580c;color:#fff;font-weight:700;padding:6px 10px" onclick="submitItemReturn('${s.id}', ${idx})">
                        İade Al
                      </button>
                    `}
                  </td>
                </tr>
              `;
            }).join('')}
          </tbody>
        </table>
      </div>

      <!-- İade Ödeme Şekli ve Not Seçimi -->
      <div style="background:#fff7ed;border:1px solid #fed7aa;border-radius:10px;padding:10px 14px;margin-bottom:14px;display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap">
        <div>
          <b style="color:#9a3412;font-size:13px">İade Bedeli Müşteriye Nasıl Ödenecek?</b>
          <small style="color:#c2410c;display:block">
            ${s.method==='veresiye' ? 'Müşterinin veresiye borcundan otomatik düşülecektir.' : 'Kasadan nakit mi yoksa karta iade mi yapılacak?'}
          </small>
        </div>
        <div style="display:flex;gap:8px;align-items:center">
          <select id="retRefundMethod" style="padding:6px 10px;font-size:13px;border:1px solid #cbd5e1;border-radius:6px">
            ${s.method==='veresiye' ? `
              <option value="veresiye">Müşteri Veresiye Borcundan Düş</option>
              <option value="nakit">Kasadan Nakit Öde</option>
            ` : `
              <option value="nakit">Kasadan Nakit İade</option>
              <option value="kart">Karta / POS İade</option>
            `}
          </select>
          <input type="text" id="retNote" placeholder="İade Nedeni / Açıklama (Opsiyonel)" style="padding:6px 10px;font-size:13px;width:200px;border:1px solid #cbd5e1;border-radius:6px">
        </div>
      </div>

      ${s.returns && s.returns.length > 0 ? `
        <div style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:10px;padding:10px 12px;margin-bottom:14px">
          <b style="font-size:12px;color:#475569;display:block;margin-bottom:6px">📋 Bu Fişten Daha Önce Yapılan İadeler:</b>
          <div style="font-size:12px;color:#334155;line-height:1.5">
            ${s.returns.map(r => `
              <div style="display:flex;justify-content:space-between;border-bottom:1px dashed #cbd5e1;padding:3px 0">
                <span>• <b>${h(r.name)}</b> (${num(r.qty)} ${r.unit}) - ${fdt(r.date)} <small class="mut">(${h(r.cashier||'')})</small></span>
                <span style="font-weight:700;color:#dc2626">- ${money(r.refundAmount)}</span>
              </div>
            `).join('')}
          </div>
        </div>
      ` : ''}

      <div style="display:flex;justify-content:flex-end;gap:8px">
        <button class="btn ln" onclick="closeModal()">Kapat</button>
      </div>
    </div>
  `);
}

function updateReturnCalc(idx, unitRefundPrice){
  const inp = $(`#retQty_${idx}`);
  const out = $(`#retAmount_${idx}`);
  if(!inp || !out) return;
  const q = parse(inp.value);
  if(q > 0) inp.style.borderColor = '#ea580c';
  else inp.style.borderColor = '#cbd5e1';
  out.textContent = money(round2(Math.max(0, q) * unitRefundPrice));
}

function stepReturnQty(idx, delta, maxQty, unitRefundPrice){
  const inp = $(`#retQty_${idx}`);
  if(!inp) return;
  let cur = parse(inp.value) || 0;
  cur = round3(cur + delta);
  if(cur < 0) cur = 0;
  if(cur > maxQty) cur = maxQty;
  inp.value = cur;
  updateReturnCalc(idx, unitRefundPrice);
}

function setReturnQty(idx, val, maxQty, unitRefundPrice){
  const inp = $(`#retQty_${idx}`);
  if(!inp) return;
  let cur = round3(val);
  if(cur < 0) cur = 0;
  if(cur > maxQty) cur = maxQty;
  inp.value = cur;
  updateReturnCalc(idx, unitRefundPrice);
}

async function submitItemReturn(saleId, itemIndex){
  const s = S.sales.find(x => x.id === saleId);
  if(!s) return;
  const item = s.items[itemIndex];
  if(!item) return;

  const inp = $(`#retQty_${itemIndex}`);
  const qty = parse(inp ? inp.value : 0);
  if(qty <= 0){
    toast(`Lütfen "${item.name}" için iade edilecek miktarı giriniz (0'dan büyük olmalı)`, 'err');
    if(inp) { inp.focus(); inp.select(); }
    return;
  }

  const refundMethod = $('#retRefundMethod')?.value || 'nakit';
  const note = $('#retNote')?.value?.trim() || '';

  const confirmMsg = `"${item.name}" ürününden ${qty} ${item.unit} iade alınacak ve STOĞA GERİ EKLENECEK.\n\nİadeyi onaylıyor musunuz?`;
  if(!confirm(confirmMsg)) return;

  const res = await cmd('returnItem', {
    saleId,
    itemIndex,
    qty,
    refundMethod,
    note
  });

  if(res){
    toast(`${item.name} (${qty} ${item.unit}) başarıyla iade alındı ve stoğa eklendi!`, 'ok');
    drawSales();
    // Modal içeriğini güncelle
    openReturnModal(saleId);
  }
}

async function voidSale(id){
  const s=S.sales.find(x=>x.id===id);
  if(!confirm(`Fiş #${s.no} tamamen iptal edilsin ve kalan tüm ürünler stoğa geri iade edilsin mi?`))return;
  if(await cmd('voidSale',{id})){drawSales();toast('Satış iptal edildi, ürünler stoğa iade edildi','ok')}
}

/* ==========================================================================
   GİDERLER VE ÖN MUHASEBE
   ========================================================================== */
const EXPCATS=['Kira','Elektrik','Su','İnternet / Telefon','Maaş','Vergi / SGK','Nakliye','Yemek','Bakım / Onarım','Diğer'];

function pExp(){
  const m=dkey(new Date()).slice(0,7);
  $('#view').innerHTML=`<div class="grid g2">
    <div class="card">
      <h3>Yeni Gider Ekle</h3>
      <div class="row">
        <div class="f"><label>Tarih</label><input type="date" id="e_d" value="${dkey(new Date())}"></div>
        <div class="f"><label>Kategori</label><select id="e_c">${EXPCATS.map(c=>`<option>${c}`).join('')}</select></div>
      </div>
      <div class="row">
        <div class="f"><label>Açıklama</label><input id="e_t" placeholder="Örn: Dükkan elektrik faturası"></div>
        <div class="f"><label>Tutar (₺)</label><input id="e_a" type="number" step="0.01"></div>
      </div>
      <button class="btn or" onclick="addExp()">Gideri Kaydet</button>
    </div>
    <div class="card"><h3>Bu Ayın Gider Dağılımı (${m})</h3><div id="expSum"></div></div>
  </div>
  <div class="card tw">
    <h3>Gider Listesi</h3>
    <table>
      <tr><th>Tarih</th><th>Kategori</th><th>Açıklama</th><th class="r">Tutar</th><th></th></tr>
      ${[...S.expenses].sort((a,b)=>b.date.localeCompare(a.date)).map(e=>`<tr><td>${fdate(e.date)}</td><td>${h(e.category)}</td><td>${h(e.desc)}</td><td class="r"><b>${money(e.amount)}</b></td><td class="r"><button class="btn sm rd" onclick="delExp('${e.id}')">Sil</button></td></tr>`).join('')||'<tr><td colspan=5 class="mut c">Gider kaydı yok</td></tr>'}
    </table>
  </div>`;
  const by={};S.expenses.filter(e=>dkey(e.date).startsWith(m)).forEach(e=>by[e.category]=(by[e.category]||0)+e.amount);
  $('#expSum').innerHTML=Object.keys(by).length?`<table>${Object.entries(by).map(([k,v])=>`<tr><td>${h(k)}</td><td class="r"><b>${money(v)}</b></td></tr>`).join('')}</table>`:'<p class="mut">Bu ay gider kaydı yok.</p>';
}

async function addExp(){
  const a=parse($('#e_a').value);
  if(a<=0){toast('Geçerli tutar girin','err');return}
  if(await cmd('expAdd',{date:new Date($('#e_d').value+'T12:00:00').toISOString(),category:$('#e_c').value,desc:$('#e_t').value.trim(),amount:a})){
    toast('Gider kaydedildi','ok');route();
  }
}
async function delExp(id){
  if(confirm('Gider kaydı silinsin mi?')){await cmd('expDel',{id});route()}
}

/* Gelir-Gider Raporları */
let rFrom='',rTo='';
function setRange(k){
  const n=new Date();let f=new Date(n);
  if(k==='today')f=new Date(n);
  else if(k==='week')f.setDate(n.getDate()-6);
  else if(k==='month')f=new Date(n.getFullYear(),n.getMonth(),1);
  else if(k==='year')f=new Date(n.getFullYear(),0,1);
  rFrom=dkey(f);rTo=dkey(n);pRep();
}

function pRep(){
  if(!rFrom)setRange('month');
  const inR=d=>{const k=dkey(d);return k>=rFrom&&k<=rTo};
  const sl=S.sales.filter(s=>!s.void&&inR(s.date)),ex=S.expenses.filter(e=>inR(e.date)),pay=S.payments.filter(p=>inR(p.date));
  const sum=(a,f)=>round2(a.reduce((x,i)=>x+f(i),0));
  const ciro=sum(sl,s=>s.total),cogs=sum(sl,s=>s.cost),gross=round2(ciro-cogs),exp=sum(ex,e=>e.amount),net=round2(gross-exp);
  const nakit=round2(sum(sl.filter(s=>s.method==='nakit'),s=>s.total) + sum(sl.filter(s=>s.method==='parcali'),s=>s.paidCash||0));
  const kart=round2(sum(sl.filter(s=>s.method==='kart'),s=>s.total) + sum(sl.filter(s=>s.method==='parcali'),s=>s.paidCard||0));
  const ver=sum(sl.filter(s=>s.method==='veresiye'),s=>s.total),tah=sum(pay,p=>p.amount);
  const cashIn=round2(nakit+kart+tah),cashNet=round2(cashIn-exp);
  const byDay={};sl.forEach(s=>{const k=dkey(s.date);byDay[k]=byDay[k]||{c:0,k:0};byDay[k].c+=s.total;byDay[k].k+=s.total-s.cost});
  const byCat={};ex.forEach(e=>byCat[e.category]=(byCat[e.category]||0)+e.amount);
  const prod={};sl.forEach(s=>s.items.forEach(i=>{const o=prod[i.name]=prod[i.name]||{q:0,t:0,k:0,u:i.unit};o.q+=i.qty;o.t+=i.qty*i.price;o.k+=i.qty*i.price-i.cost}));

  $('#view').innerHTML=`<div class="bar">
    <button class="btn ln" onclick="setRange('today')">Bugün</button>
    <button class="btn ln" onclick="setRange('week')">Son 7 Gün</button>
    <button class="btn ln" onclick="setRange('month')">Bu Ay</button>
    <button class="btn ln" onclick="setRange('year')">Bu Yıl</button>
    <input type="date" id="rf" value="${rFrom}" onchange="rFrom=this.value;pRep()">
    <input type="date" id="rt" value="${rTo}" onchange="rTo=this.value;pRep()">
    <button class="btn or" onclick="openZReportModal(rTo||rFrom)" title="Seçili tarihin Gün Sonu Z Raporunu Aç">📊 Z Raporu</button>
    <div class="grow"></div>
    <button class="btn" onclick="window.print()">🖨️ Yazdır</button>
  </div>
  <div class="grid g4" style="margin-bottom:18px">
    <div class="stat blue"><small>Toplam Ciro</small><b>${money(ciro)}</b></div>
    <div class="stat"><small>Satılan Malın Maliyeti</small><b>${money(cogs)}</b></div>
    <div class="stat green"><small>Brüt Ticari Kâr</small><b>${money(gross)}</b></div>
    <div class="stat red"><small>İşletme Giderleri</small><b>${money(exp)}</b></div>
    <div class="stat ${net>=0?'green':'red'}"><small>NET FAALİYET KÂRI</small><b>${money(net)}</b></div>
  </div>
  <div class="grid g2">
    <div class="card">
      <h3>Kasa ve Nakit Akışı</h3>
      <table>
        <tr><td>Nakit Satışlar</td><td class="r">${money(nakit)}</td></tr>
        <tr><td>Kredi Kartı Satışları</td><td class="r">${money(kart)}</td></tr>
        <tr><td>Veresiye Tahsilatları</td><td class="r">${money(tah)}</td></tr>
        <tr><td><b>Toplam Kasaya Giren</b></td><td class="r"><b>${money(cashIn)}</b></td></tr>
        <tr><td>Ödenen Giderler</td><td class="r bad">- ${money(exp)}</td></tr>
        <tr><td><b>Net Kasa Bakiyesi</b></td><td class="r"><b>${money(cashNet)}</b></td></tr>
        <tr><td class="mut">Dönem İçi Açık Veresiye Satış</td><td class="r mut">${money(ver)}</td></tr>
      </table>
    </div>
    <div class="card"><h3>Giderlerin Dağılımı</h3><table>${Object.entries(byCat).map(([k,v])=>`<tr><td>${h(k)}</td><td class="r">${money(v)}</td></tr>`).join('')||'<tr><td class="mut">Gider yok</td></tr>'}</table></div>
  </div>
  <div class="card tw">
    <h3>Ürün Bazında Satış ve Kârlılık</h3>
    <table>
      <tr><th>Ürün</th><th class="r">Satılan Miktar</th><th class="r">Toplam Ciro</th><th class="r">Elde Edilen Kâr</th></tr>
      ${Object.entries(prod).sort((a,b)=>b[1].t-a[1].t).map(([k,v])=>`<tr><td>${h(k)}</td><td class="r">${num(v.q)} ${v.u}</td><td class="r">${money(v.t)}</td><td class="r">${money(v.k)}</td></tr>`).join('')||'<tr><td colspan=4 class="mut c">Veri yok</td></tr>'}
    </table>
  </div>`;
}

/* ==========================================================================
   KASA GÜN SONU / Z RAPORU & DEVİR MODÜLÜ
   ========================================================================== */
function getZReportData(dateStr){
  const targetDate = dateStr || dkey(new Date());
  const sl = S.sales.filter(s => !s.void && dkey(s.date) === targetDate);
  const ex = S.expenses.filter(e => dkey(e.date) === targetDate);
  const pay = S.payments.filter(p => dkey(p.date) === targetDate);
  
  const sum = (a, f) => round2(a.reduce((x, i) => x + f(i), 0));
  const nakit = round2(sum(sl.filter(s => s.method === 'nakit'), s => s.total) + sum(sl.filter(s => s.method === 'parcali'), s => s.paidCash || 0));
  const kart = round2(sum(sl.filter(s => s.method === 'kart'), s => s.total) + sum(sl.filter(s => s.method === 'parcali'), s => s.paidCard || 0));
  const ver = sum(sl.filter(s => s.method === 'veresiye'), s => s.total);
  const tah = sum(pay, p => p.amount);
  const totalCiro = sum(sl, s => s.total);
  const totalCost = sum(sl, s => s.cost);
  const grossProfit = round2(totalCiro - totalCost);
  const totalExp = sum(ex, e => e.amount);
  
  // Kasaya devir / açılış avansı (localStorage bazlı gün anahtarı)
  const openingKey = 'msg_z_opening_' + targetDate;
  const openingFloat = parse(localStorage.getItem(openingKey) || '0');
  
  // Kasada olması gereken fiziki nakit: Devir + Nakit Satış + Nakit Tahsilat - Giderler
  const expectedCash = round2(openingFloat + nakit + tah - totalExp);

  // Günlük KDV Toplamları (Resmi GİB KDV Raporu)
  const kdvSummary = { 1: { matrah: 0, kdv: 0 }, 10: { matrah: 0, kdv: 0 }, 20: { matrah: 0, kdv: 0 }, 0: { matrah: 0, kdv: 0 } };
  let totalKdv = 0;
  let totalMatrah = 0;

  sl.forEach(s => {
    const bk = calculateKdvBreakdown(s.items, s.discount, s.total);
    bk.groups.forEach(g => {
      const r = g.rate;
      if(!kdvSummary[r]) kdvSummary[r] = { matrah: 0, kdv: 0 };
      kdvSummary[r].matrah = round2(kdvSummary[r].matrah + g.matrah);
      kdvSummary[r].kdv = round2(kdvSummary[r].kdv + g.kdv);
    });
    totalKdv = round2(totalKdv + bk.totalKdv);
    totalMatrah = round2(totalMatrah + bk.totalMatrah);
  });
  
  return {
    date: targetDate,
    saleCount: sl.length,
    totalCiro,
    grossProfit,
    nakit,
    kart,
    ver,
    tah,
    totalExp,
    openingFloat,
    expectedCash,
    openingKey,
    sales: sl,
    expenses: ex,
    kdvSummary,
    totalKdv,
    totalMatrah
  };
}

function openZReportModal(dateStr){
  const z = getZReportData(dateStr);
  const sec = getActiveSector();
  const shop = S.settings?.shop || sec.name;

  modal(`
    <div style="padding:4px 2px">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px;border-bottom:2px solid var(--navy);padding-bottom:10px">
        <div>
          <h2 style="margin:0;font-size:20px;color:var(--navy);display:flex;align-items:center;gap:8px">
            📊 Gün Sonu Kasa Raporu (Z Raporu)
          </h2>
          <small class="mut" style="font-size:12px">${h(shop)} • Tarih: <b>${fdate(z.date)}</b></small>
        </div>
        <div style="display:flex;gap:6px">
          <input type="date" value="${z.date}" onchange="openZReportModal(this.value)" style="padding:4px 8px;font-size:12px;border:1px solid #cbd5e1;border-radius:6px">
          <button class="btn ln sm" onclick="closeModal()">✕</button>
        </div>
      </div>

      <!-- Kasa Açılış / Devir Avansı Girişi -->
      <div style="background:#f0f9ff;border:1.5px solid #bae6fd;border-radius:12px;padding:12px 14px;margin-bottom:14px;display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap">
        <div>
          <b style="color:#0369a1;font-size:13px;display:block">🪙 Kasa Açılış / Sabah Devir Avansı</b>
          <small style="color:#0284c7">Güne başlarken kasada bulunan bozuk para / devir tutarı</small>
        </div>
        <div style="display:flex;gap:6px;align-items:center">
          <input type="number" id="zOpeningInp" step="0.01" value="${z.openingFloat||''}" placeholder="0.00" style="width:110px;font-size:16px;font-weight:800;padding:6px 10px;text-align:right;border:1.5px solid #0284c7;border-radius:8px">
          <button class="btn or sm" onclick="saveZOpening('${z.openingKey}')" style="font-weight:700;padding:8px 12px">Kaydet</button>
        </div>
      </div>

      <!-- Kasa Özet Kartları -->
      <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:10px;margin-bottom:14px">
        <div style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:10px;padding:10px;text-align:center">
          <small style="color:#64748b;font-weight:700">TOPLAM CİRO</small>
          <b style="display:block;font-size:20px;color:var(--navy);margin-top:2px">${money(z.totalCiro)}</b>
          <small style="color:#64748b">${z.saleCount} Adet Fiş</small>
        </div>
        <div style="background:#ecfdf5;border:1px solid #a7f3d0;border-radius:10px;padding:10px;text-align:center">
          <small style="color:#047857;font-weight:700">GÜN İÇİ NAKİT</small>
          <b style="display:block;font-size:20px;color:#059669;margin-top:2px">${money(z.nakit)}</b>
          <small style="color:#047857">Satış Nakdi</small>
        </div>
        <div style="background:#eff6ff;border:1px solid #bfdbfe;border-radius:10px;padding:10px;text-align:center">
          <small style="color:#1d4ed8;font-weight:700">KREDİ KARTI</small>
          <b style="display:block;font-size:20px;color:#2563eb;margin-top:2px">${money(z.kart)}</b>
          <small style="color:#1d4ed8">POS Cihazı Toplamı</small>
        </div>
        <div style="background:#fef2f2;border:1px solid #fecaca;border-radius:10px;padding:10px;text-align:center">
          <small style="color:#b91c1c;font-weight:700">ÖDENEN GİDER</small>
          <b style="display:block;font-size:20px;color:#dc2626;margin-top:2px">- ${money(z.totalExp)}</b>
          <small style="color:#b91c1c">${z.expenses.length} Kalem Masraf</small>
        </div>
      </div>

      <!-- Kasa Mutabakat Tablosu -->
      <table style="width:100%;border-collapse:collapse;margin-bottom:14px;font-size:13px">
        <tr style="border-bottom:1px solid #e2e8f0"><td style="padding:6px 4px">Sabah Devir Avansı</td><td class="r">${money(z.openingFloat)}</td></tr>
        <tr style="border-bottom:1px solid #e2e8f0"><td style="padding:6px 4px">Nakit Satışlar (+)</td><td class="r" style="color:#16a34a">+ ${money(z.nakit)}</td></tr>
        <tr style="border-bottom:1px solid #e2e8f0"><td style="padding:6px 4px">Veresiye Tahsilatları (+)</td><td class="r" style="color:#16a34a">+ ${money(z.tah)}</td></tr>
        <tr style="border-bottom:1px solid #e2e8f0"><td style="padding:6px 4px">Kasadan Çıkan Masraflar (-)</td><td class="r" style="color:#dc2626">- ${money(z.totalExp)}</td></tr>
        <tr style="background:#14213d;color:#fff;font-weight:800;font-size:15px">
          <td style="padding:10px 8px;border-radius:8px 0 0 8px">KASADA OLMASI GEREKEN NAKİT</td>
          <td class="r" style="padding:10px 8px;border-radius:0 8px 8px 0;color:#4ade80">${money(z.expectedCash)}</td>
        </tr>
      </table>

      <!-- GİB KDV Rapor Tablosu -->
      <div style="background:#f8fafc;border:1px solid #cbd5e1;border-radius:10px;padding:10px 12px;margin-bottom:16px">
        <div style="font-weight:700;color:#0f172a;font-size:13px;margin-bottom:6px">📋 GİB KDV Dağılım İcmali (Fiyatlara Dahil)</div>
        <table style="width:100%;border-collapse:collapse;font-size:12px">
          <tr style="border-bottom:1.5px solid #cbd5e1;color:#475569">
            <th style="text-align:left;padding:4px 0">Oran</th>
            <th style="text-align:right;padding:4px 0">KDV Matrahı (Net)</th>
            <th style="text-align:right;padding:4px 0">Hesaplanan KDV</th>
          </tr>
          ${[1, 10, 20, 0].filter(r => (z.kdvSummary[r]?.matrah || 0) > 0 || (z.kdvSummary[r]?.kdv || 0) > 0).map(r => `
            <tr style="border-bottom:1px solid #e2e8f0">
              <td style="padding:4px 0"><b>%${r}</b> (${KDV_RATES.find(k=>k.rate===r)?.label || 'KDV'})</td>
              <td class="r" style="padding:4px 0">${money(z.kdvSummary[r]?.matrah || 0)}</td>
              <td class="r" style="padding:4px 0;font-weight:700">${money(z.kdvSummary[r]?.kdv || 0)}</td>
            </tr>
          `).join('') || '<tr><td colspan="3" style="text-align:center;color:#64748b;padding:6px 0">Kayıtlı KDV işlemi yok</td></tr>'}
          <tr style="font-weight:800;border-top:1.5px solid #14213d;font-size:13px">
            <td style="padding:6px 0">TOPLAM KDV:</td>
            <td class="r" style="padding:6px 0">${money(z.totalMatrah)}</td>
            <td class="r" style="padding:6px 0;color:#14213d">${money(z.totalKdv)}</td>
          </tr>
        </table>
      </div>

      <!-- Aksiyon Butonları -->
      <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:10px">
        <button class="btn or" onclick="printZReportReceipt('${z.date}')" style="padding:12px 8px;font-weight:700;border-radius:10px">
          🧾 Z Raporu Fişi Bas (80mm/58mm)
        </button>
        <button class="btn" style="background:#2563eb;color:#fff;padding:12px 8px;font-weight:700;border-radius:10px" onclick="printZReportA4('${z.date}')">
          📄 A4 Kasa Raporu Yazdır
        </button>
        <button class="btn ln" onclick="closeModal()" style="border-radius:10px">
          ✕ Kapat
        </button>
      </div>
    </div>
  `);
}

function saveZOpening(key){
  const inp = $('#zOpeningInp');
  if(!inp) return;
  const val = parse(inp.value);
  localStorage.setItem(key, String(val));
  toast('Kasa açılış tutarı güncellendi: ' + money(val), 'ok');
  openZReportModal(key.replace('msg_z_opening_', ''));
}

function printZReportReceipt(dateStr){
  const z = getZReportData(dateStr);
  const sec = getActiveSector();
  const shop = S.settings?.shop || sec.name;

  printHTML(`
    <div style="width:290px;margin:auto;font-family:'Courier New',Courier,monospace;font-size:12px;line-height:1.4">
      <div style="text-align:center">
        <h2 style="margin:0;font-size:16px">${sec.icon} ${h(shop)}</h2>
        <div style="font-size:11px">${h(sec.name)}</div>
        <hr style="border:0;border-top:1px dashed #000;margin:6px 0">
        <b style="font-size:14px">GÜN SONU KASA RAPORU (Z)</b><br>
        Tarih: ${fdate(z.date)} • Saat: ${new Date().toLocaleTimeString('tr-TR')}
      </div>
      <hr style="border:0;border-top:1px dashed #000;margin:6px 0">
      <table style="width:100%;font-size:12px">
        <tr><td>Toplam Satış Adedi:</td><td class="r"><b>${z.saleCount}</b></td></tr>
        <tr><td>Toplam Ciro:</td><td class="r"><b>${money(z.totalCiro)}</b></td></tr>
        <tr><td>Brüt Ticari Kâr:</td><td class="r"><b>${money(z.grossProfit)}</b></td></tr>
      </table>
      <hr style="border:0;border-top:1px dashed #000;margin:6px 0">
      <div style="font-weight:700;margin-bottom:2px">ÖDEME DAĞILIMI:</div>
      <table style="width:100%;font-size:12px">
        <tr><td>💵 Nakit Satış:</td><td class="r">${money(z.nakit)}</td></tr>
        <tr><td>💳 Kredi Kartı:</td><td class="r">${money(z.kart)}</td></tr>
        <tr><td>👥 Veresiye Satış:</td><td class="r">${money(z.ver)}</td></tr>
        <tr><td>📥 Veresiye Tahsilat:</td><td class="r">${money(z.tah)}</td></tr>
        <tr><td>📤 Kasadan Gider:</td><td class="r">- ${money(z.totalExp)}</td></tr>
      </table>
      <hr style="border:0;border-top:1px dashed #000;margin:6px 0">
      <div style="font-weight:700;margin-bottom:2px">KDV DAĞILIMI (FİYATA DAHİL):</div>
      <table style="width:100%;font-size:11px">
        ${[1, 10, 20, 0].filter(r => (z.kdvSummary[r]?.matrah || 0) > 0 || (z.kdvSummary[r]?.kdv || 0) > 0).map(r => `
          <tr><td>%${r} Matrah: ${money(z.kdvSummary[r].matrah)}</td><td class="r">KDV: <b>${money(z.kdvSummary[r].kdv)}</b></td></tr>
        `).join('')}
        <tr style="border-top:1px dotted #000;font-weight:bold"><td>TOPLAM KDV:</td><td class="r">${money(z.totalKdv)}</td></tr>
      </table>
      <hr style="border:0;border-top:1px dashed #000;margin:6px 0">
      <table style="width:100%;font-size:13px;font-weight:800">
        <tr><td>Devir Avansı:</td><td class="r">${money(z.openingFloat)}</td></tr>
        <tr><td>KASADA OLAN NAKİT:</td><td class="r">${money(z.expectedCash)}</td></tr>
      </table>
      <hr style="border:0;border-top:1px dashed #000;margin:6px 0">
      <div style="text-align:center;font-size:11px;margin-top:10px">
        Rapor Kapatıldı: ${S.me.name || 'Yetkili'}<br>
        İmza: ____________________
      </div>
    </div>
  `, `Z-Raporu-${z.date}`);
}

function printZReportA4(dateStr){
  const z = getZReportData(dateStr);
  const sec = getActiveSector();
  const shop = S.settings?.shop || sec.name;

  printHTML(`
    <style>
      @page { size: A4 portrait; margin: 15mm; }
      body { font-family: 'Segoe UI', Arial, sans-serif; color: #1e2433; }
      .header { display: flex; justify-content: space-between; border-bottom: 2px solid #14213d; padding-bottom: 10px; margin-bottom: 16px; }
      .box { border: 1px solid #cbd5e1; border-radius: 8px; padding: 12px; margin-bottom: 14px; }
      table { width: 100%; border-collapse: collapse; margin-top: 8px; }
      th, td { padding: 8px; border-bottom: 1px solid #e2e8f0; font-size: 13px; }
      th { background: #14213d; color: #fff; text-align: left; }
      .grand { font-size: 16px; font-weight: 800; background: #f8fafc; }
    </style>
    <div class="header">
      <div>
        <h1 style="margin:0;font-size:22px;color:#14213d">${sec.icon} ${h(shop)}</h1>
        <small>${h(sec.name)} • Adres: ${h(S.settings?.address||'—')} • Tel: ${h(S.settings?.phone||'—')}</small>
      </div>
      <div style="text-align:right">
        <h2 style="margin:0;font-size:18px;color:#f59e0b">GÜN SONU KASA (Z) RAPORU</h2>
        <small>Tarih: <b>${fdate(z.date)}</b> • Basım: ${new Date().toLocaleString('tr-TR')}</small>
      </div>
    </div>
    
    <div class="box">
      <h3 style="margin:0 0 8px;color:#14213d">Kasa ve Nakit Akışı Özeti</h3>
      <table>
        <tr><td>Sabah Kasa Devir Avansı</td><td class="r"><b>${money(z.openingFloat)}</b></td></tr>
        <tr><td>Nakit Satış Toplamı</td><td class="r" style="color:#16a34a">+ ${money(z.nakit)}</td></tr>
        <tr><td>Kredi Kartı / POS Satış Toplamı</td><td class="r">+ ${money(z.kart)}</td></tr>
        <tr><td>Müşteri Veresiye Tahsilatları</td><td class="r" style="color:#16a34a">+ ${money(z.tah)}</td></tr>
        <tr><td>Kasadan Ödenen İşletme Giderleri</td><td class="r" style="color:#dc2626">- ${money(z.totalExp)}</td></tr>
        <tr><td>Dönem İçi Açık Veresiye Satış</td><td class="r">${money(z.ver)}</td></tr>
        <tr class="grand"><td>TOPLAM CİRO (${z.saleCount} Fiş)</td><td class="r"><b>${money(z.totalCiro)}</b></td></tr>
        <tr class="grand" style="background:#14213d;color:#fff"><td style="color:#fff">KASADA BULUNMASI GEREKEN NET NAKİT</td><td class="r" style="color:#4ade80"><b>${money(z.expectedCash)}</b></td></tr>
      </table>
    </div>

    <div class="box">
      <h3 style="margin:0 0 8px;color:#14213d">GİB KDV Dağılımı ve Matrah Tablosu</h3>
      <table>
        <thead>
          <tr>
            <th>KDV Oranı & Grubu</th>
            <th style="text-align:right">KDV Matrahı (Net Satış)</th>
            <th style="text-align:right">Hesaplanan KDV Tutarı</th>
          </tr>
        </thead>
        <tbody>
          ${[1, 10, 20, 0].map(r => `
            <tr>
              <td><b>%${r}</b> - ${KDV_RATES.find(k=>k.rate===r)?.label || 'KDV'} (${KDV_RATES.find(k=>k.rate===r)?.desc || ''})</td>
              <td class="r">${money(z.kdvSummary[r]?.matrah || 0)}</td>
              <td class="r"><b>${money(z.kdvSummary[r]?.kdv || 0)}</b></td>
            </tr>
          `).join('')}
          <tr class="grand">
            <td>TOPLAM</td>
            <td class="r">${money(z.totalMatrah)}</td>
            <td class="r">${money(z.totalKdv)}</td>
          </tr>
        </tbody>
      </table>
    </div>

    <div style="display:flex;justify-content:space-between;margin-top:40px;padding-top:20px;border-top:1px dashed #cbd5e1">
      <div style="text-align:center;width:200px">
        <b>Kasiyer / Hazırlayan</b><br><small>${S.me.name||'Kullanıcı'}</small>
        <div style="margin-top:30px;border-top:1px solid #000">İmza</div>
      </div>
      <div style="text-align:center;width:200px">
        <b>İşletme Yetkilisi</b><br><small>Kontrol & Onay</small>
        <div style="margin-top:30px;border-top:1px solid #000">İmza / Kaşe</div>
      </div>
    </div>
  `, `Z-Raporu-A4-${z.date}`);
}

/* ==========================================================================
   ANA SAYFA (DASHBOARD)
   ========================================================================== */
function pDash(){
  const today=dkey(new Date()),month=today.slice(0,7);
  const live=S.sales.filter(s=>!s.void);
  const td=live.filter(s=>dkey(s.date)===today),mo=live.filter(s=>dkey(s.date).startsWith(month));
  const sum=(a,f)=>round2(a.reduce((x,s)=>x+f(s),0));
  const tdCiro=sum(td,s=>s.total),moCiro=sum(mo,s=>s.total);
  const moProfit=sum(mo,s=>s.total-s.cost);
  const moExp=round2(S.expenses.filter(e=>dkey(e.date).startsWith(month)).reduce((a,e)=>a+e.amount,0));
  const debt=round2(S.customers.reduce((a,c)=>a+balanceOf(c.id),0));
  const stockVal=round2(S.products.reduce((a,p)=>a+p.stock*(p.cost||0),0));
  const low=S.products.filter(isLow),od=overdueList();

  const days=[];for(let i=6;i>=0;i--){const d=new Date();d.setDate(d.getDate()-i);days.push(dkey(d))}
  const vals=days.map(k=>sum(live.filter(s=>dkey(s.date)===k),s=>s.total));const mx=Math.max(...vals,1);
  const cnt={};live.forEach(s=>s.items.forEach(i=>cnt[i.name]=(cnt[i.name]||0)+i.qty*i.price));
  const top=Object.entries(cnt).sort((a,b)=>b[1]-a[1]).slice(0,5);

  $('#view').innerHTML=`
  <div class="grid g4" style="margin-bottom:18px">
   <div class="stat"><small>Bugünkü Satış (${td.length} fiş)</small><b>${money(tdCiro)}</b></div>
   <div class="stat blue"><small>Bu Ayın Cirosu</small><b>${money(moCiro)}</b></div>
   <div class="stat green"><small>Bu Ay Net Kâr (Giderler Düşülmüş)</small><b>${money(moProfit-moExp)}</b></div>
   <div class="stat red"><small>Bu Ayki Giderler</small><b>${money(moExp)}</b></div>
   <div class="stat navy"><small>Piyasadaki Toplam Veresiye Alacak</small><b>${money(debt)}</b></div>
   <div class="stat navy"><small>Depo Değeri (Maliyet)</small><b>${money(stockVal)}</b></div>
   <div class="stat ${low.length?'red':'green'}"><small>Azalan / Biten Ürün</small><b>${low.length}</b></div>
   <div class="stat ${od.length?'red':'green'}"><small>Geciken Veresiye</small><b>${od.length}</b></div>
  </div>
  <div class="grid g2">
   <div class="card"><h3>Son 7 Günlük Satış Grafiği</h3><div class="bars" style="margin-bottom:24px">${vals.map((v,i)=>`<div style="height:${v/mx*100}%" title="${money(v)}"><span>${days[i].slice(8)}</span></div>`).join('')}</div></div>
   <div class="card"><h3>En Çok Ciro Yapan Ürünler</h3>${top.length?`<table>${top.map(t=>`<tr><td>${h(t[0])}</td><td class="r"><b>${money(t[1])}</b></td></tr>`).join('')}</table>`:'<p class="mut">Henüz satış yapılmadı.</p>'}</div>
   <div class="card">
     <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px">
       <h3 style="margin:0">⚠️ Azalan Stok Uyarıları</h3>
       ${low.length?`<button class="btn sm" style="background:#0f766e;color:#fff;padding:4px 9px;font-size:11px" onclick="openSupplierOrderModal()">📋 Sipariş Listesi</button>`:''}
     </div>
     ${low.length?`<table>${low.slice(0,8).map(p=>`<tr><td>${h(p.name)}</td><td class="r"><span class="tag ${p.stock<=0?'t-bad':'t-warn'}">${stockOf(p)}</span></td></tr>`).join('')}</table>`:'<p class="mut">Tüm ürünlerin stokları yeterli seviyede.</p>'}
   </div>
   <div class="card"><h3>⏰ Vadesi Geçen Veresiyeler</h3>${od.length?`<table>${od.slice(0,8).map(o=>`<tr><td>${h(o.c.name)}<br><small class="mut">Fiş #${o.s.no} • ${o.days} gün gecikti</small></td><td class="r bad"><b>${money(o.rem)}</b></td></tr>`).join('')}</table>`:'<p class="mut">Vadesi geçen ödeme bulunmuyor.</p>'}</div>
  </div>
  <div class="bar">
    <button class="btn or lg" onclick="go('pos')">🛒 Kasaya Geç (Satış)</button>
    <button class="btn lg" style="background:#0f766e;color:#fff" onclick="openZReportModal()">📊 Gün Sonu Kasa Raporu (Z)</button>
    <button class="btn lg" onclick="go('products')">📦 Ürün Yönetimi</button>
  </div>`;
}

/* ==========================================================================
   AYARLAR, İŞLETME ADI VE KULLANICILAR
   ========================================================================== */
function pSet(){
  const s=S.settings;
  const lic=S.license;
  const sec=getActiveSector();
  const isProAll = (lic && lic.sector === 'all');
  const licStatusText=lic?.valid ? (lic?.exp ? `Aktif (${lic?.daysLeft} Gün Kaldı)` : 'Aktif (Sınırsız / Ömür Boyu)') : 'Lisanssız / Geçersiz';
  const licColor=lic?.valid ? '#16a34a' : '#dc2626';

  $('#view').innerHTML=`<div class="grid g2">
    <div class="card">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px">
        <h3 style="margin:0">İşletme Bilgileri</h3>
        <span class="tag t-ok" style="font-weight:700">${sec.icon} ${sec.name}</span>
      </div>
      <div class="f">
        <label>İşletme / Dükkan İsmi *</label>
        <input id="s_n" value="${h(s.shop||'İşletme')}" placeholder="Örn: ${sec.name} veya Mağaza Adınız">
        <small class="mut">Bu isim menülerde, fişlerde ve raporlarda anında güncellenir.</small>
      </div>
      <div class="row">
        <div class="f"><label>Telefon</label><input id="s_p" value="${h(s.phone||'')}"></div>
        <div class="f"><label>Adres / Konum</label><input id="s_a" value="${h(s.address||'')}"></div>
      </div>
      <div class="row">
        <div class="f"><label>Veresiye Standart Vade Süresi (Gün)</label><input id="s_c" type="number" value="${s.creditDays||15}"></div>
        <div class="f"><label>Varsayılan Minimum Stok Uyarısı</label><input id="s_m" type="number" value="${s.defMin||5}"></div>
      </div>
      <div style="display:flex;gap:8px;margin-top:10px;flex-wrap:wrap">
        <button class="btn or" onclick="saveSet()">Kaydet ve Uygula</button>
        <button class="btn ln sm" type="button" onclick="loadSampleCategories()">✨ ${sec.name} Örnek Kategorileri Ekle</button>
      </div>
    </div>

    <div class="card">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px">
        <h3 style="margin:0">🛡️ Lisans ve Sektör Uyumluluğu</h3>
        <button class="btn sm or" onclick="showLicenseModal()">Lisans Değiştir</button>
      </div>
      <div class="row">
        <div class="f"><label>Cihaz Donanım Kimliği (Machine ID)</label><input readonly value="${h(lic?.mid||'-')}" style="font-family:monospace;font-weight:700"></div>
        <div class="f"><label>Lisans Durumu</label><input readonly value="${licStatusText}" style="font-weight:800;color:${licColor}"></div>
      </div>
      <div class="row">
        <div class="f"><label>Kayıtlı Müşteri / İşletme</label><input readonly value="${h(lic?.client||'Belirtilmemiş')}"></div>
        <div class="f"><label>Lisanslı Sektör</label><input readonly value="${sec.icon} ${sec.name}" style="font-weight:800;color:var(--navy)"></div>
      </div>

      ${isProAll ? `
        <div style="margin-top:8px;padding:10px;background:#f5f3ff;border:1px solid #ddd6fe;border-radius:10px">
          <label style="color:#6d28d9;font-weight:800;font-size:12px;display:block;margin-bottom:4px">👑 AKTİF SEKTÖR GÖRÜNÜMÜNÜ DEĞİŞTİR (ULTRA PRO LİSANS):</label>
          <select id="s_sec_select" onchange="switchSectorView(this.value)" style="width:100%;font-weight:700">
            ${Object.values(SECTORS).map(sc=>`<option value="${sc.id}" ${getActiveSectorKey()===sc.id?'selected':''}>${sc.icon} ${sc.name}</option>`).join('')}
          </select>
          <small style="color:#5b21b6;font-size:11px;display:block;margin-top:4px">İstediğiniz zaman tek tıkla sektör değiştirip arayüzü ve birimleri dönüştürebilirsiniz.</small>
        </div>
      ` : ''}

      <div style="margin-top:10px;padding:10px;background:#f0fdf4;border:1px solid #bbf7d0;border-radius:10px;display:flex;justify-content:space-between;align-items:center">
        <div>
          <span style="display:block;font-size:12px;font-weight:700;color:#166534">Lisans Satın Alma / Sektör Değiştirme Hattı:</span>
          <b style="font-size:14px;color:#065f46">0506 110 45 63</b>
        </div>
        <a href="https://wa.me/905061104563?text=${encodeURIComponent(`Merhaba, ${sec.name} Lisansım için yazıyorum. Donanım Kimliğim: ${lic?.mid||''}`)}" target="_blank" class="btn sm ok" style="text-decoration:none;font-weight:700">
          💬 WhatsApp ile Yaz
        </a>
      </div>
    </div>

    <div class="card">
      <h3>Kullanıcı Hesapları <button class="btn or sm" style="float:right" onclick="userForm()">+ Yeni Kullanıcı</button></h3>
      <table>
        ${S.users.map(u=>`<tr>
          <td><b>${h(u.name)}</b></td>
          <td><span class="tag ${u.role==='admin'?'t-blue':'t-gray'}">${u.role==='admin'?'Yönetici':'Kasiyer'}</span></td>
          <td class="r">
            <button class="btn sm ln" onclick="userForm('${u.id}')">Düzenle</button>
            ${u.id!==S.me.id?`<button class="btn sm rd" onclick="userDel('${u.id}')">Sil</button>`:''}
          </td>
        </tr>`).join('')}
      </table>
      <p class="mut" style="font-size:12px;margin-top:8px">Kasiyer yetkisindeki kullanıcılar satış yapabilir, müşteri ekleyebilir ve tahsilat yapabilir; ancak maliyet, kâr ve gider sayfalarını göremez.</p>
    </div>

    <div class="card">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px">
        <h3 style="margin:0">🚀 Sistem & Otomatik Güncelleme (GitHub)</h3>
        <span class="tag t-ok" style="font-weight:700">v2.1.0</span>
      </div>
      <div style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:10px;padding:12px;margin-bottom:12px">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px">
          <span style="font-size:12px;color:#64748b;font-weight:700">Bağlı GitHub Deposu:</span>
          <a href="https://github.com/mehmetsinangunay/msg-yazilim" target="_blank" style="font-size:12px;font-weight:700;color:#2563eb;text-decoration:none">
            mehmetsinangunay/msg-yazilim ↗
          </a>
        </div>
        <p style="margin:0;font-size:12px;color:#475569;line-height:1.4">
          Müşterileriniz yeni bir özellik çıktığında hiçbir şey silinmeden tek tıkla en son sürüme güncellenir.
        </p>
      </div>

      <div style="display:flex;gap:8px;flex-wrap:wrap">
        <button class="btn ok sm" onclick="checkSystemUpdate(true)" style="background:#16a34a;color:#fff;font-weight:700;padding:8px 14px">
          🔄 Güncellemeleri Denetle
        </button>
        <label class="btn ln sm" style="margin:0;cursor:pointer;font-weight:600">
          📂 Manuel Güncelleme Paketi Yükle (.zip)
          <input type="file" accept=".zip" hidden onchange="uploadManualUpdateZip(this)">
        </label>
      </div>
    </div>

    <div class="card">
      <h3>Veri Yedekleme ve Kurtarma</h3>
      <div style="background:#eff6ff;border:1px solid #bfdbfe;border-radius:10px;padding:12px;margin-bottom:12px">
        <b style="color:#1e40af;font-size:13px;display:block;margin-bottom:4px">🛡️ Otomatik Korumalı Yedekleme (C:\\MSG_Yazilim_Yedekleri)</b>
        <p style="margin:0;font-size:12px;color:#475569;line-height:1.4">
          Sistem her açıldığında ve kapandığında otomatik olarak bilgisayarınızdaki güvenli <b>C:\\MSG_Yazilim_Yedekleri</b> klasörüne tam yedek alır. <u>Programı silseniz bile bu yedekler silinmez</u>.
        </p>
        <button class="btn sm ok" style="margin-top:10px;width:100%;font-weight:700" onclick="restoreExternalBackup()">
          📥 Güvenli Klasörden Son Yedeği Yükle
        </button>
      </div>

      <p class="mut" style="font-size:12px">Manuel olarak da bilgisayarınıza dosya indirebilir veya dosya yükleyebilirsiniz:</p>
      <div class="bar">
        <button class="btn" onclick="exportData()">💾 Yedeği İndir (JSON)</button>
        <label class="btn ln" style="margin:0;cursor:pointer">📂 Manuel Yedek Dosyası Yükle<input type="file" accept=".json" hidden onchange="importData(this)"></label>
      </div>
      <hr>
      <button class="btn rd" onclick="wipe()">⚠️ Tüm Verileri Sıfırla (Temizle)</button>
    </div>

    <div class="card">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px">
        <h3 style="margin:0">⚖️ Donanım & Çevre Birimleri (Terazi & POS)</h3>
        <span class="tag t-blue" style="font-weight:700">Canlı Entegrasyon</span>
      </div>
      
      <!-- Kasa Terazisi Ayarları -->
      <div style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:10px;padding:12px;margin-bottom:12px">
        <b style="color:var(--navy);font-size:13px;display:flex;align-items:center;gap:6px">
          ⚖️ Canlı Kasa Terazisi (RS232 / USB)
        </b>
        <p style="margin:4px 0 8px;font-size:12px;color:#64748b">
          Ürün tartıldığında gramaj otomatik kasaya aktarılır.
        </p>
        <div style="display:flex;gap:8px;align-items:center">
          <button class="btn sm" style="background:#0284c7;color:#fff;font-weight:700" onclick="toggleScaleSettingsModal()">
            ⚙️ Terazi Ayarları & Test Et
          </button>
          <span style="font-size:12px;color:${liveScaleConnected?'#16a34a':'#64748b'};font-weight:700">
            ${liveScaleConnected ? '🟢 Terazi Bağlı (' + num(liveScaleWeight) + ' KG)' : '⚪ Bağlı Değil'}
          </span>
        </div>
      </div>

      <!-- POS Cihazı Ayarları -->
      <div style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:10px;padding:12px">
        <b style="color:var(--navy);font-size:13px;display:flex;align-items:center;gap:6px">
          💳 Akıllı Banka / ÖKC POS Cihazı (GMP-3)
        </b>
        <p style="margin:4px 0 8px;font-size:12px;color:#64748b">
          Kredi kartı satışlarında tutar POS cihazına otomatik gönderilir.
        </p>
        <div class="row">
          <div class="f">
            <label style="font-size:11px">POS Cihaz Modeli</label>
            <select id="set_pos_device" onchange="localStorage.setItem('msg_pos_device', this.value)">
              <option value="Hugin / Beko / Ingenico (GMP-3)">Hugin / Beko / Ingenico (GMP-3)</option>
              <option value="Vera / Profilo ÖKC">Vera / Profilo ÖKC</option>
              <option value="Banka EFT-POS Terminali">Banka EFT-POS Terminali</option>
            </select>
          </div>
          <div class="f">
            <label style="font-size:11px">Otomatik Aktarım</label>
            <select id="set_pos_prompt" onchange="localStorage.setItem('msg_pos_auto_prompt', this.value)">
              <option value="enabled">Aktif (Satışta Ekrana Getir)</option>
              <option value="disabled">Devre Dışı (Yalnızca Manuel)</option>
            </select>
          </div>
        </div>
      </div>
    </div>

    <div class="card">
      <h3>📱 Telefon / Tablet Kurulumu (Canlı Kameralı Barkod Okuyucu)</h3>
      <ol style="line-height:1.7;padding-left:20px;margin:0 0 10px">
        <li>Telefonunuzu iş yerindeki <b>aynı Wi-Fi</b> ağına bağlayın.</li>
        <li>Aşağıdaki <b>"Karekod (QR Kod) Göster"</b> butonuna basıp ekrandaki karekodu telefonunuzun kamerasıyla okutun.</li>
        <li>Veya telefonun Chrome / Safari tarayıcısına şunu yazın:<br>
          <b style="font-size:16px;color:var(--navy)">https://${location.hostname}:3443</b>
        </li>
        <li>İlk girişte çıkan yerel ağ ekranında <b>Gelişmiş → İlerle (güvensiz)</b> seçeneğine dokunun (tek seferliktir, Chrome bunu hatırlar ve bir daha sormaz).</li>
        <li>Açılan sayfada <b>"Uygulamayı Yükle"</b> veya tarayıcı menüsünden <b>"Ana Ekrana Ekle"</b> diyerek telefonunuza uygulama olarak ekleyin. Canlı video kamera ile market kasası gibi seri barkod okutabilirsiniz!</li>
      </ol>
      <div class="bar">
        <button class="btn or" onclick="installAppModal()">📲 Karekod (QR Kod) Göster & Telefona Yükle</button>
      </div>
    </div>
  </div>`;
}

async function switchSectorView(newSectorKey){
  if(await cmd('settings',{data:{
    ...S.settings,
    activeSector: newSectorKey
  }})){
    S.settings.activeSector = newSectorKey;
    updateShopBranding();
    toast(`Sektör görünümü "${SECTORS[newSectorKey]?.name}" olarak güncellendi!`,'ok');
    pSet();
  }
}

async function loadSampleCategories(){
  const sec = getActiveSector();
  if(!sec.sampleCats || !sec.sampleCats.length){
    toast('Bu sektör için tanımlı örnek kategori bulunamadı.','err');
    return;
  }
  if(confirm(`"${sec.name}" sektörüne ait temel kategoriler (${sec.sampleCats.join(', ')}) eklensin mi?`)){
    let addedCount = 0;
    for(const catName of sec.sampleCats){
      const exists = S.products.some(p => p.category === catName);
      if(!exists){
        // Kategori listesinde görünmesi için o kategoriye ait bir şablon ürün taslağı açalım
        await cmd('prodSave', {
          id: null,
          data: {
            name: `${catName} (Örnek Ürün)`,
            barcode: genBarcode(),
            category: catName,
            unit: sec.defaultUnit || 'adet',
            cost: 0,
            price: 0,
            stock: 0,
            min: 5
          }
        });
        addedCount++;
      }
    }
    toast(`Tebrikler! ${sec.name} sektörüne ait ${sec.sampleCats.length} örnek kategori sisteme eklendi.`,'ok');
    route();
  }
}

async function saveSet(){
  const shopName=$('#s_n').value.trim()||'MSG YAZILIM';
  if(await cmd('settings',{data:{
    shop:shopName,
    phone:$('#s_p').value,
    address:$('#s_a').value,
    creditDays:$('#s_c').value,
    defMin:$('#s_m').value
  }})){
    S.settings.shop=shopName;
    updateShopBranding();
    toast('İşletme ayarları güncellendi','ok');
  }
}

function userForm(id){
  const u=id?S.users.find(x=>x.id===id):{name:'',role:'cashier'};
  modal(`<h2>${id?'Kullanıcıyı Düzenle':'Yeni Kullanıcı'}</h2>
  <div class="f"><label>Kullanıcı Adı</label><input id="u_n" value="${h(u.name)}"></div>
  <div class="row">
    <div class="f"><label>Yetki</label><select id="u_r"><option value="cashier" ${u.role==='cashier'?'selected':''}>Kasiyer</option><option value="admin" ${u.role==='admin'?'selected':''}>Yönetici</option></select></div>
    <div class="f"><label>PIN (4-8 Rakam)${id?' — boşsa değişmez':''}</label><input id="u_p" type="password" inputmode="numeric" maxlength="8"></div>
  </div>
  <div class="mfoot"><button class="btn ln" onclick="closeModal()">İptal</button><button class="btn or" onclick="saveUser('${id||''}')">Kaydet</button></div>`);
}

async function saveUser(id){
  if(await cmd('userSave',{id:id||null,data:{name:$('#u_n').value,role:$('#u_r').value,pin:$('#u_p').value}})){
    closeModal();route();
  }
}
async function userDel(id){
  if(confirm('Bu kullanıcı silinsin mi?')){await cmd('userDel',{id});route()}
}

async function exportData(){
  const r=await fetch('/api/backup',{headers:{'X-Token':TOKEN}});
  const b=await r.blob();
  const a=document.createElement('a');
  a.href=URL.createObjectURL(b);
  a.download=`msg-yedek-${dkey(new Date())}.json`;
  a.click();
}

function importData(i){
  const f=i.files[0];if(!f)return;
  const r=new FileReader();
  r.onload=async()=>{
    try{
      const d=JSON.parse(r.result);
      if(!d.products)throw 0;
      if(!confirm('Mevcut sistemdeki veriler yedekteki verilerle DEĞİŞTİRİLECEK. Devam edilsin mi?'))return;
      if(await cmd('import',{state:d})){toast('Yedek başarıyla yüklendi','ok');route()}
    }catch(e){toast('Geçersiz yedek dosyası','err')}
  };
  r.readAsText(f);
}

async function wipe(){
  if(confirm('TÜM ürünler, satışlar ve cari kayıtlar silinecek! Emin misiniz?')&&confirm('Bu işlem GERİ ALINAMAZ. Gerçekten sıfırlansın mı?')){
    await cmd('wipe');route();
  }
}

/* ==========================================================================
   PWA & MOBİL UYGULAMA KURULUM DESTEĞİ
   ========================================================================== */
let installEv = null;

function isPWA() {
  return window.matchMedia('(display-mode: standalone)').matches ||
         window.navigator.standalone === true ||
         document.referrer.includes('android-app://');
}

function isMobileDevice() {
  return /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent) || window.innerWidth <= 820;
}

function isIOS() {
  return /iPad|iPhone|iPod/.test(navigator.userAgent) && !window.MSStream;
}

window.addEventListener('beforeinstallprompt', e => {
  e.preventDefault();
  installEv = e;
  renderPWABanner();
  const btn = $('#pwaHeaderBtn');
  if (btn && !isPWA()) btn.style.display = 'inline-flex';
});

window.addEventListener('appinstalled', () => {
  installEv = null;
  const shopName = S.settings?.shop || 'MSG YAZILIM';
  toast(`🎉 ${shopName} başarıyla telefonunuza yüklendi!`, 'ok');
  dismissPWABanner(true);
  const btn = $('#pwaHeaderBtn');
  if (btn) btn.style.display = 'none';
});

function renderPWABanner() {
  if (isPWA()) return; // Zaten uygulama olarak çalışıyorsa gösterme
  const dismissed = localStorage.getItem('hrd_pwa_dismissed');
  if (dismissed && Date.now() - Number(dismissed) < 86400000) return; // 24 saat içinde kapatıldıysa gösterme
  if ($('#pwaBanner')) return;

  const shopName = S.settings?.shop || 'MSG YAZILIM';
  const div = document.createElement('div');
  div.id = 'pwaBanner';
  div.className = 'pwa-banner';
  div.innerHTML = `
    <div class="pwa-icon"><img src="/icon-192.png" alt="${h(shopName)}"></div>
    <div class="pwa-info">
      <b>${h(shopName)}'ı Yükle</b>
      <small>Telefonunuza uygulama olarak ekleyin, tek tıkla açın</small>
    </div>
    <div class="pwa-actions">
      <button class="btn sm or" onclick="triggerPWAInstall()">Yükle</button>
      <button class="pwa-close" onclick="dismissPWABanner()">✕</button>
    </div>
  `;
  document.body.appendChild(div);
}

function dismissPWABanner(permanent=false) {
  const b = $('#pwaBanner');
  if (b) b.remove();
  localStorage.setItem('hrd_pwa_dismissed', permanent ? String(Date.now() + 31536000000) : String(Date.now()));
}

async function triggerPWAInstall() {
  if (installEv) {
    installEv.prompt();
    const choice = await installEv.userChoice;
    if (choice && choice.outcome === 'accepted') {
      toast('Uygulama telefonunuza yükleniyor... 🎉', 'ok');
      dismissPWABanner(true);
    }
    installEv = null;
  } else {
    installAppModal();
  }
}

function getMobileNetworkUrl() {
  const lanIp = S.network?.ips?.[0] || (location.hostname !== 'localhost' && location.hostname !== '127.0.0.1' ? location.hostname : '192.168.1.102');
  return `https://${lanIp}:${S.network?.httpsPort || 3443}`;
}

async function installAppModal() {
  const targetUrl = getMobileNetworkUrl();
  const installed = isPWA();
  const ios = isIOS();
  const shopName = S.settings?.shop || 'MSG YAZILIM';

  modal(`
    <div style="text-align:center;padding:6px 2px">
      <div style="font-size:42px;margin-bottom:6px">📲</div>
      <h2 style="margin:0 0 6px">${h(shopName)} Mobil Barkod Terminali</h2>
      <p class="mut" style="margin:0 0 16px;font-size:13px">
        Telefonunuzu market el terminali gibi kullanın. Canlı video kamera ile seri barkod okutun ve satış yapın.
      </p>

      ${installed ? `
        <div style="background:#dcfce7;border:1px solid #16a34a;color:#166534;border-radius:12px;padding:12px;margin-bottom:16px;font-weight:700">
          ✅ Bu cihazda uygulama zaten ana ekrana yüklenmiş olarak çalışıyor!
        </div>
      ` : installEv ? `
        <div style="margin-bottom:16px">
          <button class="btn or lg" onclick="triggerPWAInstall()" style="width:100%;padding:14px;font-size:16px;font-weight:700;border-radius:12px;box-shadow:0 4px 12px rgba(252,163,17,0.4)">
            ⚡ TEK TIKLA TELEFONA YÜKLE
          </button>
        </div>
      ` : ''}

      <div class="qr-container">
        <b style="font-size:15px;color:var(--navy);display:block;margin-bottom:6px">📸 Canlı Kameralı Giriş İçin Karekodu (QR) Okutun</b>
        <p class="mut" style="font-size:12px;margin:0 0 10px">Telefonunuzun normal kamerasını aşağıdaki karekoda tutun:</p>
        <div id="installQrBox" style="display:inline-block;padding:8px;background:#fff;border-radius:12px;box-shadow:0 2px 8px #0002;margin-bottom:8px">
          <canvas id="installQrCanvas" width="180" height="180" style="display:block;margin:auto"></canvas>
        </div>
        <div style="display:flex;gap:8px;max-width:360px;margin:auto">
          <input id="shareUrlInput" value="${targetUrl}" readonly style="font-size:12px;text-align:center;padding:8px;border-radius:8px;border:1px solid var(--line);background:#f8fafc;flex:1">
          <button class="btn sm or" onclick="copyShareUrl()" style="white-space:nowrap;padding:8px 12px">📋 Kopyala</button>
        </div>
        
        <div style="background:#fff7ed;border:1px solid #fed7aa;border-radius:10px;padding:10px;margin:12px auto 0;max-width:380px;text-align:left;font-size:12px;color:#9a3412">
          <b>💡 İlk Giriş Onayı (Tek Seferlik):</b><br>
          İlk açılışta çıkan ekranda <b>Gelişmiş → İlerle (güvensiz)</b> butonuna dokunun. Chrome bunu o telefon için kalıcı olarak hatırlar ve bir daha sormaz; canlı kamera seri okuma yapar!
        </div>
      </div>

      <div class="install-tabs" style="margin-top:16px">
        <div class="install-card" style="${!ios ? 'border-color:var(--orange);background:#fffaf0;' : ''}">
          <h4>🤖 Android Telefonlar İçin</h4>
          <ol>
            <li>Tarayıcının sağ üstündeki <b>⋮ (Üç Nokta)</b> menüsüne dokunun.</li>
            <li>Menüdeki <b>"Ana Ekrana Ekle"</b> veya <b>"Kısayol Ekle"</b> seçeneğine dokunun.</li>
            <li>Çıkan ekranda <b>"Ekle"</b> deyin. Logonuzla birlikte ana ekrana yerleşir!</li>
          </ol>
        </div>

        <div class="install-card" style="${ios ? 'border-color:var(--orange);background:#fffaf0;' : ''}">
          <h4>🍎 iPhone & iPad (Safari) İçin</h4>
          <ol>
            <li>Safari'de açtıktan sonra alttaki <b>Paylaş (⎙ / ⬆)</b> simgesine dokunun.</li>
            <li>Menüyü aşağı kaydırıp <b>"Ana Ekrana Ekle" (➕)</b> seçeneğine dokunun.</li>
            <li>Sağ üstteki <b>"Ekle"</b> butonuna basın. Ana ekrana yerleşir!</li>
          </ol>
        </div>
      </div>

      <div class="mfoot" style="margin-top:16px">
        <button class="btn ln" onclick="closeModal()">Kapat</button>
      </div>
    </div>
  `, true);

  // QR kodu çiz
  setTimeout(() => renderQRToTarget('#installQrCanvas', targetUrl), 50);
}

async function renderQRToTarget(canvasSelector, text) {
  const canvas = $(canvasSelector);
  if (!canvas) return;
  try {
    if (typeof ZXing === 'undefined') {
      await new Promise((res, rej) => {
        const s = document.createElement('script');
        s.src = '/zxing.min.js';
        s.onload = res;
        s.onerror = rej;
        document.head.appendChild(s);
      });
    }
    const w = new ZXing.QRCodeWriter();
    const m = w.encode(text, ZXing.BarcodeFormat.QR_CODE, 180, 180, new Map());
    const size = 180;
    canvas.width = size;
    canvas.height = size;
    const ctx = canvas.getContext('2d');
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, size, size);
    ctx.fillStyle = '#14213d';
    const pw = size / m.getWidth();
    const ph = size / m.getHeight();
    for (let y = 0; y < m.getHeight(); y++) {
      for (let x = 0; x < m.getWidth(); x++) {
        if (m.get(x, y)) {
          ctx.fillRect(Math.floor(x * pw), Math.floor(y * ph), Math.ceil(pw), Math.ceil(ph));
        }
      }
    }
  } catch (e) {
    console.warn('QR oluşturulamadı:', e);
  }
}

function copyShareUrl() {
  const el = $('#shareUrlInput');
  if (el) {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(el.value).then(() => toast('Bağlantı kopyalandı! 📋', 'ok')).catch(() => {
        el.select();
        document.execCommand('copy');
        toast('Bağlantı kopyalandı! 📋', 'ok');
      });
    } else {
      el.select();
      document.execCommand('copy');
      toast('Bağlantı kopyalandı! 📋', 'ok');
    }
  }
}

/* ==========================================================================
   OTOMATİK VE MANUEL GÜNCELLEME İŞLEMLERİ (GITHUB AUTO-UPDATE)
   ========================================================================== */
let updateCheckResult = null;

async function checkSystemUpdate(showModalIfNoUpdate = true) {
  try {
    const res = await api('/api/update/check');
    updateCheckResult = res;
    if (res && res.hasUpdate && res.remote) {
      showUpdateAvailableModal(res);
      const licBadge = document.getElementById('licBadge');
      if (licBadge) {
        licBadge.style.display = 'inline-block';
        licBadge.className = 'tag t-warn';
        licBadge.style.cursor = 'pointer';
        licBadge.innerHTML = `🚀 Güncelleme: v${res.remote.version}`;
        licBadge.onclick = () => showUpdateAvailableModal(res);
      }
    } else {
      if (showModalIfNoUpdate) {
        toast(`✅ MSG Yazılım güncel! En son sürümü kullanıyorsunuz (v${res.currentVersion || '2.1.0'}).`, 'ok');
      }
    }
  } catch(err) {
    if (showModalIfNoUpdate) {
      toast('Güncelleme sunucusuna ulaşılamadı. İnternet bağlantınızı kontrol edin.', 'err');
    }
  }
}

function showUpdateAvailableModal(info) {
  const rem = info.remote || {};
  modal(`
    <div style="text-align:center;padding:10px 4px">
      <div style="font-size:52px;margin-bottom:8px">🚀</div>
      <h2 style="margin:0 0 6px;color:var(--navy)">Yeni MSG Yazılım Güncellemesi Mevcut!</h2>
      <div style="display:inline-block;background:#dbeafe;color:#1e40af;font-weight:800;padding:5px 14px;border-radius:20px;font-size:13px;margin-bottom:14px">
        Yeni Sürüm: v${h(rem.version)} • Mevcut Sürüm: v${h(info.currentVersion)}
      </div>

      <div style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:12px;padding:14px;text-align:left;margin-bottom:16px">
        <b style="color:#0f172a;font-size:14px;display:block;margin-bottom:6px">📌 Bu Güncellemedeki Yenilikler:</b>
        <div style="color:#334155;font-size:13px;line-height:1.5;white-space:pre-wrap;background:#fff;padding:10px;border-radius:8px;border:1px solid #f1f5f9">${h(rem.notes || rem.title || 'Performans iyileştirmeleri ve yeni özellikler.')}</div>
      </div>

      <div style="background:#f0fdf4;border:1px solid #bbf7d0;border-radius:10px;padding:10px;font-size:12px;color:#166534;margin-bottom:18px;text-align:left">
        🛡️ <b>Veri Güvenliği Garantisi:</b> Güncelleme öncesi otomatik güvenlik yedeği alınır. Mevcut stoklarınız, müşteri ve veresiye kayıtlarınız kesinlikle etkilenmez.
      </div>

      <div style="display:flex;gap:10px;flex-wrap:wrap">
        <button class="btn ok lg" style="flex:1;background:#16a34a;color:#fff;font-weight:800;padding:14px" onclick="applySystemUpdate('${h(rem.downloadUrl)}')">
          ⚡ Şimdi Güncelle (Tek Tıkla)
        </button>
        <button class="btn ln" onclick="closeModal()">Daha Sonra</button>
      </div>
    </div>
  `, true);
}

async function applySystemUpdate(downloadUrl) {
  if (!downloadUrl) {
    toast('İndirme bağlantısı bulunamadı', 'err');
    return;
  }
  modal(`
    <div style="text-align:center;padding:24px 10px">
      <div style="font-size:52px;animation:spin 2s linear infinite;display:inline-block;margin-bottom:12px">⚙️</div>
      <h3 style="margin:0 0 8px">Güncelleme Yükleniyor...</h3>
      <p style="color:#64748b;font-size:14px;margin-bottom:16px">
        Güvenlik yedeği alınıyor ve yeni sürüm dosyaları kuruluyor. Lütfen bekleyin...
      </p>
      <div style="height:8px;background:#e2e8f0;border-radius:4px;overflow:hidden;max-width:300px;margin:auto">
        <div style="height:100%;width:70%;background:#16a34a;animation:pulse 1.5s infinite"></div>
      </div>
    </div>
  `, true);

  try {
    const res = await api('/api/update/apply', { downloadUrl });
    if (res && res.ok) {
      modal(`
        <div style="text-align:center;padding:24px 10px">
          <div style="font-size:52px;margin-bottom:12px">🎉</div>
          <h2 style="margin:0 0 8px;color:#16a34a">Güncelleme Başarıyla Tamamlandı!</h2>
          <p style="color:#475569;font-size:14px">
            Sistem yenilendi. 3 saniye içinde sayfa otomatik olarak yeniden açılacaktır...
          </p>
        </div>
      `, true);
      setTimeout(() => {
        location.reload(true);
      }, 3000);
    } else {
      toast(res.error || 'Güncelleme uygulanamadı', 'err');
    }
  } catch(err) {
    toast('Güncelleme sırasında bir hata oluştu: ' + (err.message || err), 'err');
  }
}

async function uploadManualUpdateZip(fileInput) {
  const file = fileInput.files && fileInput.files[0];
  if (!file) return;
  if (!file.name.endsWith('.zip')) {
    toast('Lütfen geçerli bir .zip güncelleme paketi seçin', 'err');
    return;
  }
  if (!confirm(`"${file.name}" güncelleme paketi yüklenecek. Onaylıyor musunuz?`)) return;

  const reader = new FileReader();
  reader.onload = async () => {
    const b64 = reader.result.split(',')[1];
    modal(`
      <div style="text-align:center;padding:24px 10px">
        <div style="font-size:52px;animation:spin 2s linear infinite;display:inline-block;margin-bottom:12px">⚙️</div>
        <h3 style="margin:0 0 8px">Manuel Güncelleme Paketi Kuruluyor...</h3>
        <p style="color:#64748b;font-size:14px">Dosyalar açılıyor, lütfen bekleyin...</p>
      </div>
    `, true);
    try {
      const res = await api('/api/update/upload', { zipBase64: b64 });
      if (res && res.ok) {
        modal(`
          <div style="text-align:center;padding:24px 10px">
            <div style="font-size:52px;margin-bottom:12px">🎉</div>
            <h2 style="margin:0 0 8px;color:#16a34a">Manuel Paket Başarıyla Kuruldu!</h2>
            <p style="color:#475569;font-size:14px">Sistem 3 saniye içinde yeniden başlatılıyor...</p>
          </div>
        `, true);
        setTimeout(() => location.reload(true), 3000);
      } else {
        toast(res.error || 'Paket yüklenemedi', 'err');
      }
    } catch(err) {
      toast('Hata: ' + (err.message || err), 'err');
    }
  };
  reader.readAsDataURL(file);
}

/* ---------- Başlatma ---------- */
async function boot(retries = 0){
  try{
    const st = await api('/api/state');
    if (!st || st.error) {
      if (st && (st.error === 'Oturum yok' || st.error === 'auth')) {
        sessionStorage.removeItem('msg_token');
        sessionStorage.removeItem('hrd_token');
        TOKEN = null;
        showLogin();
        return;
      }
      throw new Error(st?.error || 'Sunucu yanıtı geçersiz');
    }
    S.v = 0;
    applyState(st);
  }catch(e){
    console.warn('Sistem başlatma denemesi:', e.message);
    if (e.message === 'auth') return;
    if (retries < 6) {
      // Sunucu güncelleme veya yeniden başlatma anında olabilir; tekrar dene
      setTimeout(() => boot(retries + 1), 1200);
      return;
    }
    showLogin();
    return;
  }

  connectSSE();
  route();
  updateShopBranding();

  // Mobil yükleme banner'ı
  setTimeout(renderPWABanner, 1200);

  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('/sw.js').catch(err => console.log('SW bilgi:', err));
  }

  if (isPWA()) {
    const btn = $('#pwaHeaderBtn');
    if (btn) btn.style.display = 'none';
  }

  if(S.me.defaultPin){
    setTimeout(()=>toast('⚠️ Varsayılan PIN (1234) kullanılıyor. Sağ üstteki kullanıcı menüsünden değiştirin.','err'),800);
  }
  setInterval(updBadge,60000);
  const n=notifications();
  if(n.length) setTimeout(()=>toast(`🔔 ${n.length} bildiriminiz var (azalan stok / geciken ödeme)`),600);

  // Arka planda sessiz güncelleme kontrolü
  setTimeout(() => {
    if (isAdmin()) checkSystemUpdate(false);
  }, 4000);
}

if(TOKEN)boot();else showLogin();

