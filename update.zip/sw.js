/* Hırdavat Sistemi - Service Worker (PWA Desteği ve Çevrimdışı Önbellek) */
const CACHE_NAME = 'hirdavat-pwa-v1';
const APP_SHELL = [
  '/',
  '/index.html',
  '/style.css?v=2',
  '/app.js',
  '/manifest.json',
  '/icon-192.png',
  '/icon-512.png',
  '/html5-qrcode.min.js'
];

self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME).then(cache => {
      return cache.addAll(APP_SHELL).catch(err => {
        console.warn('Önbellek kurulumu uyarısı:', err);
      });
    })
  );
  self.skipWaiting();
});

self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(keys => {
      return Promise.all(
        keys.filter(k => k !== CACHE_NAME).map(k => caches.delete(k))
      );
    }).then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', event => {
  const url = new URL(event.request.url);

  // API istekleri veya dinamik görselleri önbelleğe alma (her zaman sunucudan çek)
  if (event.request.method !== 'GET' || url.pathname.startsWith('/api/') || url.pathname.startsWith('/img/')) {
    return;
  }

  // Network-first ile taze sürümü al, ağ yoksa veya gecikirse önbellekten dön
  event.respondWith(
    fetch(event.request)
      .then(response => {
        if (response && response.status === 200) {
          const resClone = response.clone();
          caches.open(CACHE_NAME).then(cache => cache.put(event.request, resClone));
        }
        return response;
      })
      .catch(() => {
        return caches.match(event.request).then(cached => {
          return cached || (url.pathname === '/' ? caches.match('/index.html') : null);
        });
      })
  );
});
