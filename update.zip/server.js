/* Hırdavat Yönetim ve Satış Sistemi - Güvenli Ağ Sunucusu */
'use strict';
process.on('uncaughtException', err => console.error('UNCAUGHT EXCEPTION:', err));
process.on('unhandledRejection', err => console.error('UNHANDLED REJECTION:', err));

const https = require('https'), { execFileSync } = require('child_process'), http = require('http'), fs = require('fs'), path = require('path'), os = require('os'), crypto = require('crypto');
const PORT = +process.env.PORT || 3000;
const HPORT = +process.env.HTTPS_PORT || 3443;
const ROOT = __dirname, DATA = path.join(ROOT, 'data'), IMG = path.join(DATA, 'img'), BK = path.join(DATA, 'backups'), DBF = path.join(DATA, 'db.json'), LIC_FILE = path.join(DATA, 'license.lic');
const PROTECTED_BK = 'C:\\MSG_Yazilim_Yedekleri';
const LEGACY_BK = 'C:\\Hirdavat_Yedekleri';

[DATA, IMG, BK, PROTECTED_BK, LEGACY_BK].forEach(d => { try { fs.mkdirSync(d, { recursive: true }); } catch(_) {} });

const round2 = n => Math.round((n + Number.EPSILON) * 100) / 100;
const round3 = n => Math.round((n + Number.EPSILON) * 1000) / 1000;
const uid = () => Date.now().toString(36) + crypto.randomBytes(3).toString('hex');
const num = v => { const n = Number(v); return isFinite(n) ? n : 0 };

/* ---------- GÖMÜLÜ RSA PUBLIC KEY (SADECE DOĞRULAMA YAPAR, LİSANS ÜRETEMEZ) ---------- */
const PUBLIC_KEY_PEM = `-----BEGIN RSA PUBLIC KEY-----
MIIBCgKCAQEA032SMwBvcINfdT+kMO34bf7WIN4Bev4r1VsvKISeGo/i2B52qALG
+mwx81ve0PO2N+xePTRYdlFV1NJyDNTXhsEpMz4B/861f49mlqbxjfyIRSGLrvMX
wOY4xv2SKILRZRNHngYHz9zx6yflQLAgqH0py0JXMlMQUJ949My5JRMV5HfHbe/z
aYwPBHMwVGdFA5vX+OHOW+8oSZnT76VTk3bn7eMSxNTKhTp2ij+VGvfn66GE/+Kk
Lt/WM07An4KDapGdB89ZNsYXpl2CqHch4VJ9DnIbASFpgjPlPEkZi+8Fo8jaAzfW
vsE87V0qoTAW2PX7dPooUg2LIN1fQrBRUQIDAQAB
-----END RSA PUBLIC KEY-----`;

/* ---------- DONANIM KİMLİĞİ (MACHINE ID) ---------- */
let cachedMachineId = null;
function getMachineId() {
  if (cachedMachineId) return cachedMachineId;
  let raw = '';
  try {
    const out = require('child_process').execSync('reg query HKLM\\SOFTWARE\\Microsoft\\Cryptography /v MachineGuid', { timeout: 2000 }).toString();
    const m = out.match(/MachineGuid\s+REG_SZ\s+([^\r\n]+)/i);
    if (m) raw = m[1].trim();
  } catch(e) {}
  if (!raw) {
    try {
      raw = os.hostname() + '|' + (process.env.COMPUTERNAME || 'MSG_PC');
    } catch(e) { raw = 'MSG_DEFAULT_HOST'; }
  }
  const hash = crypto.createHash('sha256').update(raw).digest('hex').toUpperCase();
  cachedMachineId = 'MSG-' + hash.slice(0, 4) + '-' + hash.slice(4, 8) + '-' + hash.slice(8, 12) + '-' + hash.slice(12, 16);
  return cachedMachineId;
}

/* ---------- KORUMALI OTOMATİK YEDEKLEME MOTORU (C:\MSG_Yazilim_Yedekleri) ---------- */
function takeProtectedBackup(tag) {
  try {
    fs.mkdirSync(PROTECTED_BK, { recursive: true });
    const hasData = (S.products && S.products.length > 0) || 
                    (S.customers && S.customers.length > 0) || 
                    (S.sales && S.sales.length > 0);
    const ts = new Date().toISOString().replace(/[:.]/g, '-');
    const snapFile = path.join(PROTECTED_BK, `MSG_OtoYedek_${tag}_${ts}.json`);
    const latestFile = path.join(PROTECTED_BK, 'MSG_Son_Guncel_Yedek.json');
    
    const o = { ...S };
    delete o.sessions;
    const jsonStr = JSON.stringify(o, null, 2);

    if (hasData) {
      fs.writeFileSync(snapFile, jsonStr, 'utf8');
      fs.writeFileSync(latestFile, jsonStr, 'utf8');
      try { fs.writeFileSync(path.join(LEGACY_BK, 'Hirdavat_Son_Guncel_Yedek.json'), jsonStr, 'utf8'); } catch(_) {}
    } else if (!fs.existsSync(latestFile)) {
      fs.writeFileSync(latestFile, jsonStr, 'utf8');
    }

    try {
      const files = fs.readdirSync(PROTECTED_BK).filter(f => f.startsWith('MSG_OtoYedek_')).sort();
      if (files.length > 100) {
        files.slice(0, files.length - 100).forEach(f => {
          try { fs.unlinkSync(path.join(PROTECTED_BK, f)); } catch(_) {}
        });
      }
    } catch(_) {}
    return true;
  } catch(e) {
    return false;
  }
}

function getProtectedBackupInfo() {
  try {
    const checkDirs = [PROTECTED_BK, LEGACY_BK];
    for (const dDir of checkDirs) {
      if (!fs.existsSync(dDir)) continue;
      const latestFile = path.join(dDir, dDir === PROTECTED_BK ? 'MSG_Son_Guncel_Yedek.json' : 'Hirdavat_Son_Guncel_Yedek.json');
      if (fs.existsSync(latestFile)) {
        const stat = fs.statSync(latestFile);
        const d = JSON.parse(fs.readFileSync(latestFile, 'utf8'));
        const pCount = (d.products || []).length;
        const cCount = (d.customers || []).length;
        const sCount = (d.sales || []).length;
        if (pCount > 0 || cCount > 0 || sCount > 0) {
          return {
            exists: true,
            file: path.basename(latestFile),
            mtime: stat.mtime,
            dateStr: new Date(stat.mtime).toLocaleString('tr-TR'),
            productsCount: pCount,
            customersCount: cCount,
            salesCount: sCount,
            shopName: d.settings?.shop || 'MSG YAZILIM'
          };
        }
      }
    }
  } catch(e) {}
  return { exists: false };
}

function restoreFromProtectedBackup() {
  try {
    let target = null;
    const candidates = [
      path.join(PROTECTED_BK, 'MSG_Son_Guncel_Yedek.json'),
      path.join(LEGACY_BK, 'Hirdavat_Son_Guncel_Yedek.json')
    ];
    for (const c of candidates) {
      if (fs.existsSync(c)) { target = c; break; }
    }
    if (!target) {
      if (fs.existsSync(PROTECTED_BK)) {
        const snaps = fs.readdirSync(PROTECTED_BK).filter(f => f.startsWith('MSG_OtoYedek_')).sort().reverse();
        if (snaps.length) target = path.join(PROTECTED_BK, snaps[0]);
      }
    }
    if (!target) return { ok: false, error: 'Yedek dosyası bulunamadı.' };
    const d = JSON.parse(fs.readFileSync(target, 'utf8'));
    if (!Array.isArray(d.products)) return { ok: false, error: 'Yedek dosyası bozuk veya geçersiz!' };

    for (const k of ['products', 'customers', 'sales', 'expenses', 'payments', 'quick']) {
      S[k] = Array.isArray(d[k]) ? d[k] : [];
    }
    S.seq.sale = Math.max(S.seq.sale || 0, Number(d.seq?.sale) || 0, ...S.sales.map(s => s.no || 0));
    if (d.settings) Object.assign(S.settings, d.settings);

    persist();
    return { ok: true, productsCount: S.products.length, customersCount: S.customers.length, salesCount: S.sales.length };
  } catch(e) {
    return { ok: false, error: 'Geri yükleme hatası: ' + e.message };
  }
}

/* ---------- LİSANS DOĞRULAMA MOTORU ---------- */
function verifyLicenseKey(keyStr) {
  if (!keyStr || typeof keyStr !== 'string') return { ok: false, error: 'Lisans anahtarı boş olamaz' };
  const parts = keyStr.trim().split('.');
  if (parts.length !== 2) return { ok: false, error: 'Geçersiz lisans anahtarı formatı' };

  try {
    const payloadBuf = Buffer.from(parts[0], 'base64');
    const sigBuf = Buffer.from(parts[1], 'base64');

    const verifier = crypto.createVerify('SHA256');
    verifier.update(payloadBuf);
    verifier.end();

    const isValidSig = verifier.verify(PUBLIC_KEY_PEM, sigBuf);
    if (!isValidSig) {
      return { ok: false, error: 'Lisans imzası geçersiz veya yetkisiz üretilmiş!' };
    }

    const payload = JSON.parse(payloadBuf.toString('utf8'));
    const currentMid = getMachineId();

    if (!payload.mid || payload.mid.toUpperCase() !== currentMid) {
      return { ok: false, error: `Bu lisans başka bir cihaza aittir! (Bu Cihaz: ${currentMid})` };
    }

    const now = Date.now();
    if (payload.exp && payload.exp > 0) {
      if (now > payload.exp) {
        return { ok: false, error: 'Lisans süreniz sona ermiştir! WhatsApp üzerinden lisansınızı yenileyiniz.', expired: true, payload };
      }
    }

    return { ok: true, payload };
  } catch(e) {
    return { ok: false, error: 'Lisans çözümlenemedi: ' + e.message };
  }
}

function checkCurrentLicense() {
  const currentMid = getMachineId();
  const bkInfo = getProtectedBackupInfo();
  if (!fs.existsSync(LIC_FILE)) {
    return { valid: false, mid: currentMid, error: 'Sistem lisanslanmamış. WhatsApp (0506 110 45 63) üzerinden lisans alınız.', hasBackup: bkInfo.exists, backupInfo: bkInfo };
  }
  try {
    const key = fs.readFileSync(LIC_FILE, 'utf8').trim();
    const res = verifyLicenseKey(key);
    if (!res.ok) {
      return { valid: false, mid: currentMid, error: res.error, expired: !!res.expired, hasBackup: bkInfo.exists, backupInfo: bkInfo };
    }
    const p = res.payload;
    const daysLeft = (p.exp && p.exp > 0) ? Math.max(0, Math.ceil((p.exp - Date.now()) / (1000 * 60 * 60 * 24))) : null;
    return {
      valid: true,
      mid: currentMid,
      client: p.client || 'Kullanıcı',
      type: p.type || 'Lisanslı',
      sector: p.sector || 'sarkuteri',
      secName: p.secName || '🥩 Şarküteri, Kasap & Manav',
      days: p.days,
      exp: p.exp,
      iat: p.iat,
      daysLeft,
      hasBackup: bkInfo.exists,
      backupInfo: bkInfo
    };
  } catch(e) {
    return { valid: false, mid: currentMid, error: 'Lisans dosyası okunamadı.', hasBackup: bkInfo.exists, backupInfo: bkInfo };
  }
}

/* ---------- OTOMATİK GÜNCELLEME MOTORU (GITHUB RELEASES & RAW INTEGRATION) ---------- */
const CURRENT_APP_VERSION = '2.1.4';
const GITHUB_REPO = 'mehmetsinangunay/msg-yazilim';

function isNewerVersion(remote, local) {
  if (!remote || !local) return false;
  const rParts = String(remote).replace(/^v/i, '').split('.').map(n => parseInt(n, 10) || 0);
  const lParts = String(local).replace(/^v/i, '').split('.').map(n => parseInt(n, 10) || 0);
  for (let i = 0; i < Math.max(rParts.length, lParts.length); i++) {
    const r = rParts[i] || 0;
    const l = lParts[i] || 0;
    if (r > l) return true;
    if (r < l) return false;
  }
  return false;
}

function fetchJsonFromUrl(urlStr, maxRedirects = 5) {
  return new Promise((resolve, reject) => {
    if (maxRedirects <= 0) return reject(new Error('Çok fazla yönlendirme'));
    try {
      const parsed = new URL(urlStr);
      const mod = parsed.protocol === 'https:' ? https : http;
      const req = mod.get(urlStr, {
        headers: {
          'User-Agent': 'MSG-Yazilim-POS-Updater',
          'Accept': 'application/json'
        }
      }, (res) => {
        if ([301, 302, 307, 308].includes(res.statusCode) && res.headers.location) {
          return resolve(fetchJsonFromUrl(res.headers.location, maxRedirects - 1));
        }
        if (res.statusCode !== 200) {
          return reject(new Error(`HTTP ${res.statusCode}`));
        }
        let raw = '';
        res.setEncoding('utf8');
        res.on('data', chunk => raw += chunk);
        res.on('end', () => {
          try {
            resolve(JSON.parse(raw));
          } catch(e) {
            reject(new Error('Geçersiz JSON verisi'));
          }
        });
      });
      req.on('error', reject);
      req.setTimeout(12000, () => {
        req.destroy();
        reject(new Error('Zaman aşımı'));
      });
    } catch(e) {
      reject(e);
    }
  });
}

function downloadFileToDisk(urlStr, destPath, maxRedirects = 5) {
  return new Promise((resolve, reject) => {
    if (maxRedirects <= 0) return reject(new Error('Çok fazla yönlendirme'));
    try {
      const parsed = new URL(urlStr);
      const mod = parsed.protocol === 'https:' ? https : http;
      const req = mod.get(urlStr, {
        headers: {
          'User-Agent': 'MSG-Yazilim-POS-Updater'
        }
      }, (res) => {
        if ([301, 302, 307, 308].includes(res.statusCode) && res.headers.location) {
          return resolve(downloadFileToDisk(res.headers.location, destPath, maxRedirects - 1));
        }
        if (res.statusCode !== 200) {
          return reject(new Error(`İndirme başarısız: HTTP ${res.statusCode}`));
        }
        const fileStream = fs.createWriteStream(destPath);
        res.pipe(fileStream);
        fileStream.on('finish', () => fileStream.close(() => resolve(destPath)));
        fileStream.on('error', (err) => {
          try { fs.unlinkSync(destPath); } catch(_) {}
          reject(err);
        });
      });
      req.on('error', reject);
      req.setTimeout(45000, () => {
        req.destroy();
        reject(new Error('İndirme zaman aşımı'));
      });
    } catch(e) {
      reject(e);
    }
  });
}

async function checkSystemUpdate() {
  const result = {
    ok: true,
    currentVersion: CURRENT_APP_VERSION,
    hasUpdate: false,
    repo: GITHUB_REPO,
    checkedAt: new Date().toISOString()
  };

  // 1. Canlı ve anlık GitHub API sorgusu (0 saniye gecikme)
  try {
    const apiUrl = `https://api.github.com/repos/${GITHUB_REPO}/contents/version.json?ref=main`;
    const apiData = await fetchJsonFromUrl(apiUrl);
    if (apiData && apiData.content) {
      const decodedStr = Buffer.from(apiData.content, 'base64').toString('utf8').replace(/^\uFEFF/, '').trim();
      const rawData = JSON.parse(decodedStr);
      if (rawData && rawData.version) {
        result.remote = rawData;
        result.hasUpdate = isNewerVersion(rawData.version, CURRENT_APP_VERSION);
        return result;
      }
    }
  } catch(e) {}

  // 2. Yedek: raw.githubusercontent.com
  const rawUrl = `https://raw.githubusercontent.com/${GITHUB_REPO}/main/version.json?t=${Date.now()}`;
  try {
    const rawData = await fetchJsonFromUrl(rawUrl);
    if (rawData && rawData.version) {
      result.remote = rawData;
      result.hasUpdate = isNewerVersion(rawData.version, CURRENT_APP_VERSION);
      return result;
    }
  } catch(e) {
    try {
      const relUrl = `https://api.github.com/repos/${GITHUB_REPO}/releases/latest`;
      const relData = await fetchJsonFromUrl(relUrl);
      if (relData && relData.tag_name) {
        const zipAsset = relData.assets && relData.assets.find(a => a.name.endsWith('.zip'));
        const remoteInfo = {
          version: relData.tag_name.replace(/^v/i, ''),
          title: relData.name || `Sürüm ${relData.tag_name}`,
          notes: relData.body || '',
          date: relData.published_at ? relData.published_at.slice(0, 10) : '',
          downloadUrl: zipAsset ? zipAsset.browser_download_url : `https://github.com/${GITHUB_REPO}/releases/download/${relData.tag_name}/update.zip`
        };
        result.remote = remoteInfo;
        result.hasUpdate = isNewerVersion(remoteInfo.version, CURRENT_APP_VERSION);
        return result;
      }
    } catch(errRel) {
      result.ok = false;
      result.error = 'Güncelleme sunucusuna ulaşılamadı veya henüz yayınlanmış bir sürüm bulunamadı.';
    }
  }
  return result;
}

function restartServerDelayed() {
  setTimeout(() => {
    try {
      const { spawn } = require('child_process');
      const nodeExe = process.execPath;
      const appExe = path.join(ROOT, 'MSGYazilim.exe');
      const psCmd = `Get-Process chrome, msedge -ErrorAction SilentlyContinue | Where-Object { $_.MainWindowTitle -like '*MSG YAZILIM*' } | Stop-Process -Force -ErrorAction SilentlyContinue; Get-Process MSGYazilim -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue; Start-Sleep -Milliseconds 1500; Start-Process -FilePath '${nodeExe.replace(/'/g, "''")}' -ArgumentList 'server.js' -WorkingDirectory '${ROOT.replace(/'/g, "''")}' -WindowStyle Hidden; Start-Sleep -Milliseconds 1500; if (Test-Path '${appExe.replace(/'/g, "''")}') { Start-Process -FilePath '${appExe.replace(/'/g, "''")}' -WorkingDirectory '${ROOT.replace(/'/g, "''")}' }`;
      spawn('powershell.exe', ['-NoProfile', '-WindowStyle', 'Hidden', '-Command', psCmd], {
        detached: true,
        stdio: 'ignore',
        cwd: ROOT,
        windowsHide: true
      }).unref();
      process.exit(0);
    } catch(e) {
      process.exit(0);
    }
  }, 1000);
}

function extractZipArchive(zipPath, targetDir) {
  // 1. Windows yerleşik tar.exe (en hızlı, sıfır bağımlılık)
  try {
    execFileSync('tar.exe', ['-xf', zipPath, '-C', targetDir], { timeout: 30000 });
    return true;
  } catch(e) {
    console.warn('tar.exe çıkarma hatası, .NET deneniyor:', e.message);
  }

  // 2. .NET ZipFile (Tüm Windows sürümlerinde yüklüdür)
  try {
    const psCmd = `Add-Type -AssemblyName System.IO.Compression.FileSystem; $zip = [System.IO.Compression.ZipFile]::OpenRead('${zipPath.replace(/'/g, "''")}'); foreach ($entry in $zip.Entries) { $dest = [System.IO.Path]::Combine('${targetDir.replace(/'/g, "''")}', $entry.FullName); $dir = [System.IO.Path]::GetDirectoryName($dest); if (!(Test-Path $dir)) { [System.IO.Directory]::CreateDirectory($dir) | Out-Null }; if ($entry.Name -ne '') { [System.IO.Compression.ZipFileExtensions]::ExtractToFile($entry, $dest, $true) } }; $zip.Dispose();`;
    execFileSync('powershell.exe', ['-ExecutionPolicy', 'Bypass', '-Command', psCmd], { timeout: 30000 });
    return true;
  } catch(e) {
    console.warn('.NET ZipFile hatası, Expand-Archive deneniyor:', e.message);
  }

  // 3. Fallback: PowerShell Expand-Archive
  const psFallback = `Import-Module Microsoft.PowerShell.Archive -ErrorAction SilentlyContinue; Expand-Archive -Path '${zipPath.replace(/'/g, "''")}' -DestinationPath '${targetDir.replace(/'/g, "''")}' -Force`;
  execFileSync('powershell.exe', ['-ExecutionPolicy', 'Bypass', '-Command', psFallback], { timeout: 45000 });
  return true;
}

async function applySystemUpdate(downloadUrl) {
  if (!downloadUrl) {
    downloadUrl = `https://raw.githubusercontent.com/${GITHUB_REPO}/main/update.zip`;
  }
  takeProtectedBackup('Oto_Guncelleme');
  const tempZip = path.join(DATA, `update_${Date.now()}.zip`);
  try {
    await downloadFileToDisk(downloadUrl, tempZip);
    const stat = fs.statSync(tempZip);
    if (!stat || stat.size < 500) {
      throw new Error('İndirilen güncelleme paketi boş veya geçersiz boyutta.');
    }
    extractZipArchive(tempZip, ROOT);
    try { fs.unlinkSync(tempZip); } catch(_) {}
    restartServerDelayed();
    return { ok: true, message: 'Güncelleme başarıyla kuruldu! Sistem yeniden başlatılıyor...' };
  } catch(err) {
    try { if (fs.existsSync(tempZip)) fs.unlinkSync(tempZip); } catch(_) {}
    return { ok: false, error: 'Güncelleme uygulanamadı: ' + err.message };
  }
}

async function applyManualZipUpdate(zipBase64) {
  if (!zipBase64) return { ok: false, error: 'Zip dosyası bulunamadı.' };
  takeProtectedBackup('Manuel_Guncelleme');
  const tempZip = path.join(DATA, `manual_update_${Date.now()}.zip`);
  try {
    const buf = Buffer.from(zipBase64, 'base64');
    fs.writeFileSync(tempZip, buf);
    extractZipArchive(tempZip, ROOT);
    try { fs.unlinkSync(tempZip); } catch(_) {}
    restartServerDelayed();
    return { ok: true, message: 'Güncelleme paketi başarıyla yüklendi! Sistem yeniden başlatılıyor...' };
  } catch(err) {
    try { if (fs.existsSync(tempZip)) fs.unlinkSync(tempZip); } catch(_) {}
    return { ok: false, error: 'Paket yüklenemedi: ' + err.message };
  }
}

/* ---------- VERİTABANI VE AYARLAR ---------- */
function defaults() {
  return {
    products: [], customers: [], sales: [], expenses: [], payments: [], quick: [],
    users: [{ id: 'admin', name: 'Yönetici', pin: '1234', role: 'admin' }],
    sessions: {}, seq: { sale: 0 }, v: 1,
    settings: { shop: 'MSG YAZILIM', phone: '', address: '', creditDays: 15, defMin: 5 }
  };
}

let S = (() => {
  try {
    const d = JSON.parse(fs.readFileSync(DBF, 'utf8'));
    const x = Object.assign(defaults(), d);
    x.settings = Object.assign(defaults().settings, d.settings || {});
    if (!x.settings.shop || x.settings.shop === 'Hırdavat') {
      x.settings.shop = 'MSG YAZILIM';
    }
    x.sessions = {}; // Her program açılışında oturumları sıfırla, PIN zorunlu olsun
    return x;
  } catch(e) { return defaults(); }
})();

function persist() {
  S.v++;
  const tmp = DBF + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(S));
  fs.renameSync(tmp, DBF);
  const day = new Date().toISOString().slice(0, 10), bf = path.join(BK, `db-${day}.json`);
  if (!fs.existsSync(bf)) {
    try {
      fs.copyFileSync(DBF, bf);
      fs.readdirSync(BK).sort().slice(0, -30).forEach(f => fs.unlinkSync(path.join(BK, f)));
    } catch(e) {}
  }
  // Korumalı klasördeki güncel yedeği de tazele
  try {
    fs.mkdirSync(PROTECTED_BK, { recursive: true });
    const o = { ...S }; delete o.sessions;
    fs.writeFileSync(path.join(PROTECTED_BK, 'Hirdavat_Son_Guncel_Yedek.json'), JSON.stringify(o, null, 2));
  } catch(e) {}
  broadcast();
}

function saveImage(d) {
  if (!d || !d.startsWith('data:image')) return d || null;
  const m = d.match(/^data:image\/(\w+);base64,(.+)$/);
  if (!m) return null;
  const f = uid() + '.' + (m[1] === 'png' ? 'png' : 'jpg');
  fs.writeFileSync(path.join(IMG, f), Buffer.from(m[2], 'base64'));
  return '/img/' + f;
}
function dropImage(u) {
  if (u && u.startsWith('/img/')) {
    try { fs.unlinkSync(path.join(IMG, path.basename(u))); } catch(e) {}
  }
}

let isSecure = false;
function lanIPs() {
  return Object.values(os.networkInterfaces()).flat().filter(x => x.family === 'IPv4' && !x.internal).map(x => x.address);
}

/* ---------- DURUM GÖRÜNÜMÜ ---------- */
function view(user) {
  const o = { ...S };
  delete o.sessions;
  o.users = user.role === 'admin' ? S.users.map(u => ({ id: u.id, name: u.name, role: u.role })) : [];
  if (user.role !== 'admin') { o.expenses = []; }
  o.me = { id: user.id, name: user.name, role: user.role, defaultPin: user.pin === '1234' };
  o.online = clients.size;
  o.network = { ips: lanIPs(), httpPort: PORT, httpsPort: HPORT, hasHttps: isSecure };
  o.license = checkCurrentLicense();
  o.backupInfo = getProtectedBackupInfo();
  o.version = CURRENT_APP_VERSION;
  return o;
}

/* ---------- İŞLEM KOMUTLARI ---------- */
const CASHIER = new Set(['sale', 'payment', 'custSave', 'quickSet', 'pinChange', 'returnItem']);
const fail = m => { throw new Error(m); };
const findP = id => S.products.find(p => p.id === id);
function genBarcode() {
  let b;
  do { b = '28' + String(Math.floor(Math.random() * 1e10)).padStart(10, '0'); }
  while(S.products.some(p => p.barcode === b));
  return b;
}

const cmds = {
  sale(p, u) {
    if (!Array.isArray(p.items) || !p.items.length) fail('Sepet boş');
    const need = {};
    const items = p.items.map(l => {
      const pr = findP(l.pid); if (!pr) fail('Ürün artık sistemde yok');
      const qty = num(l.qty); if (qty <= 0) fail(`${pr.name}: miktar 0 olamaz`);
      const roll = l.mode === 'roll'; if (roll && !pr.rollLen) fail(`${pr.name}: adet tanımı yok`);
      const used = roll ? qty * pr.rollLen : qty; need[pr.id] = (need[pr.id] || 0) + used;
      return { pid: pr.id, name: pr.name, barcode: pr.barcode, unit: roll ? 'adet' : (pr.unit === 'metre' ? 'm' : 'adet'), mode: roll ? 'roll' : 'base', qty, price: num(l.price), kdv: num(pr.kdv != null ? pr.kdv : (l.kdv != null ? l.kdv : 20)), used, cost: round2(used * (pr.cost || 0)) };
    });
    for (const id in need) { const pr = findP(id); if (need[id] > pr.stock + 1e-9) fail(`Yetersiz stok: ${pr.name} (kalan ${pr.stock})`); }
    const method = ['nakit', 'kart', 'veresiye', 'parcali'].includes(p.method) ? p.method : 'nakit';
    if (method === 'veresiye' && !S.customers.some(c => c.id === p.customerId)) fail('Veresiye için müşteri seçin');
    const sub = round2(items.reduce((a, i) => a + i.qty * i.price, 0)), disc = Math.min(Math.max(0, num(p.discount)), sub);
    const tot = round2(sub - disc);

    let pCash = 0;
    let pCard = 0;
    if (method === 'parcali') {
      pCash = round2(num(p.paidCash));
      pCard = round2(num(p.paidCard));
      if (pCash <= 0 && pCard <= 0) fail('Parçalı ödemede Nakit veya Kart tutarı belirtilmelidir');
      if (Math.abs(round2(pCash + pCard) - tot) >= 0.01) fail(`Parçalı ödeme tutarları toplamı (${round2(pCash + pCard)} ₺) fiş genel toplamına (${tot} ₺) eşit olmalıdır`);
    } else if (method === 'nakit') {
      pCash = tot;
    } else if (method === 'kart') {
      pCard = tot;
    }

    for (const id in need) findP(id).stock = round2(findP(id).stock - need[id]);
    const sale = {
      id: uid(), no: ++S.seq.sale, date: new Date().toISOString(), items, subtotal: sub, discount: disc, total: tot, cost: round2(items.reduce((a, i) => a + i.cost, 0)), method,
      paidCash: pCash,
      paidCard: pCard,
      customerId: method === 'veresiye' ? p.customerId : null, dueDate: method === 'veresiye' ? (p.dueDate || new Date(Date.now() + S.settings.creditDays * 864e5).toISOString()) : null, cashier: u.name
    };
    S.sales.push(sale); return { saleId: sale.id };
  },
  voidSale(p) {
    const s = S.sales.find(x => x.id === p.id); if (!s || s.void) fail('Satış bulunamadı');
    s.items.forEach(i => {
      const returnedQty = num(i.returnedQty || 0);
      const remainingQty = Math.max(0, i.qty - returnedQty);
      if (remainingQty > 0) {
        const factor = i.qty > 0 ? (remainingQty / i.qty) : 1;
        const stockToReturn = round2(i.used * factor);
        const pr = findP(i.pid);
        if (pr) pr.stock = round2(pr.stock + stockToReturn);
      }
    });
    s.void = true;
  },
  returnItem(p, u) {
    const s = S.sales.find(x => x.id === p.saleId);
    if (!s || s.void) fail('Satış bulunamadı veya iptal edilmiş');
    const idx = Number(p.itemIndex);
    if (isNaN(idx) || idx < 0 || idx >= s.items.length) fail('Geçersiz ürün kalemi');
    const item = s.items[idx];
    const returnQty = round3(num(p.qty));
    if (returnQty <= 0) fail('İade miktarı 0 dan büyük olmalıdır');
    const alreadyReturned = round3(num(item.returnedQty || 0));
    const availableQty = round3(item.qty - alreadyReturned);
    if (returnQty > availableQty + 1e-6) fail(`En fazla kalan miktar kadar (${availableQty} ${item.unit}) iade edilebilir`);

    // Stoğa geri ekle
    const pr = findP(item.pid);
    const roll = item.mode === 'roll';
    const stockToAdd = roll ? (pr?.rollLen ? round2(returnQty * pr.rollLen) : returnQty) : returnQty;
    if (pr) pr.stock = round2(pr.stock + stockToAdd);

    // Kalem üzerinde iade miktarını güncelle
    item.returnedQty = round3(alreadyReturned + returnQty);

    // İade finansal tutar hesabı (Varsa fiş genel iskonto orantısı dikkate alınarak)
    const rawLine = round2(returnQty * item.price);
    const sub = s.subtotal || round2(s.items.reduce((a, i) => a + i.qty * i.price, 0));
    const discRatio = sub > 0 ? Math.max(0, Math.min(1, (s.discount || 0) / sub)) : 0;
    const refundAmount = round2(rawLine * (1 - discRatio));

    // Satışın iade geçmişine kaydet
    if (!s.returns) s.returns = [];
    const retRecord = {
      id: uid(),
      date: new Date().toISOString(),
      itemIndex: idx,
      pid: item.pid,
      name: item.name,
      qty: returnQty,
      unit: item.unit,
      price: item.price,
      refundAmount,
      refundMethod: p.refundMethod || (s.method === 'veresiye' ? 'veresiye' : 'nakit'),
      note: p.note || '',
      cashier: u.name
    };
    s.returns.push(retRecord);

    // Eğer veresiye satışıysa, müşterinin bu fişteki borç tutarı otomatik azalır
    if (s.method === 'veresiye') {
      s.total = round2(Math.max(0, s.total - refundAmount));
    }

    // Tüm kalemler tamamen iade edildiyse fişi tamamen iade edilmiş olarak işaretle
    const allFullyReturned = s.items.every(i => round3(i.qty - (i.returnedQty || 0)) <= 0.0001);
    if (allFullyReturned) {
      s.void = true;
    }

    return { ok: true, returnRecord: retRecord, allFullyReturned };
  },
  prodSave(p) {
    const d = p.data || {}; if (!String(d.name || '').trim()) fail('Ürün adı gerekli');
    const cur = p.id ? findP(p.id) : null; if (p.id && !cur) fail('Ürün bulunamadı');
    const bc = String(d.barcode || '').trim() || genBarcode();
    if (S.products.some(x => x.barcode === bc && x.id !== p.id)) fail('Bu barkod başka üründe kayıtlı!');
    const unit = String(d.unit || 'adet').trim().toLowerCase();
    const rec = {
      name: String(d.name).trim(),
      barcode: bc,
      category: String(d.category || '').trim(),
      unit,
      cost: num(d.cost),
      price: num(d.price),
      kdv: num(d.kdv != null && d.kdv !== '' ? d.kdv : 20),
      rollLen: unit === 'metre' ? num(d.rollLen) : 0,
      rollPrice: unit === 'metre' ? num(d.rollPrice) : 0,
      min: d.min === '' || d.min == null ? S.settings.defMin : num(d.min),
      plu: String(d.plu || '').trim(),
      sizes: String(d.sizes || '').trim(),
      colors: String(d.colors || '').trim(),
      hanger: String(d.hanger || '').trim(),
      imei: String(d.imei || '').trim(),
      deviceModel: String(d.deviceModel || '').trim(),
      isbn: String(d.isbn || '').trim(),
      author: String(d.author || '').trim(),
      rack: String(d.rack || '').trim(),
      brand: String(d.brand || '').trim(),
      expiry: String(d.expiry || '').trim(),
      icon: String(d.icon || '').trim()
    };
    if (rec.rollPrice && !rec.rollLen) fail('Adet fiyatı için uzunluk girin');
    if (d.img !== undefined) { const old = cur && cur.img; rec.img = saveImage(d.img); if (old && old !== rec.img) dropImage(old); }
    if (cur) { Object.assign(cur, rec); if (d.stock !== undefined) cur.stock = num(d.stock); }
    else S.products.push({ id: uid(), created: new Date().toISOString(), stock: num(d.stock), img: null, ...rec });
  },
  prodDel(p) { const pr = findP(p.id); if (pr) dropImage(pr.img); S.products = S.products.filter(x => x.id !== p.id); S.quick = S.quick.filter(x => x !== p.id); },
  stockIn(p) { const pr = findP(p.id); if (!pr) fail('Ürün yok'); const q = num(p.qty); if (q <= 0) fail('Miktar girin'); pr.stock = round2(pr.stock + q); if (num(p.cost) > 0) pr.cost = num(p.cost); },
  custSave(p) {
    const n = String(p.data?.name || '').trim(); if (!n) fail('İsim gerekli');
    const d = { name: n, phone: String(p.data.phone || '').trim(), address: String(p.data.address || '').trim() };
    if (p.id) { const c = S.customers.find(x => x.id === p.id); if (!c) fail('Müşteri yok'); Object.assign(c, d); return { id: c.id }; }
    const c = { id: uid(), ...d }; S.customers.push(c); return { id: c.id };
  },
  payment(p) { const a = num(p.amount); if (a <= 0) fail('Tutar girin'); if (!S.customers.some(c => c.id === p.customerId)) fail('Müşteri yok'); S.payments.push({ id: uid(), date: new Date().toISOString(), customerId: p.customerId, amount: a, method: p.method === 'kart' ? 'kart' : 'nakit' }); },
  expAdd(p) { const a = num(p.amount); if (a <= 0) fail('Tutar girin'); S.expenses.push({ id: uid(), date: p.date || new Date().toISOString(), category: String(p.category || 'Diğer'), desc: String(p.desc || ''), amount: a }); },
  expDel(p) { S.expenses = S.expenses.filter(e => e.id !== p.id); },
  settings(p) {
    const s = p.data || {};
    Object.assign(S.settings, {
      shop: String(s.shop || '').trim() || 'MSG YAZILIM',
      phone: String(s.phone || ''),
      address: String(s.address || ''),
      creditDays: num(s.creditDays) || 15,
      defMin: num(s.defMin),
      activeSector: String(s.activeSector || S.settings.activeSector || '')
    });
  },
  quickSet(p) { S.quick = (p.ids || []).filter(id => findP(id)).slice(0, 40); },
  userSave(p) {
    const d = p.data || {}; const name = String(d.name || '').trim(); if (!name) fail('Kullanıcı adı gerekli');
    const role = d.role === 'admin' ? 'admin' : 'cashier';
    if (d.pin && !/^\d{4,8}$/.test(d.pin)) fail('PIN 4-8 haneli rakam olmalı');
    if (p.id) {
      const u = S.users.find(x => x.id === p.id); if (!u) fail('Kullanıcı yok');
      if (u.role === 'admin' && role !== 'admin' && S.users.filter(x => x.role === 'admin').length < 2) fail('En az bir yönetici kalmalı');
      u.name = name; u.role = role; if (d.pin) u.pin = d.pin;
    } else {
      if (!d.pin) fail('PIN gerekli');
      S.users.push({ id: uid(), name, role, pin: d.pin });
    }
  },
  userDel(p, u) {
    if (p.id === u.id) fail('Kendinizi silemezsiniz');
    const t = S.users.find(x => x.id === p.id); if (!t) return;
    if (t.role === 'admin' && S.users.filter(x => x.role === 'admin').length < 2) fail('En az bir yönetici kalmalı');
    S.users = S.users.filter(x => x.id !== p.id);
    for (const k in S.sessions) if (S.sessions[k] === p.id) delete S.sessions[k];
  },
  pinChange(p, u) { if (u.pin !== String(p.old)) fail('Eski PIN yanlış'); if (!/^\d{4,8}$/.test(String(p.pin))) fail('PIN 4-8 haneli rakam olmalı'); u.pin = String(p.pin); },
  import(p) {
    const d = p.state || {}; if (!Array.isArray(d.products)) fail('Geçersiz yedek');
    for (const k of ['products', 'customers', 'sales', 'expenses', 'payments', 'quick']) S[k] = Array.isArray(d[k]) ? d[k] : [];
    S.products.forEach(pr => { if (pr.img && pr.img.startsWith('data:')) pr.img = saveImage(pr.img); });
    S.seq.sale = Math.max(S.seq.sale, num(d.seq?.sale), ...S.sales.map(s => s.no || 0));
    if (d.settings) Object.assign(S.settings, d.settings);
  },
  wipe() { S.products.forEach(p => dropImage(p.img)); Object.assign(S, { products: [], customers: [], sales: [], expenses: [], payments: [], quick: [] }); }
};

/* ---------- CANLI SENKRON ---------- */
const clients = new Set();
function broadcast() {
  const m = `event: v\ndata: ${JSON.stringify({ v: S.v, online: clients.size })}\n\n`;
  for (const c of clients) c.res.write(m);
}

/* ---------- HTTP İSTEK YÖNETİMİ ---------- */
const MIME = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.jpg': 'image/jpeg', '.png': 'image/png', '.json': 'application/json', '.ico': 'image/x-icon', '.lic': 'text/plain'
};
const fails = {};
function body(req) {
  return new Promise((res, rej) => {
    let a = [], n = 0;
    req.on('data', c => { n += c.length; if (n > 60e6) { rej(new Error('big')); req.destroy(); } else a.push(c); });
    req.on('end', () => { try { res(a.length ? JSON.parse(Buffer.concat(a).toString()) : {}); } catch(e) { rej(e); } });
  });
}
const send = (res, code, obj) => {
  res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(JSON.stringify(obj));
};
const authUser = (req, url) => {
  const t = req.headers['x-token'] || url.searchParams.get('token');
  const id = t && S.sessions[t];
  return id ? S.users.find(u => u.id === id) : null;
};

const handler = async (req, res) => {
  try {
    const url = new URL(req.url, 'http://x');
    const p = url.pathname;

    /* Açık Lisans Endpointleri */
    if (p === '/api/license' && req.method === 'GET') {
      return send(res, 200, checkCurrentLicense());
    }
    if (p === '/api/license/activate' && req.method === 'POST') {
      const b = await body(req);
      const resVer = verifyLicenseKey(b.key);
      if (!resVer.ok) return send(res, 400, { ok: false, error: resVer.error });
      fs.writeFileSync(LIC_FILE, b.key.trim(), 'utf8');
      const curLic = checkCurrentLicense();
      if (curLic.valid && curLic.client && (!S.settings.shop || S.settings.shop === 'Hırdavat')) {
        S.settings.shop = curLic.client;
        save();
      }
      return send(res, 200, { ok: true, license: curLic });
    }

    /* Korumalı Yedek Endpointleri (Yeniden Kurulum Kurtarma) */
    if (p === '/api/backup/external-info' && req.method === 'GET') {
      return send(res, 200, getProtectedBackupInfo());
    }
    if (p === '/api/backup/restore-external' && req.method === 'POST') {
      const r = restoreFromProtectedBackup();
      if (r.ok) return send(res, 200, { ok: true, ...r });
      return send(res, 400, { ok: false, error: r.error });
    }

    /* Açık Güncelleme Denetimi */
    if (p === '/api/update/check' && req.method === 'GET') {
      const updateInfo = await checkSystemUpdate();
      return send(res, 200, updateInfo);
    }

    if (p === '/api/shutdown' && req.method === 'POST') {
      takeProtectedBackup('Kapanis');
      S.sessions = {};
      try { fs.writeFileSync(DBF, JSON.stringify(S)); } catch(_) {}
      send(res, 200, { ok: true });
      setTimeout(() => process.exit(0), 400);
      return;
    }

    if (p === '/api/users' && req.method === 'GET') {
      const curLic = checkCurrentLicense();
      const secKey = (curLic && curLic.valid && curLic.sector) ? curLic.sector : (S.settings?.activeSector || 'sarkuteri');
      const secName = (curLic && curLic.valid && curLic.secName) ? curLic.secName : '';
      return send(res, 200, {
        users: S.users.map(u => ({ id: u.id, name: u.name })),
        shop: S.settings?.shop || 'MSG YAZILIM',
        license: curLic,
        sector: secKey,
        secName: secName
      });
    }
    if (p === '/api/login' && req.method === 'POST') {
      const ip = req.socket.remoteAddress, f = fails[ip] || { n: 0, t: 0 };
      if (f.n >= 5 && Date.now() - f.t < 30000) return send(res, 429, { error: 'Çok fazla hatalı deneme. 30 saniye bekleyin.' });
      const b = await body(req), u = S.users.find(x => x.id === b.id && x.pin === String(b.pin));
      if (!u) { fails[ip] = { n: f.n + 1, t: Date.now() }; return send(res, 401, { error: 'PIN hatalı' }); }
      delete fails[ip];
      const token = crypto.randomBytes(24).toString('hex');
      S.sessions[token] = u.id;
      fs.writeFileSync(DBF, JSON.stringify(S));
      return send(res, 200, { token });
    }

    if (p.startsWith('/api/')) {
      const u = authUser(req, url);
      if (!u) return send(res, 401, { error: 'Oturum yok' });

      // Lisans kontrolü: Lisans geçerli değilse kritik işlemler engellenir
      const lic = checkCurrentLicense();
      if (!lic.valid && p === '/api/cmd') {
        return send(res, 403, { error: 'LİSANS GEREKLİ: ' + (lic.error || 'Sistem lisansı geçersiz veya süresi dolmuş.'), license: lic });
      }

      if (p === '/api/state') return send(res, 200, view(u));
      if (p === '/api/logout') {
        for (const k in S.sessions) if (S.sessions[k] === u.id && k === req.headers['x-token']) delete S.sessions[k];
        return send(res, 200, {});
      }
      if (p === '/api/backup') {
        if (u.role !== 'admin') return send(res, 403, { error: 'Yetki yok' });
        const o = { ...S }; delete o.sessions;
        o.products = o.products.map(pr => {
          if (pr.img && pr.img.startsWith('/img/')) {
            try {
              const f = path.join(IMG, path.basename(pr.img));
              return { ...pr, img: `data:image/${f.endsWith('png') ? 'png' : 'jpeg'};base64,` + fs.readFileSync(f).toString('base64') };
            } catch(e) {}
          }
          return pr;
        });
        res.writeHead(200, { 'Content-Type': 'application/json', 'Content-Disposition': `attachment; filename="msg-yedek-${new Date().toISOString().slice(0, 10)}.json"` });
        return res.end(JSON.stringify(o));
      }
      /* Otomatik ve Manuel Güncelleme Endpointleri */
      if (p === '/api/update/check' && req.method === 'GET') {
        const updateInfo = await checkSystemUpdate();
        return send(res, 200, updateInfo);
      }
      if (p === '/api/update/apply') {
        if (u.role !== 'admin') return send(res, 403, { error: 'Yalnızca yönetici güncelleyebilir' });
        let downloadUrl = null;
        try {
          if (req.method === 'POST') {
            const b = await body(req);
            downloadUrl = b?.downloadUrl;
          }
        } catch(_) {}
        const result = await applySystemUpdate(downloadUrl);
        return send(res, result.ok ? 200 : 500, result);
      }
      if (p === '/api/update/upload' && req.method === 'POST') {
        if (u.role !== 'admin') return send(res, 403, { error: 'Yalnızca yönetici güncelleyebilir' });
        const b = await body(req);
        const result = await applyManualZipUpdate(b.zipBase64);
        return send(res, result.ok ? 200 : 500, result);
      }
      if (p === '/api/events') {
        res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache', Connection: 'keep-alive' });
        const c = { res }; clients.add(c); res.write(`retry: 2000\n\n`); broadcast();
        const hb = setInterval(() => res.write(': hb\n\n'), 20000);
        req.on('close', () => { clearInterval(hb); clients.delete(c); broadcast(); });
        return;
      }
      if (p === '/api/cmd' && req.method === 'POST') {
        const b = await body(req);
        if (!cmds[b.t]) return send(res, 400, { error: 'Bilinmeyen işlem' });
        if (u.role !== 'admin' && !CASHIER.has(b.t)) return send(res, 403, { error: 'Bu işlem için yetkiniz yok', state: view(u) });
        try {
          const result = cmds[b.t](b.p || {}, u) || {};
          persist();
          return send(res, 200, { ok: true, result, state: view(u) });
        } catch(e) {
          return send(res, 200, { error: e.message, state: view(u) });
        }
      }
      return send(res, 404, { error: 'yok' });
    }

    if (p === '/cert.cer' && fs.existsSync(path.join(DATA, 'cert.cer'))) {
      res.writeHead(200, { 'Content-Type': 'application/x-x509-ca-cert', 'Content-Disposition': 'attachment; filename="msg-sertifika.cer"' });
      return fs.createReadStream(path.join(DATA, 'cert.cer')).pipe(res);
    }

    // Statik dosya sunumu
    let f = p === '/' ? '/index.html' : p;
    const full = f.startsWith('/img/') ? path.join(IMG, path.basename(f)) : path.join(ROOT, path.normalize(f).replace(/^(\.\.[\/\\])+/, ''));
    const ok = f.startsWith('/img/') || ['/index.html', '/app.js', '/style.css', '/manifest.json', '/sw.js', '/logo.png', '/icon.ico', '/zxing.min.js', '/html5-qrcode.min.js'].includes(f) || /^\/icon-\d+\.png$/.test(f);
    if (!ok || !fs.existsSync(full)) {
      res.writeHead(404);
      return res.end('Bulunamadı');
    }
    res.writeHead(200, {
      'Content-Type': MIME[path.extname(full)] || 'application/octet-stream',
      'Cache-Control': f.startsWith('/img/') ? 'public, max-age=86400' : 'no-cache, no-store, must-revalidate'
    });
    fs.createReadStream(full).pipe(res);
  } catch(e) {
    try { send(res, 500, { error: 'Sunucu hatası: ' + e.message }); } catch(_) {}
  }
};

/* Kapanış hookları - Otomatik korumalı kapanış yedeği */
process.on('SIGINT', () => { takeProtectedBackup('Kapanis'); process.exit(0); });
process.on('SIGTERM', () => { takeProtectedBackup('Kapanis'); process.exit(0); });
process.on('beforeExit', () => { takeProtectedBackup('Kapanis'); });

/* ---------- BAŞLATICI ---------- */
http.createServer(handler).listen(PORT, '0.0.0.0', () => {
  takeProtectedBackup('Acilis');
  const ips = lanIPs();
  console.log('\n  ======================================================');
  console.log('         💎 MSG YAZILIM TİCARİ SİSTEMİ AKTİF');
  console.log('  ======================================================\n');
  console.log('  [Ana Bilgisayar]     : http://localhost:' + PORT);
  ips.forEach(ip => console.log('  [Ağ / Mobil HTTP]    : http://' + ip + ':' + PORT));
  console.log('  [Donanım ID]         : ' + getMachineId());
  console.log('  [Yedek Konumu]       : ' + PROTECTED_BK);
  console.log('\n  ======================================================\n');
});

// Güvenli Mobil ve Kamera Erişimi (HTTPS - Port 3443)
try {
  const pfxFile = path.join(DATA, 'cert.pfx');
  const cerFile = path.join(DATA, 'cert.cer');
  const scriptFile = path.join(ROOT, 'create-cert.ps1');
  if (!fs.existsSync(pfxFile) && fs.existsSync(scriptFile)) {
    try {
      const ips = lanIPs();
      const ipArgs = ips.map(x => "'" + x + "'").join(',');
      const cmd = `powershell -NoProfile -ExecutionPolicy Bypass -File "${scriptFile}" -ips @(${ipArgs}) -outPfx "${pfxFile}" -outCer "${cerFile}"`;
      const { execSync } = require('child_process');
      execSync(cmd, { stdio: 'ignore' });
    } catch(err) {
      console.log('Otomatik sertifika oluşturulamadı:', err.message);
    }
  }

  if (fs.existsSync(pfxFile)) {
    const pfx = fs.readFileSync(pfxFile);
    let startHttps = (pass) => {
      try {
        https.createServer({ pfx, passphrase: pass }, handler).listen(HPORT, '0.0.0.0', () => {
          isSecure = true;
          const ips = lanIPs();
          console.log('  [Mobil / Kamera HTTPS]: https://localhost:' + HPORT);
          ips.forEach(ip => console.log('  [Mobil Barkod Okuyucu]: https://' + ip + ':' + HPORT));
        });
        return true;
      } catch(e) { return false; }
    };
    if (!startHttps('hirdavat')) {
      startHttps('cancan');
    }
  }
} catch(e) {
  console.log('HTTPS başlatılamadı:', e.message);
}

